/* DPM Nexus V9 - Live dashboard binding */
(() => {
  "use strict";

  const byId = (id) => document.getElementById(id);
  const money = (value) => {
    const n = Number(value || 0);
    return new Intl.NumberFormat("en-IN", {
      style: "currency", currency: "INR", maximumFractionDigits: 0
    }).format(n);
  };

  async function loadLiveDashboard() {
    const status = byId("dpmLiveDashboardStatus");
    try {
      const response = await fetch("/api/dashboard/live-status", {
        method: "GET",
        credentials: "same-origin",
        headers: { "Accept": "application/json" }
      });

      if (response.status === 401) {
        if (status) status.textContent = "Session expired. Please sign in again.";
        return;
      }
      if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        throw new Error(body.detail || `Dashboard API failed (${response.status})`);
      }

      const data = await response.json();
      if (!data || data.success !== true) throw new Error("Invalid dashboard response");

      if (byId("dpmKpiProjects")) byId("dpmKpiProjects").textContent =
        Number(data.projects?.total || 0).toLocaleString("en-IN");
      if (byId("dpmKpiClients")) byId("dpmKpiClients").textContent =
        Number(data.crm?.lead_records || 0).toLocaleString("en-IN");
      if (byId("dpmKpiBoq")) byId("dpmKpiBoq").textContent =
        Number(data.boq?.line_items || 0).toLocaleString("en-IN");
      if (byId("dpmKpiRevenue")) byId("dpmKpiRevenue").textContent =
        money(data.finance?.paid_revenue || 0);

      const name = data.user?.name;
      if (name && byId("dashboardWelcomeName")) {
        byId("dashboardWelcomeName").textContent = name;
      }

      if (status) {
        status.textContent = `Live database data · Updated ${new Date(data.generated_at).toLocaleTimeString("en-IN")}`;
      }
    } catch (error) {
      console.error("DPM live dashboard:", error);
      if (status) status.textContent = "Live dashboard data unavailable: " + error.message;
    }
  }


  async function applyDashboardAccess() {
    const adminRoles = new Set(["admin", "administrator", "super admin", "superadmin", "director"]);
    let user = null;
    try {
      const r = await fetch("/api/profile", { credentials: "same-origin", headers: { "Accept": "application/json" } });
      if (r.ok) {
        const payload = await r.json();
        user = payload.data || payload.user || payload.profile || null;
      }
    } catch (e) {
      console.warn("Could not load dashboard profile:", e);
    }

    const roleText = String(user?.role || "").trim();
    const isAdmin = adminRoles.has(roleText.toLowerCase());
    document.querySelectorAll('[data-access="admin"]').forEach((el) => {
      el.hidden = !isAdmin;
    });

    if (user) {
      const displayName = user.name || user.full_name || user.email;
      if (displayName) {
        ["sidebarName", "topbarName", "dashboardWelcomeName"].forEach((id) => {
          const el = document.getElementById(id);
          if (el) el.textContent = displayName;
        });
      }
      if (roleText) {
        ["sidebarRole", "topbarRole"].forEach((id) => {
          const el = document.getElementById(id);
          if (el) el.textContent = roleText;
        });
      }
    }

    // Do not expose the internal admin dashboard to non-admin accounts.
    if (!isAdmin) {
      const content = document.getElementById("content");
      if (content) {
        content.innerHTML = '<div style="max-width:560px;margin:8vh auto;padding:24px;border:1px solid var(--border);border-radius:18px;background:var(--panel);text-align:center"><h2>Admin access required</h2><p>This dashboard contains internal DPM workspace tools. Please use the public website or contact your administrator for access.</p><a href="/" style="display:inline-block;margin-top:12px;padding:11px 16px;border-radius:10px;background:var(--primary);color:#fff;text-decoration:none">Go to Public Website</a></div>';
      }
    }
  }

  function setupMobileMenu() {
    const toggle = document.getElementById("dpmMobileMenuToggle");
    const backdrop = document.getElementById("dpmMobileBackdrop");
    const close = () => {
      document.body.classList.remove("dpm-menu-open");
      if (backdrop) backdrop.hidden = true;
      if (toggle) toggle.setAttribute("aria-expanded", "false");
    };
    if (toggle) toggle.addEventListener("click", () => {
      const open = !document.body.classList.contains("dpm-menu-open");
      document.body.classList.toggle("dpm-menu-open", open);
      if (backdrop) backdrop.hidden = !open;
      toggle.setAttribute("aria-expanded", String(open));
    });
    if (backdrop) backdrop.addEventListener("click", close);
    document.querySelectorAll("#sidebar [data-route], #sidebar a").forEach((el) => {
      el.addEventListener("click", close);
    });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });
  }

  document.addEventListener("DOMContentLoaded", () => {
    setupMobileMenu();
    applyDashboardAccess();
    loadLiveDashboard();
  });
  window.DPMDashboard = { refresh: loadLiveDashboard };
})();
