/* DPM Nexus V10 — small shared page enhancements */
(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    const year = document.querySelector("[data-current-year], #current-year");
    if (year) year.textContent = String(new Date().getFullYear());

    document.querySelectorAll('a[href="#"]').forEach(function (link) {
      link.addEventListener("click", function (event) {
        event.preventDefault();
      });
    });

    document.querySelectorAll("[data-confirm]").forEach(function (element) {
      element.addEventListener("click", function (event) {
        const message = element.getAttribute("data-confirm") || "Are you sure?";
        if (!window.confirm(message)) event.preventDefault();
      });
    });
  });
})();
