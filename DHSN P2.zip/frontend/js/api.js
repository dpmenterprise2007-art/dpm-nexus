/* DPM Nexus V10 — API helper
 * Keep endpoint contracts aligned with backend routes before enabling submissions.
 */
(function (global) {
  "use strict";

  async function request(url, options) {
    const config = Object.assign(
      { method: "GET", credentials: "same-origin", headers: {} },
      options || {}
    );

    if (config.body && typeof config.body !== "string" &&
        !(config.body instanceof FormData) && !(config.body instanceof URLSearchParams)) {
      config.headers["Content-Type"] = "application/json";
      config.body = JSON.stringify(config.body);
    }

    const response = await fetch(url, config);
    const contentType = response.headers.get("content-type") || "";
    let payload;

    if (contentType.includes("application/json")) {
      payload = await response.json();
    } else {
      payload = await response.text();
    }

    if (!response.ok) {
      const message = payload && typeof payload === "object" && payload.detail
        ? payload.detail
        : "Request failed (" + response.status + ").";
      throw new Error(String(message));
    }

    return payload;
  }

  function formToObject(form) {
    const result = {};
    new FormData(form).forEach(function (value, key) {
      if (Object.prototype.hasOwnProperty.call(result, key)) {
        result[key] = Array.isArray(result[key]) ? result[key].concat(value) : [result[key], value];
      } else {
        result[key] = value;
      }
    });
    return result;
  }

  global.DPMApi = Object.freeze({
    request: request,
    formToObject: formToObject
  });
})(window);
