/* DPM Nexus V10 — registration form client-side checks
 * Server-side validation and authorization are still required.
 */
(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector('form[action*="register"]');
    if (!form) return;

    const password = form.querySelector('input[name="password"]');
    if (password) {
      password.addEventListener("input", function () {
        password.setCustomValidity("");
        if (password.value && password.value.length < 8) {
          password.setCustomValidity("Use at least 8 characters.");
        }
      });
    }

    form.addEventListener("submit", function (event) {
      if (!form.reportValidity()) {
        event.preventDefault();
        return;
      }
      const submit = form.querySelector('button[type="submit"], input[type="submit"]');
      if (submit) submit.disabled = true;
    });
  });
})();
