/* DPM Nexus V10 — auth-page safety and usability
 * Does not intercept login/register submissions; backend routes remain authoritative.
 */
(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll('input[type="password"]').forEach(function (field) {
      field.autocomplete = field.autocomplete || "current-password";
      field.addEventListener("paste", function () {
        // Password managers and paste remain allowed for accessibility and security.
      });
    });

    document.querySelectorAll('form[action*="login"], form[action*="register"]').forEach(function (form) {
      form.addEventListener("submit", function (event) {
        if (!form.reportValidity()) {
          event.preventDefault();
          return;
        }
        const submit = form.querySelector('button[type="submit"], input[type="submit"]');
        if (submit) {
          submit.disabled = true;
          submit.dataset.submitting = "true";
        }
      });
    });
  });
})();
