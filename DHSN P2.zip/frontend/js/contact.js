/* DPM Nexus V10 — contact form validation
 * This file validates fields only. It does not assume that /api/contact accepts form data.
 */
(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector('form[data-contact-form], main form[action*="contact"]');
    if (!form) return;

    form.addEventListener("submit", function (event) {
      if (!form.reportValidity()) {
        event.preventDefault();
        return;
      }

      const email = form.querySelector('input[type="email"]');
      if (email && email.value.trim() && !email.validity.valid) {
        event.preventDefault();
        email.focus();
      }
    });
  });
})();
