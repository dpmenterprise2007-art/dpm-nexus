/* DPM Nexus V10 — shared form feedback helpers */
(function (global) {
  "use strict";

  function setStatus(form, message, isError) {
    if (!form) return;
    let status = form.querySelector("[data-form-status]");
    if (!status) {
      status = document.createElement("p");
      status.setAttribute("data-form-status", "");
      status.setAttribute("role", "status");
      status.setAttribute("aria-live", "polite");
      form.appendChild(status);
    }
    status.textContent = message;
    status.dataset.state = isError ? "error" : "success";
  }

  function setBusy(form, busy, busyLabel) {
    if (!form) return;
    const submit = form.querySelector('button[type="submit"], input[type="submit"]');
    if (!submit) return;
    if (busy) {
      submit.dataset.originalLabel = submit.tagName === "INPUT" ? submit.value : submit.textContent;
      if (submit.tagName === "INPUT") submit.value = busyLabel || "Please wait…";
      else submit.textContent = busyLabel || "Please wait…";
      submit.disabled = true;
    } else {
      const original = submit.dataset.originalLabel;
      if (original !== undefined) {
        if (submit.tagName === "INPUT") submit.value = original;
        else submit.textContent = original;
        delete submit.dataset.originalLabel;
      }
      submit.disabled = false;
    }
  }

  global.DPMApp = Object.freeze({ setStatus: setStatus, setBusy: setBusy });
})(window);
