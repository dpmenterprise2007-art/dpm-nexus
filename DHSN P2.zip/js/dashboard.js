/* DPM Nexus V10 — dashboard shell
 * Avoids inventing API calls or exposing business data in the browser.
 */
(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    const dashboard = document.querySelector("[data-dpm-dashboard]");
    if (!dashboard) return;

    dashboard.dispatchEvent(new CustomEvent("dpm:dashboard-ready", {
      bubbles: true,
      detail: { ready: true }
    }));
  });
})();
