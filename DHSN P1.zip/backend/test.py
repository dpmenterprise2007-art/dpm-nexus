from openai import OpenAI
client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key="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")
r = client.chat.completions.create(
    model="nvidia/nemotron-3-ultra-550b-a55b:free",
    messages=[
        {"role": "system", "content": "Tum DPM Enterprise Private Limited (interior design company, Palghar, Maharashtra) ke sales assistant ho. Tum company ki taraf se client ko likhte ho. Hinglish mein, polite aur chhota jawab do."},
        {"role": "user", "content": "Humne client Rahul Sharma ko 500 sq.ft corporate office ka quotation Rs. 19,18,592 ka bheja hai. Ab ek WhatsApp follow-up message likho jo poochhe ki quotation dekha ya nahi, aur site visit ka time maange. Sirf message likho, options nahi."}
    ])
print(r.choices[0].message.content) 

