from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
main_file = ROOT / "main.py"

if not main_file.exists():
    raise SystemExit("main.py not found.")

text = main_file.read_text(encoding="utf-8")

imp = "from routes.ai_skills import router as ai_skills_router"
if imp not in text:
    marker = "from routes.public_ai import router as public_ai_router"
    if marker not in text:
        raise SystemExit("Could not find public_ai router import marker in main.py.")
    text = text.replace(marker, marker + "\n" + imp, 1)

inc = "app.include_router(ai_skills_router)"
if inc not in text:
    marker = "app.include_router(public_ai_router)"
    if marker not in text:
        raise SystemExit("Could not find public_ai router registration marker in main.py.")
    text = text.replace(marker, marker + "\n" + inc, 1)

backup = ROOT / "main.py.phase1_routes_backup"
if not backup.exists():
    shutil.copy2(main_file, backup)

main_file.write_text(text, encoding="utf-8")
print("Phase 1 AI Skills router added successfully.")
