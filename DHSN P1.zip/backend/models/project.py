# ==========================================================
# PROJECT MODEL
# ==========================================================


from sqlalchemy import (

    Column,

    Integer,

    String,

    Float,

    DateTime

)

from datetime import datetime

from database.base import Base



class Project(Base):


    __tablename__ = "projects"



    id = Column(

        Integer,

        primary_key=True

    )


    project_name = Column(

        String(200)

    )


    client_name = Column(

        String(200)

    )


    location = Column(

        String(200)

    )


    project_value = Column(

        Float,

        default=0

    )


    status = Column(

        String(50),

        default="Planning"

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )