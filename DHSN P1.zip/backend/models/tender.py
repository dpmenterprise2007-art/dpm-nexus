# ==========================================================
# TENDER MODEL
# ==========================================================

from sqlalchemy import (
    Column,
    Integer,
    String,
    DateTime
)

from datetime import datetime

from database.base import Base



class Tender(Base):

    __tablename__ = "tenders"


    id = Column(

        Integer,

        primary_key=True

    )


    tender_number = Column(

        String(100)

    )


    department = Column(

        String(200)

    )


    title = Column(

        String(500)

    )


    location = Column(

        String(200)

    )


    status = Column(

        String(50),

        default="Open"

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )