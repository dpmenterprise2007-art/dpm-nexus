# ==========================================================
# DPM NEXUS V9
# ADMIN ACTION MODEL
# ==========================================================


from sqlalchemy import (

    Column,

    Integer,

    String,

    Boolean,

    DateTime

)

from datetime import datetime

from database.base import Base



class AdminAction(Base):

    __tablename__ = "admin_actions"


    id = Column(

        Integer,

        primary_key=True

    )


    admin_email = Column(

        String(200)

    )


    action = Column(

        String(200)

    )


    module = Column(

        String(100)

    )


    status = Column(

        String(50),

        default="Completed"

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )