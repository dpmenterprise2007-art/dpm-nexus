# ==========================================================
# CRM LEAD MODEL
# ==========================================================

from sqlalchemy import (
    Column,
    Integer,
    String,
    DateTime
)

from datetime import datetime

from database.base import Base



class CRMLead(Base):

    __tablename__ = "crm_leads"


    id = Column(

        Integer,

        primary_key=True

    )


    company_name = Column(

        String(200)

    )


    contact_person = Column(

        String(200)

    )


    email = Column(

        String(200)

    )


    phone = Column(

        String(50)

    )


    source = Column(

        String(100),

        default="Website"

    )


    status = Column(

        String(50),

        default="New"

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )
