# ==========================================================
# DPM NEXUS V9
# ROLE MODEL
# ==========================================================


from sqlalchemy import (

    Column,

    Integer,

    String,

    Boolean,

    DateTime

)

from datetime import datetime

from database.base import Base



class Role(Base):

    __tablename__ = "roles"


    id = Column(

        Integer,

        primary_key=True

    )


    name = Column(

        String(100),

        unique=True

    )


    description = Column(

        String(500)

    )


    is_active = Column(

        Boolean,

        default=True

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )