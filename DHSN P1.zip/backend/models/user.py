# ==========================================================
# DPM NEXUS V9
# USER MODEL
# ==========================================================

from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    DateTime
)

from datetime import datetime

from database.base import Base


# ==========================================================
# USER TABLE
# ==========================================================

class User(Base):

    __tablename__ = "users"


    id = Column(
        Integer,
        primary_key=True,
        index=True
    )


    name = Column(
        String(150),
        nullable=False
    )


    company_name = Column(
        String(200),
        nullable=True
    )


    email = Column(
        String(200),
        unique=True,
        index=True,
        nullable=False
    )


    phone = Column(
        String(20),
        nullable=True
    )


    password_hash = Column(
        String(255),
        nullable=True
    )


    role = Column(
        String(100),
        default="Workspace Member"
    )


    picture = Column(
        String(500),
        nullable=True
    )


    is_active = Column(
        Boolean,
        default=True
    )


    created_at = Column(
        DateTime,
        default=datetime.utcnow
    )


    otp_code = Column(
        String(6),
        nullable=True
    )


    otp_expiry = Column(
        DateTime,
        nullable=True
    )


    otp_verified = Column(
        Boolean,
        default=False
    )


    otp_attempts = Column(
        Integer,
        default=0
    )


    last_otp_sent = Column(
        DateTime,
        nullable=True
    )