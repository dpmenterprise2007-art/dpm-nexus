# ==========================================================
# DPM NEXUS V9
# DOCUMENT MODEL
# ==========================================================


from sqlalchemy import (

    Column,

    Integer,

    String,

    DateTime

)

from datetime import datetime

from database.base import Base



class Document(Base):

    __tablename__ = "documents"


    id = Column(

        Integer,

        primary_key=True

    )


    file_name = Column(

        String(300),

        nullable=False

    )


    file_path = Column(

        String(500),

        nullable=False

    )


    file_type = Column(

        String(100)

    )


    category = Column(

        String(100),

        default="General"

    )


    project_id = Column(

        Integer,

        nullable=True

    )


    uploaded_by = Column(

        String(200),

        nullable=True

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )