# ==========================================================
# DPM NEXUS V9
# EMPLOYEE MODEL
# ==========================================================


from sqlalchemy import (

    Column,

    Integer,

    String,

    DateTime

)

from datetime import datetime

from database.base import Base



class Employee(Base):

    __tablename__ = "employees"



    id = Column(

        Integer,

        primary_key=True

    )


    name = Column(

        String(200),

        nullable=False

    )


    department = Column(

        String(100)

    )


    designation = Column(

        String(100)

    )


    phone = Column(

        String(50)

    )


    email = Column(

        String(200)

    )


    status = Column(

        String(50),

        default="Active"

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )