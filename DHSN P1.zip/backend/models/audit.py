# ==========================================================
# DPM NEXUS V9
# AUDIT LOG MODEL
# ==========================================================


from sqlalchemy import (

    Column,

    Integer,

    String,

    DateTime

)

from datetime import datetime

from database.base import Base



class AuditLog(Base):

    __tablename__ = "audit_logs"


    id = Column(

        Integer,

        primary_key=True

    )


    user_email = Column(

        String(200),

        nullable=True

    )


    module = Column(

        String(100)

    )


    action = Column(

        String(200)

    )


    description = Column(

        String(1000)

    )


    ip_address = Column(

        String(100),

        nullable=True

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )