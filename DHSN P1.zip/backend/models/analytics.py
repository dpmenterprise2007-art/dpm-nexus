# ==========================================================
# DPM NEXUS V9
# ANALYTICS KPI MODEL
# ==========================================================


from sqlalchemy import (

    Column,

    Integer,

    String,

    Float,

    DateTime

)

from datetime import datetime

from database.base import Base



class AnalyticsKPI(Base):

    __tablename__ = "analytics_kpi"


    id = Column(

        Integer,

        primary_key=True

    )


    metric_name = Column(

        String(200)

    )


    metric_value = Column(

        Float,

        default=0

    )


    category = Column(

        String(100)

    )


    period = Column(

        String(50)

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )