# ==========================================================
# DPM NEXUS V9
# PURCHASE ORDER MODEL
# ==========================================================


from sqlalchemy import (

    Column,

    Integer,

    String,

    Float,

    DateTime

)

from datetime import datetime

from database.base import Base



class PurchaseOrder(Base):

    __tablename__ = "purchase_orders"


    id = Column(

        Integer,

        primary_key=True

    )


    po_number = Column(

        String(100),

        unique=True

    )


    vendor_name = Column(

        String(200)

    )


    material_name = Column(

        String(300)

    )


    quantity = Column(

        Float,

        default=0

    )


    amount = Column(

        Float,

        default=0

    )


    status = Column(

        String(50),

        default="Pending"

    )


    delivery_status = Column(

        String(50),

        default="Not Delivered"

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )