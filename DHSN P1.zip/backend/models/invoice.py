# ==========================================================
# INVOICE MODEL
# ==========================================================

from sqlalchemy import (
    Column,
    Integer,
    String,
    Float,
    DateTime
)

from datetime import datetime

from database.base import Base



class Invoice(Base):

    __tablename__ = " invoices"


    id = Column(

        Integer,

        primary_key=True

    )


    invoice_number = Column(

        String(100)

    )


    client_name = Column(

        String(200)

    )


    amount = Column(

        Float,

        default=0

    )


    gst_amount = Column(

        Float,

        default=0

    )


    status = Column(

        String(50),

        default="Pending"

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )