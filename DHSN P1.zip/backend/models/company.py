# ==========================================================
# COMPANY MODEL
# ==========================================================


from sqlalchemy import (

    Column,

    Integer,

    String,

    DateTime

)

from datetime import datetime

from database.base import Base



class Company(Base):


    __tablename__ = "companies"



    id = Column(

        Integer,

        primary_key=True

    )


    name = Column(

        String(200),

        nullable=False

    )


    gst_number = Column(

        String(50),

        nullable=True

    )


    industry = Column(

        String(100),

        default="Interior & Infrastructure"

    )


    website = Column(

        String(200),

        nullable=True

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )