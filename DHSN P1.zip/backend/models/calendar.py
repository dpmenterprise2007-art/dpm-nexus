# ==========================================================
# DPM NEXUS V9
# CALENDAR EVENT MODEL
# ==========================================================


from sqlalchemy import (

    Column,

    Integer,

    String,

    DateTime,

    Boolean

)

from datetime import datetime

from database.base import Base



class CalendarEvent(Base):

    __tablename__ = "calendar_events"


    id = Column(

        Integer,

        primary_key=True

    )


    title = Column(

        String(300),

        nullable=False

    )


    description = Column(

        String(1000)

    )


    event_type = Column(

        String(100),

        default="Meeting"

    )


    event_date = Column(

        String(50)

    )


    user_email = Column(

        String(200),

        nullable=True

    )


    reminder_sent = Column(

        Boolean,

        default=False

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )