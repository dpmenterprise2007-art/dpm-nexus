# ==========================================================
# VENDOR MODEL
# ==========================================================

from sqlalchemy import (
    Column,
    Integer,
    String,
    DateTime
)

from datetime import datetime

from database.base import Base



class Vendor(Base):

    __tablename__ = "vendors"


    id = Column(

        Integer,

        primary_key=True

    )


    vendor_name = Column(

        String(200)

    )


    category = Column(

        String(100)

    )


    contact = Column(

        String(100)

    )


    email = Column(

        String(200)

    )


    status = Column(

        String(50),

        default="Active"

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )