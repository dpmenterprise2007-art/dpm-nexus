# ==========================================================
# DPM NEXUS V9
# INVENTORY MODEL
# ==========================================================


from sqlalchemy import (

    Column,

    Integer,

    String,

    Float,

    DateTime

)

from datetime import datetime

from database.base import Base



class InventoryItem(Base):

    __tablename__ = "inventory_items"


    id = Column(

        Integer,

        primary_key=True

    )


    material_name = Column(

        String(300),

        nullable=False

    )


    category = Column(

        String(100)

    )


    unit = Column(

        String(50)

    )


    quantity = Column(

        Float,

        default=0

    )


    minimum_stock = Column(

        Float,

        default=0

    )


    warehouse = Column(

        String(200)

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )