# ==========================================================
# DPM NEXUS V9
# TASK MODEL
# ==========================================================


from sqlalchemy import (

    Column,

    Integer,

    String,

    DateTime

)

from datetime import datetime

from database.base import Base



class Task(Base):

    __tablename__ = "tasks"


    id = Column(

        Integer,

        primary_key=True

    )


    title = Column(

        String(300),

        nullable=False

    )


    description = Column(

        String(1000)

    )


    project_id = Column(

        Integer,

        nullable=True

    )


    assigned_to = Column(

        String(200),

        nullable=True

    )


    priority = Column(

        String(50),

        default="Medium"

    )


    status = Column(

        String(50),

        default="Pending"

    )


    due_date = Column(

        String(50),

        nullable=True

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )