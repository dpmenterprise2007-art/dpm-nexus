# ==========================================================
# BOQ MODEL
# ==========================================================

from sqlalchemy import (
    Column,
    Integer,
    String,
    Float,
    DateTime
)

from datetime import datetime

from database.base import Base



class BOQItem(Base):

    __tablename__ = "boq_items"


    id = Column(

        Integer,

        primary_key=True

    )


    project_id = Column(

        Integer

    )


    item_name = Column(

        String(300)

    )


    quantity = Column(

        Float,

        default=0

    )


    unit = Column(

        String(50)

    )


    rate = Column(

        Float,

        default=0

    )


    amount = Column(

        Float,

        default=0

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )

