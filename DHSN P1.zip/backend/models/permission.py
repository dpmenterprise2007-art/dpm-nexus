# ==========================================================
# DPM NEXUS V9
# PERMISSION MODEL
# ==========================================================


from sqlalchemy import (

    Column,

    Integer,

    String

)

from database.base import Base



class Permission(Base):

    __tablename__ = "permissions"


    id = Column(

        Integer,

        primary_key=True

    )


    module = Column(

        String(100)

    )


    action = Column(

        String(100)

    )


    description = Column(

        String(300)

    )