# ==========================================================
# DPM NEXUS V9
# DIRECTOR KPI MODEL
# ==========================================================


from sqlalchemy import (

    Column,

    Integer,

    String,

    Float,

    DateTime

)

from datetime import datetime

from database.base import Base



class DirectorKPI(Base):

    __tablename__ = "director_kpi"


    id = Column(

        Integer,

        primary_key=True

    )


    metric_name = Column(

        String(200)

    )


    metric_value = Column(

        Float,

        default=0

    )


    category = Column(

        String(100)

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )