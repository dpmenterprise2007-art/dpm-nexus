# ==========================================================
# DPM NEXUS V9
# NOTIFICATION MODEL
# ==========================================================


from sqlalchemy import (

    Column,
    Integer,
    String,
    Boolean,
    DateTime

)

from datetime import datetime

from database.base import Base



class Notification(Base):

    __tablename__ = "notifications"


    id = Column(

        Integer,

        primary_key=True

    )


    user_email = Column(

        String(200),

        nullable=True

    )


    title = Column(

        String(300),

        nullable=False

    )


    message = Column(

        String(1000),

        nullable=False

    )


    category = Column(

        String(100),

        default="System"

    )


    is_read = Column(

        Boolean,

        default=False

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )