# ==========================================================
# DPM NEXUS V9
# NOTIFICATION ROUTER
# ==========================================================


from fastapi import (

    APIRouter,
    Depends

)


from sqlalchemy.orm import Session


from database.connection import get_db


from models.notification import Notification



router = APIRouter(

    prefix="/api/notifications",

    tags=["Notification Engine"]

)



# ==========================================================
# GET NOTIFICATIONS
# ==========================================================


@router.get("/list")

async def get_notifications(

    db: Session = Depends(get_db)

):


    notifications = db.query(

        Notification

    ).order_by(

        Notification.created_at.desc()

    ).all()



    return {

        "success": True,

        "count": len(notifications),

        "data": notifications

    }



# ==========================================================
# CREATE NOTIFICATION
# ==========================================================


@router.post("/create")

async def create_notification(

    title: str,

    message: str,

    category: str = "System",

    user_email: str = None,

    db: Session = Depends(get_db)

):


    notification = Notification(

        title=title,

        message=message,

        category=category,

        user_email=user_email

    )


    db.add(notification)

    db.commit()

    db.refresh(notification)



    return {

        "success": True,

        "message": "Notification Created",

        "id": notification.id

    }



# ==========================================================
# MARK AS READ
# ==========================================================


@router.put("/{notification_id}/read")

async def mark_read(

    notification_id: int,

    db: Session = Depends(get_db)

):


    notification = db.query(

        Notification

    ).filter(

        Notification.id == notification_id

    ).first()



    if not notification:


        return {

            "success": False,

            "message": "Notification Not Found"

        }



    notification.is_read = True


    db.commit()



    return {

        "success": True,

        "message": "Marked As Read"

    }



# ==========================================================
# UNREAD COUNT
# ==========================================================


@router.get("/count")

async def unread_count(

    db: Session = Depends(get_db)

):


    count = db.query(

        Notification

    ).filter(

        Notification.is_read == False

    ).count()



    return {

        "success": True,

        "unread": count

    }