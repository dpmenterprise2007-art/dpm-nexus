# ==========================================================
# DPM NEXUS V9
# CALENDAR ROUTER
# ==========================================================


from fastapi import (

    APIRouter,

    Depends

)


from sqlalchemy.orm import Session


from database.connection import get_db


from models.calendar import CalendarEvent



router = APIRouter(

    prefix="/api/calendar",

    tags=["Calendar OS"]

)



# ==========================================================
# LIST EVENTS
# ==========================================================


@router.get("/events")

async def get_events(

    db: Session = Depends(get_db)

):


    events = db.query(

        CalendarEvent

    ).all()



    return {


        "success": True,


        "count": len(events),


        "data": events

    }



# ==========================================================
# CREATE EVENT
# ==========================================================


@router.post("/create")

async def create_event(

    title: str,

    event_date: str,

    event_type: str = "Meeting",

    description: str = "",

    user_email: str = None,

    db: Session = Depends(get_db)

):


    event = CalendarEvent(

        title=title,

        event_date=event_date,

        event_type=event_type,

        description=description,

        user_email=user_email

    )


    db.add(event)

    db.commit()

    db.refresh(event)



    return {


        "success": True,


        "message": "Event Created",


        "event_id": event.id

    }



# ==========================================================
# UPCOMING EVENTS
# ==========================================================


@router.get("/upcoming")

async def upcoming_events(

    db: Session = Depends(get_db)

):


    events = db.query(

        CalendarEvent

    ).filter(

        CalendarEvent.reminder_sent == False

    ).all()



    return {


        "success": True,


        "upcoming": events

    }