# ==========================================================
# DPM NEXUS V9
# DIRECTOR CONSOLE ROUTER
# ==========================================================


from fastapi import (

    APIRouter,

    Depends

)

from sqlalchemy.orm import Session


from database.connection import get_db


from models.director import DirectorKPI



router = APIRouter(

    prefix="/api/director",

    tags=["Director Console"]

)



# ==========================================================
# DIRECTOR DASHBOARD
# ==========================================================


@router.get("/dashboard")

async def director_dashboard(

    db: Session = Depends(get_db)

):


    kpis = db.query(

        DirectorKPI

    ).all()



    return {


        "success": True,


        "dashboard": {


            "company": "DPM ENTERPRISE PRIVATE LIMITED",


            "edition": "Director Command Center",


            "kpis": kpis


        }

    }



# ==========================================================
# ADD KPI
# ==========================================================


@router.post("/kpi/create")

async def create_kpi(

    metric_name: str,

    metric_value: float,

    category: str,

    db: Session = Depends(get_db)

):


    kpi = DirectorKPI(

        metric_name=metric_name,

        metric_value=metric_value,

        category=category

    )


    db.add(kpi)

    db.commit()

    db.refresh(kpi)



    return {


        "success": True,


        "message": "KPI Created",


        "id": kpi.id

    }



# ==========================================================
# BUSINESS INTELLIGENCE SUMMARY
# ==========================================================


@router.get("/business-summary")

async def business_summary():


    return {


        "success": True,


        "company": "DPM ENTERPRISE PRIVATE LIMITED",


        "insights": {


            "project_growth": "Tracking",


            "revenue_analysis": "Active",


            "tender_pipeline": "Active",


            "ai_prediction": "Ready"

        }

    }



# ==========================================================
# AI BUSINESS INSIGHT PLACEHOLDER
# ==========================================================


@router.get("/ai-insight")

async def ai_insight():


    return {


        "success": True,


        "message": "Director AI Intelligence Layer Ready"

    }