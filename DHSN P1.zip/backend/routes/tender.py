# ==========================================================
# DPM NEXUS V9
# TENDER ENGINE ROUTER
# ==========================================================


from fastapi import (
    APIRouter,
    Depends
)

from sqlalchemy.orm import Session

from database.connection import get_db

from models.tender import Tender



router = APIRouter(

    prefix="/api/tender",

    tags=["Tender Engine"]

)



# ==========================================================
# GET ALL TENDERS
# ==========================================================


@router.get("/list")

async def get_tenders(

    db: Session = Depends(get_db)

):


    tenders = db.query(

        Tender

    ).all()



    return {

        "success": True,

        "count": len(tenders),

        "data": tenders

    }



# ==========================================================
# CREATE TENDER
# ==========================================================


@router.post("/create")

async def create_tender(

    tender_number: str,

    title: str,

    department: str,

    location: str,

    db: Session = Depends(get_db)

):


    tender = Tender(

        tender_number=tender_number,

        title=title,

        department=department,

        location=location

    )


    db.add(tender)

    db.commit()

    db.refresh(tender)



    return {

        "success": True,

        "message": "Tender Created",

        "tender_id": tender.id

    }



# ==========================================================
# UPDATE TENDER STATUS
# ==========================================================


@router.put("/{tender_id}/status")

async def update_status(

    tender_id: int,

    status: str,

    db: Session = Depends(get_db)

):


    tender = db.query(

        Tender

    ).filter(

        Tender.id == tender_id

    ).first()



    if not tender:


        return {

            "success": False,

            "message": "Tender Not Found"

        }



    tender.status = status


    db.commit()



    return {

        "success": True,

        "message": "Tender Status Updated",

        "status": status

    }



# ==========================================================
# TENDER SEARCH
# ==========================================================

@router.get("/search")

async def search_tender(

    keyword: str,

    db: Session = Depends(get_db)

):


    result = db.query(

        Tender

    ).filter(

        Tender.title.contains(keyword)

    ).all()



    return {

        "success": True,

        "keyword": keyword,

        "results": result

    }



# ==========================================================
# AI TENDER ANALYSIS PLACEHOLDER
# ==========================================================

@router.post("/{tender_id}/analyze")

async def analyze_tender(

    tender_id: int

):


    return {

        "success": True,

        "message":

        "AI Tender Analysis Engine Ready",

        "tender_id": tender_id

    }