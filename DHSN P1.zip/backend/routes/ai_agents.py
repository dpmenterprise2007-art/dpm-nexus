# ==========================================================
# DPM NEXUS V9
# AI AGENT ROUTER
# ==========================================================


from fastapi import APIRouter


from agents.boq_agent import analyze_boq

from agents.tender_agent import analyze_tender

from agents.crm_agent import qualify_lead



router = APIRouter(

    prefix="/api/agents",

    tags=["AI Agents"]

)



# ==========================================================
# BOQ AI
# ==========================================================


@router.post("/boq")

async def boq_ai(data: dict):


    return analyze_boq(

        data

    )



# ==========================================================
# TENDER AI
# ==========================================================


@router.post("/tender")

async def tender_ai(data: dict):


    return analyze_tender(

        data

    )



# ==========================================================
# CRM AI
# ==========================================================


@router.post("/crm")

async def crm_ai(data: dict):


    return qualify_lead(

        data

    )