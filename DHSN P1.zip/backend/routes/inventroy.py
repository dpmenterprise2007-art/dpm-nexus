# ==========================================================
# DPM NEXUS V9
# INVENTORY ROUTER
# ==========================================================


from fastapi import (

    APIRouter,

    Depends

)

from sqlalchemy.orm import Session


from database.connection import get_db


from models.inventory import InventoryItem



router = APIRouter(

    prefix="/api/inventory",

    tags=["Inventory OS"]

)



# ==========================================================
# LIST MATERIAL
# ==========================================================


@router.get("/items")

async def list_items(

    db: Session = Depends(get_db)

):


    items = db.query(

        InventoryItem

    ).all()



    return {


        "success": True,


        "count": len(items),


        "data": items

    }



# ==========================================================
# CREATE MATERIAL
# ==========================================================


@router.post("/create")

async def create_material(

    material_name: str,

    category: str,

    unit: str,

    quantity: float,

    warehouse: str,

    db: Session = Depends(get_db)

):


    item = InventoryItem(

        material_name=material_name,

        category=category,

        unit=unit,

        quantity=quantity,

        warehouse=warehouse

    )


    db.add(item)

    db.commit()

    db.refresh(item)



    return {


        "success": True,


        "message": "Material Added",


        "id": item.id

    }



# ==========================================================
# LOW STOCK ALERT
# ==========================================================


@router.get("/low-stock")

async def low_stock(

    db: Session = Depends(get_db)

):


    items = db.query(

        InventoryItem

    ).filter(

        InventoryItem.quantity <= InventoryItem.minimum_stock

    ).all()



    return {


        "success": True,


        "low_stock_items": items

    }