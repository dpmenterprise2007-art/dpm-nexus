# ==========================================================
# DPM NEXUS V9
# PERMISSIONS ROUTE
# ==========================================================

from fastapi import APIRouter


router = APIRouter(

    prefix="/api/permissions",

    tags=["Permissions"]

)


@router.get("/")
async def permissions_home():

    return {

        "module": "Permissions",

        "status": "active",

        "version": "V9"

    }


@router.get("/roles")
async def roles():

    return {

        "roles": [

            "Director",

            "Admin",

            "Manager",

            "Employee",

            "Client"

        ]

    }