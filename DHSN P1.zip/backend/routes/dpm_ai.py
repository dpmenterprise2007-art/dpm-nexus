from fastapi import APIRouter
from pydantic import BaseModel

from ai_engine.response import generate_response


router = APIRouter()



class AIRequest(BaseModel):

    message: str




@router.post("/chat")
def dpm_ai_chat(
    data: AIRequest
):

    reply = generate_response(
        data.message
    )


    return {

        "success": True,

        "reply": reply

    }