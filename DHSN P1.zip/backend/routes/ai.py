from fastapi import APIRouter, HTTPException
from schemas.ai_schema import ChatRequest, SimpleRequest
from services.ai_service import (
    run_general_ai,
    run_boq_ai,
    run_invoice_ai,
    run_tender_ai,
    run_proposal_ai,
    run_lead_ai,
    run_scope_ai,
)

router = APIRouter(prefix="/api/ai", tags=["DPM Nexus AI"])


@router.get("/health")
async def ai_health():
    return {
        "success": True,
        "service": "DPM Nexus AI",
        "status": "online"
    }


@router.post("/chat")
async def ai_chat(payload: ChatRequest):
    try:
        tool = (payload.tool or "general").lower()
        model = payload.model or "gpt-4.1-mini"

        if tool == "boq":
            reply = run_boq_ai(payload.message, model)
        elif tool == "invoice":
            reply = run_invoice_ai(payload.message, model)
        elif tool == "tender":
            reply = run_tender_ai(payload.message, model)
        elif tool == "proposal":
            reply = run_proposal_ai(payload.message, model)
        elif tool == "lead":
            reply = run_lead_ai(payload.message, model)
        elif tool == "scope":
            reply = run_scope_ai(payload.message, model)
        else:
            reply = run_general_ai(payload.message, model)

        return {
            "success": True,
            "tool": tool,
            "model": model,
            "reply": reply
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DPM Nexus AI Error: {str(e)}")


@router.post("/boq")
async def boq_ai(payload: SimpleRequest):
    try:
        reply = run_boq_ai(payload.prompt, payload.model)
        return {"success": True, "tool": "boq", "reply": reply}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/invoice")
async def invoice_ai(payload: SimpleRequest):
    try:
        reply = run_invoice_ai(payload.prompt, payload.model)
        return {"success": True, "tool": "invoice", "reply": reply}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/tender")
async def tender_ai(payload: SimpleRequest):
    try:
        reply = run_tender_ai(payload.prompt, payload.model)
        return {"success": True, "tool": "tender", "reply": reply}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/proposal")
async def proposal_ai(payload: SimpleRequest):
    try:
        reply = run_proposal_ai(payload.prompt, payload.model)
        return {"success": True, "tool": "proposal", "reply": reply}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/lead")
async def lead_ai(payload: SimpleRequest):
    try:
        reply = run_lead_ai(payload.prompt, payload.model)
        return {"success": True, "tool": "lead", "reply": reply}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/scope")
async def scope_ai(payload: SimpleRequest):
    try:
        reply = run_scope_ai(payload.prompt, payload.model)
        return {"success": True, "tool": "scope", "reply": reply}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))