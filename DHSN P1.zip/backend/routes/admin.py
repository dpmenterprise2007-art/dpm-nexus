# ==========================================================
# DPM NEXUS V9
# ADMIN CONSOLE ROUTER
# ==========================================================


from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from database.connection import get_db

from models.admin import AdminAction



router = APIRouter(

    prefix="/api/admin",

    tags=["Admin Console"]

)



# ==========================================================
# ADMIN DASHBOARD
# ==========================================================


@router.get("/dashboard")

async def admin_dashboard(

    db: Session = Depends(get_db)

):


    total_actions = db.query(

        AdminAction

    ).count()



    return {


        "success": True,


        "system": "DPM Nexus V9",


        "total_admin_actions": total_actions,


        "modules": {


            "CRM": "Active",

            "BOQ": "Active",

            "Tender": "Active",

            "Projects": "Active",

            "Finance": "Active",

            "HRMS": "Active"

        }

    }



# ==========================================================
# CREATE ADMIN ACTION
# ==========================================================


@router.post("/action")

async def create_admin_action(

    admin_email: str,

    action: str,

    module: str,

    db: Session = Depends(get_db)

):


    record = AdminAction(

        admin_email=admin_email,

        action=action,

        module=module

    )


    db.add(record)

    db.commit()

    db.refresh(record)



    return {


        "success": True,


        "message": "Admin Action Saved",


        "id": record.id

    }



# ==========================================================
# SYSTEM MODULE STATUS
# ==========================================================


@router.get("/modules")

async def module_status():


    return {


        "success": True,


        "modules": {


            "AI Engine": True,

            "CRM": True,

            "BOQ Engine": True,

            "Tender Engine": True,

            "Project OS": True,

            "Finance OS": True,

            "HRMS": True,

            "Document Vault": True

        }

    }