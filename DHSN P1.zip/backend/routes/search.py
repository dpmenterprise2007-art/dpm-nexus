# ==========================================================
# DPM NEXUS V9
# GLOBAL SEARCH ROUTER
# ==========================================================


from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from database.connection import get_db


from models.crm import CRMLead

from models.project import Project

from models.vendor import Vendor

from models.tender import Tender

from models.boq import BOQItem



router = APIRouter(

    prefix="/api/search",

    tags=["Global Search"]

)



# ==========================================================
# UNIVERSAL SEARCH
# ==========================================================


@router.get("/global")

async def global_search(

    keyword: str,

    db: Session = Depends(get_db)

):


    results = {

        "crm": [],

        "projects": [],

        "vendors": [],

        "tenders": [],

        "boq": []

    }



    # CRM Search

    results["crm"] = db.query(

        CRMLead

    ).filter(

        CRMLead.company_name.contains(keyword)

    ).all()



    # Project Search

    results["projects"] = db.query(

        Project

    ).filter(

        Project.project_name.contains(keyword)

    ).all()



    # Vendor Search

    results["vendors"] = db.query(

        Vendor

    ).filter(

        Vendor.vendor_name.contains(keyword)

    ).all()



    # Tender Search

    results["tenders"] = db.query(

        Tender

    ).filter(

        Tender.title.contains(keyword)

    ).all()



    # BOQ Search

    results["boq"] = db.query(

        BOQItem

    ).filter(

        BOQItem.item_name.contains(keyword)

    ).all()



    return {


        "success": True,


        "keyword": keyword,


        "results": results

    }



# ==========================================================
# SEARCH STATUS
# ==========================================================


@router.get("/status")

async def search_status():


    return {


        "success": True,


        "engine": "DPM Global Search",


        "status": "Online"


    }