from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/api/ai", tags=["Video AI"])


class VideoRequest(BaseModel):
    prompt: str


@router.post("/video")
async def generate_video(data: VideoRequest):
    try:
        # Placeholder system (future AI video integration)
        return {
            "success": True,
            "status": "queued",
            "message": "Video generation pipeline ready (not active API yet)",
            "prompt": data.prompt
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))