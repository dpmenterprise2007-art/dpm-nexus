# ==========================================================
# DPM NEXUS V9
# ANALYTICS ROUTER
# ==========================================================


from fastapi import (

    APIRouter,

    Depends

)

from sqlalchemy.orm import Session


from database.connection import get_db


from models.analytics import AnalyticsKPI



router = APIRouter(

    prefix="/api/analytics",

    tags=["Analytics"]

)



# ==========================================================
# KPI LIST
# ==========================================================


@router.get("/kpi")

async def get_kpi(

    db: Session = Depends(get_db)

):


    kpis = db.query(

        AnalyticsKPI

    ).all()



    return {


        "success": True,


        "count": len(kpis),


        "data": kpis

    }



# ==========================================================
# CREATE KPI
# ==========================================================


@router.post("/kpi/create")

async def create_kpi(

    metric_name: str,

    metric_value: float,

    category: str,

    period: str,

    db: Session = Depends(get_db)

):


    kpi = AnalyticsKPI(

        metric_name=metric_name,

        metric_value=metric_value,

        category=category,

        period=period

    )


    db.add(kpi)

    db.commit()

    db.refresh(kpi)



    return {


        "success": True,


        "message": "KPI Created",


        "id": kpi.id

    }



# ==========================================================
# BUSINESS DASHBOARD
# ==========================================================


@router.get("/dashboard")

async def analytics_dashboard(

    db: Session = Depends(get_db)

):


    total = db.query(

        AnalyticsKPI

    ).count()



    return {


        "success": True,


        "dashboard": {


            "system": "DPM Business Intelligence",


            "total_metrics": total,


            "modules": {


                "Projects": "Active",

                "Finance": "Active",

                "Tender": "Active",

                "CRM": "Active"

            }

        }

    }



# ==========================================================
# REPORT EXPORT READY
# ==========================================================


@router.get("/reports")

async def reports():


    return {


        "success": True,


        "available_reports": [


            "Project Report",

            "Finance Report",

            "Tender Report",

            "CRM Report",

            "Vendor Report"

        ]

    }