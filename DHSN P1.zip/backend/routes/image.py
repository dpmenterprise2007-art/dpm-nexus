import os
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from openai import OpenAI

router = APIRouter(prefix="/api/ai", tags=["Image AI"])

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


class ImageRequest(BaseModel):
    prompt: str
    size: str = "1024x1024"


@router.post("/image")
async def generate_image(data: ImageRequest):
    try:
        result = client.images.generate(
            model="gpt-image-1",
            prompt=data.prompt,
            size=data.size
        )

        image_base64 = result.data[0].b64_json

        return {
            "success": True,
            "image": image_base64
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))