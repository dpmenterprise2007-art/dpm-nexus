# ==========================================================
# DPM NEXUS V9
# VENDOR NETWORK ROUTER
# ==========================================================


from fastapi import (
    APIRouter,
    Depends
)

from sqlalchemy.orm import Session

from database.connection import get_db

from models.vendor import Vendor



router = APIRouter(

    prefix="/api/vendors",

    tags=["Vendor Network"]

)



# ==========================================================
# GET ALL VENDORS
# ==========================================================


@router.get("/list")

async def get_vendors(

    db: Session = Depends(get_db)

):


    vendors = db.query(

        Vendor

    ).all()



    return {

        "success": True,

        "count": len(vendors),

        "data": vendors

    }



# ==========================================================
# CREATE VENDOR
# ==========================================================


@router.post("/create")

async def create_vendor(

    vendor_name: str,

    category: str,

    contact: str,

    email: str,

    db: Session = Depends(get_db)

):


    vendor = Vendor(

        vendor_name=vendor_name,

        category=category,

        contact=contact,

        email=email

    )


    db.add(vendor)

    db.commit()

    db.refresh(vendor)



    return {

        "success": True,

        "message": "Vendor Created",

        "vendor_id": vendor.id

    }



# ==========================================================
# UPDATE VENDOR STATUS
# ==========================================================


@router.put("/{vendor_id}/status")

async def update_vendor_status(

    vendor_id: int,

    status: str,

    db: Session = Depends(get_db)

):


    vendor = db.query(

        Vendor

    ).filter(

        Vendor.id == vendor_id

    ).first()



    if not vendor:


        return {

            "success": False,

            "message": "Vendor Not Found"

        }



    vendor.status = status


    db.commit()



    return {

        "success": True,

        "message": "Vendor Status Updated",

        "status": status

    }



# ==========================================================
# SEARCH VENDOR
# ==========================================================


@router.get("/search")

async def search_vendor(

    keyword: str,

    db: Session = Depends(get_db)

):


    vendors = db.query(

        Vendor

    ).filter(

        Vendor.vendor_name.contains(keyword)

    ).all()



    return {

        "success": True,

        "keyword": keyword,

        "results": vendors

    }



# ==========================================================
# VENDOR CATEGORY FILTER
# ==========================================================


@router.get("/category/{category}")

async def vendor_category(

    category: str,

    db: Session = Depends(get_db)

):


    vendors = db.query(

        Vendor

    ).filter(

        Vendor.category == category

    ).all()



    return {

        "success": True,

        "category": category,

        "data": vendors

    }



# ==========================================================
# VENDOR DASHBOARD
# ==========================================================


@router.get("/dashboard")

async def vendor_dashboard(

    db: Session = Depends(get_db)

):


    total = db.query(

        Vendor

    ).count()



    active = db.query(

        Vendor

    ).filter(

        Vendor.status == "Active"

    ).count()



    return {

        "success": True,

        "total_vendors": total,

        "active_vendors": active

    }