# ==========================================================
# DPM NEXUS V9
# CRM API ROUTER
# ==========================================================


from fastapi import (
    APIRouter,
    Depends
)

from sqlalchemy.orm import Session

from database.connection import get_db

from models.crm import CRMLead


router = APIRouter(

    prefix="/api/crm",

    tags=["CRM"]

)


# ==========================================================
# GET ALL LEADS
# ==========================================================


@router.get("/leads")

async def get_leads(

    db: Session = Depends(get_db)

):

    leads = db.query(

        CRMLead

    ).all()


    return {

        "success": True,

        "count": len(leads),

        "data": leads

    }



# ==========================================================
# CREATE LEAD
# ==========================================================


@router.post("/lead")

async def create_lead(

    company_name: str,

    contact_person: str,

    email: str,

    phone: str,

    db: Session = Depends(get_db)

):


    lead = CRMLead(

        company_name=company_name,

        contact_person=contact_person,

        email=email,

        phone=phone

    )


    db.add(lead)

    db.commit()

    db.refresh(lead)



    return {

        "success": True,

        "message": "Lead Created",

        "id": lead.id

    }