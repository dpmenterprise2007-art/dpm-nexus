# ==========================================================
# DPM NEXUS V9
# AUDIT ROUTER
# ==========================================================


from fastapi import (

    APIRouter,

    Depends,

    Request

)

from sqlalchemy.orm import Session


from database.connection import get_db


from models.audit import AuditLog



router = APIRouter(

    prefix="/api/audit",

    tags=["Audit System"]

)



# ==========================================================
# GET AUDIT LOGS
# ==========================================================


@router.get("/logs")

async def get_logs(

    db: Session = Depends(get_db)

):


    logs = db.query(

        AuditLog

    ).order_by(

        AuditLog.created_at.desc()

    ).all()



    return {

        "success": True,

        "count": len(logs),

        "data": logs

    }



# ==========================================================
# CREATE AUDIT LOG
# ==========================================================


@router.post("/create")

async def create_log(

    request: Request,

    module: str,

    action: str,

    description: str,

    user_email: str = None,

    db: Session = Depends(get_db)

):


    log = AuditLog(

        user_email=user_email,

        module=module,

        action=action,

        description=description,

        ip_address=request.client.host

    )


    db.add(log)

    db.commit()

    db.refresh(log)



    return {

        "success": True,

        "message": "Audit Created",

        "id": log.id

    }



# ==========================================================
# MODULE ACTIVITY
# ==========================================================


@router.get("/module/{module_name}")

async def module_logs(

    module_name: str,

    db: Session = Depends(get_db)

):


    logs = db.query(

        AuditLog

    ).filter(

        AuditLog.module == module_name

    ).all()



    return {

        "success": True,

        "module": module_name,

        "data": logs

    }