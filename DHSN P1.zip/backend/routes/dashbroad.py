from fastapi import APIRouter, Request
from datetime import datetime
import random

router = APIRouter(
    prefix="/api/dashboard",
    tags=["Dashboard"]
)

# =========================
# LIVE KPI (REAL-TIME MOCK)
# =========================

@router.get("/kpi")
async def get_kpi():

    return {
        "active_leads": random.randint(200, 350),
        "open_tenders": random.randint(30, 80),
        "running_projects": random.randint(50, 120),
        "revenue": f"{round(random.uniform(10, 25), 2)} Cr",
        "clients": random.randint(200, 500),
        "vendors": random.randint(80, 200)
    }


# =========================
# EXECUTIVE SUMMARY
# =========================

@router.get("/summary")
async def summary():

    return {
        "today_leads": random.randint(1, 10),
        "today_tenders": random.randint(1, 5),
        "pending_boq": random.randint(2, 12),
        "alerts": random.randint(0, 3)
    }


# =========================
# NOTIFICATIONS STREAM
# =========================

@router.get("/notifications")
async def notifications():

    return [
        {
            "type": "lead",
            "message": "New High Value Lead Received"
        },
        {
            "type": "tender",
            "message": "New Government Tender Published"
        },
        {
            "type": "boq",
            "message": "BOQ Approval Pending from Client"
        },
        {
            "type": "project",
            "message": "Project Milestone Completed"
        }
    ]


# =========================
# PROJECT STATUS LIVE
# =========================

@router.get("/projects")
async def projects():

    return [
        {
            "name": "Mumbai Corporate Office",
            "progress": random.randint(60, 95)
        },
        {
            "name": "Showroom Interior Project",
            "progress": random.randint(40, 90)
        },
        {
            "name": "Luxury Villa Project",
            "progress": random.randint(70, 99)
        }
    ]


# =========================
# CRM SNAPSHOT
# =========================

@router.get("/crm")
async def crm():

    return {
        "new_leads": random.randint(2, 15),
        "converted": random.randint(1, 10),
        "pipeline_value": f"{round(random.uniform(5, 30), 2)} Cr"
    }


# =========================
# FINANCE SNAPSHOT
# =========================

@router.get("/finance")
async def finance():

    return {
        "monthly_revenue": f"{round(random.uniform(8, 20), 2)} Cr",
        "expenses": f"{round(random.uniform(2, 8), 2)} Cr",
        "profit": f"{round(random.uniform(4, 12), 2)} Cr"
    }


# =========================
# USER PROFILE (GOOGLE LOGIN)
# =========================

@router.get("/profile")
async def profile(request: Request):

    user = request.session.get("user")

    if not user:
        return {
            "error": "not logged in"
        }

    return user


# =========================
# SYSTEM STATUS
# =========================

@router.get("/status")
async def status():

    return {
        "platform": "DPM AI OS",
        "version": "V5 REAL TIME",
        "status": "ONLINE",
        "server_time": datetime.now().isoformat()
    }