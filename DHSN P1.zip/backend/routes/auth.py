"""
DPM Nexus V9 - Registration / MSG91 SecureOTP Authentication
-------------------------------------------------
Production-safe registration flow:
    1. Validate and check existing email/mobile.
    2. Send OTP by email only.
    3. Verify Email OTP.
    4. Create the user only after OTP verification.

Compatibility:
    Accepts snake_case, camelCase, and common legacy field names from
    older register.html/register.js versions so frontend/backend changes
    do not break the registration flow.

Existing users are never deleted or modified by this module.
"""

from __future__ import annotations

import logging
import secrets
import os
import json
from urllib.request import Request as URLRequest, urlopen
from urllib.error import HTTPError, URLError
from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import (
    AliasChoices,
    BaseModel,
    ConfigDict,
    EmailStr,
    Field,
    field_validator,
)
from sqlalchemy import func
from sqlalchemy.orm import Session

from database.connection import get_db
from models.user import User
from auth.password import hash_password
from utils.email import send_otp_email

router = APIRouter(prefix="/auth", tags=["Authentication"])
logger = logging.getLogger("DPM-Nexus-Auth")

OTP_TTL_SECONDS = 5 * 60
OTP_RESEND_COOLDOWN_SECONDS = 60
OTP_MAX_ATTEMPTS = 5
OTP_MAX_RESENDS = 5

# Runtime store. This does not touch existing database records.
otp_store: dict[str, dict] = {}


# ---------------------------------------------------------------------------
# Normalisation helpers
# ---------------------------------------------------------------------------

def normalize_email(value: str) -> str:
    return str(value).strip().lower()


def normalize_phone(value: str) -> str:
    digits = "".join(ch for ch in str(value or "") if ch.isdigit())

    if digits.startswith("91") and len(digits) == 12:
        digits = digits[2:]

    if len(digits) != 10:
        raise ValueError("Please enter a valid 10 digit mobile number.")

    return digits


def normalize_method(value: str | None) -> str:
    value = (value or "email").strip().lower()
    aliases = {
        "email": "email", "email_otp": "email", "emailotp": "email", "mail": "email",
        "sms": "sms", "mobile": "sms", "phone": "sms", "mobile_otp": "sms", "sms_otp": "sms",
    }
    if value not in aliases:
        raise ValueError("delivery_method must be 'email' or 'sms'.")
    return aliases[value]


def verify_msg91_access_token(access_token: str) -> str:
    """Validate a MSG91 OTP Widget token and return its verified identifier."""
    authkey = (os.getenv("MSG91_AUTHKEY") or os.getenv("MSG91_AUTH_KEY") or "").strip()
    if not authkey:
        raise HTTPException(status_code=503, detail="MSG91 server verification is not configured. Add MSG91_AUTHKEY to backend/.env.")
    token = str(access_token or "").strip()
    if not token or len(token) > 8192:
        raise HTTPException(status_code=400, detail="A valid MSG91 access token is required.")
    payload = json.dumps({"authkey": authkey, "access-token": token}).encode("utf-8")
    req = URLRequest("https://control.msg91.com/api/v5/widget/verifyAccessToken", data=payload,
                     headers={"Accept": "application/json", "Content-Type": "application/json"}, method="POST")
    try:
        with urlopen(req, timeout=20) as response:
            result = json.loads(response.read().decode("utf-8", errors="replace") or "{}")
    except HTTPError as exc:
        logger.warning("MSG91 token verification HTTP error %s: %s", exc.code, exc.read().decode(errors="ignore")[:300])
        raise HTTPException(status_code=502, detail="MSG91 could not validate the OTP access token.") from exc
    except (URLError, TimeoutError) as exc:
        logger.exception("MSG91 token verification connection failed")
        raise HTTPException(status_code=502, detail="Could not connect to MSG91 for OTP verification.") from exc
    except (ValueError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=502, detail="MSG91 returned an unreadable verification response.") from exc
    if not isinstance(result, dict) or str(result.get("type", "")).lower() != "success":
        logger.warning("MSG91 access-token verification rejected: %s", str(result)[:300])
        raise HTTPException(status_code=403, detail="MSG91 OTP verification failed. Please verify the OTP again.")
    identifier = str(result.get("message") or result.get("identifier") or "").strip()
    if not identifier:
        raise HTTPException(status_code=502, detail="MSG91 did not return the verified identifier.")
    return identifier


def otp_key(method: str, destination: str) -> str:
    return f"{method}:{destination}"


def duplicate_status(
    db: Session,
    email: str,
    phone: str,
) -> tuple[bool, bool]:

    email_exists = (
        db.query(User.id)
        .filter(func.lower(User.email) == normalize_email(email))
        .first()
        is not None
    )

    phone_exists = (
        db.query(User.id)
        .filter(User.phone == phone)
        .first()
        is not None
    )

    return email_exists, phone_exists


def duplicate_message(
    email_exists: bool,
    phone_exists: bool,
) -> str | None:

    if email_exists and phone_exists:
        return "This email and mobile number are already registered."

    if email_exists:
        return "This email is already registered."

    if phone_exists:
        return "This mobile number is already registered."

    return None


def raise_if_duplicate(
    email_exists: bool,
    phone_exists: bool,
) -> None:

    message = duplicate_message(
        email_exists,
        phone_exists,
    )

    if message:
        raise HTTPException(
            status_code=409,
            detail=message,
        )


def get_verified_record(
    method: str,
    destination: str,
) -> dict | None:

    record = otp_store.get(
        otp_key(method, destination)
    )

    if not record:
        return None

    expires_at = record.get("expires_at")

    if not isinstance(expires_at, datetime):
        otp_store.pop(
            otp_key(method, destination),
            None,
        )
        return None

    if datetime.utcnow() > expires_at:
        otp_store.pop(
            otp_key(method, destination),
            None,
        )
        return None

    return record


def validate_and_normalize_otp(
    value: str,
) -> str:

    value = str(value or "").strip()

    if not value.isdigit() or len(value) != 6:
        raise ValueError(
            "OTP must contain exactly 6 digits."
        )

    return value


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------

class SendOTPRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, str_strip_whitespace=True)
    email: Optional[EmailStr] = Field(default=None, validation_alias=AliasChoices("email", "business_email", "businessEmail"))
    phone: Optional[str] = Field(default=None, validation_alias=AliasChoices("phone", "mobile", "mobile_number", "mobileNumber"))
    delivery_method: str = Field(default="email", validation_alias=AliasChoices("delivery_method", "deliveryMethod", "otp_method", "otpMethod", "method"))

    @field_validator("delivery_method")
    @classmethod
    def validate_method(cls, value: str) -> str:
        return normalize_method(value)


class VerifyOTPRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, str_strip_whitespace=True)
    email: Optional[EmailStr] = Field(default=None, validation_alias=AliasChoices("email", "business_email", "businessEmail"))
    phone: Optional[str] = Field(default=None, validation_alias=AliasChoices("phone", "mobile", "mobile_number", "mobileNumber"))
    otp: str = Field(min_length=6, max_length=6, validation_alias=AliasChoices("otp", "otp_code", "otpCode", "verification_otp", "verificationOtp"))
    delivery_method: str = Field(default="email", validation_alias=AliasChoices("delivery_method", "deliveryMethod", "otp_method", "otpMethod", "method"))

    @field_validator("delivery_method")
    @classmethod
    def validate_method(cls, value: str) -> str:
        return normalize_method(value)

    @field_validator("otp")
    @classmethod
    def validate_otp(cls, value: str) -> str:
        return validate_and_normalize_otp(value)


class RegisterRequest(BaseModel):

    model_config = ConfigDict(
        populate_by_name=True,
        str_strip_whitespace=True,
    )

    # Supports:
    # name / full_name / fullName
    name: str = Field(
        min_length=2,
        max_length=150,
        validation_alias=AliasChoices(
            "name",
            "full_name",
            "fullName",
            "full-name",
        ),
    )

    company_name: str = Field(
        min_length=2,
        max_length=200,
        validation_alias=AliasChoices(
            "company_name",
            "companyName",
            "company",
        ),
    )

    email: EmailStr = Field(
        validation_alias=AliasChoices(
            "email",
            "business_email",
            "businessEmail",
        ),
    )

    phone: str = Field(
        min_length=10,
        max_length=15,
        validation_alias=AliasChoices(
            "phone",
            "mobile",
            "mobile_number",
            "mobileNumber",
        ),
    )

    password: str = Field(
        min_length=8,
        max_length=128,
        validation_alias=AliasChoices(
            "password",
            "user_password",
        ),
    )

    # Optional after a successful /verify-otp call.
    # If supplied, it is also accepted for compatibility with older
    # register pages that submit the OTP again during final registration.
    otp: Optional[str] = Field(
        default=None,
        validation_alias=AliasChoices(
            "otp",
            "otp_code",
            "otpCode",
            "verification_otp",
            "verificationOtp",
        ),
    )
    email_otp: Optional[str] = Field(default=None, validation_alias=AliasChoices("email_otp", "emailOtp"))
    phone_otp: Optional[str] = Field(default=None, validation_alias=AliasChoices("phone_otp", "phoneOtp"))
    email_access_token: Optional[str] = Field(default=None, validation_alias=AliasChoices("email_access_token", "emailAccessToken"))
    phone_access_token: Optional[str] = Field(default=None, validation_alias=AliasChoices("phone_access_token", "phoneAccessToken"))

    delivery_method: str = Field(
        default="email",
        validation_alias=AliasChoices(
            "delivery_method",
            "deliveryMethod",
            "otp_method",
            "otpMethod",
            "method",
        ),
    )

    confirm_password: Optional[str] = Field(
        default=None,
        validation_alias=AliasChoices(
            "confirm_password",
            "confirmPassword",
            "password_confirmation",
        ),
    )

    @field_validator("delivery_method")
    @classmethod
    def validate_method(cls, value: str) -> str:
        return normalize_method(value)

    @field_validator("otp")
    @classmethod
    def validate_optional_otp(cls, value: Optional[str]) -> Optional[str]:
        if value in (None, ""):
            return None
        return validate_and_normalize_otp(value)

    @field_validator("phone")
    @classmethod
    def validate_phone_field(cls, value: str) -> str:
        try:
            return normalize_phone(value)
        except ValueError as exc:
            raise ValueError(str(exc)) from exc


# ---------------------------------------------------------------------------
# Availability
# ---------------------------------------------------------------------------

@router.post("/check-availability")
async def check_availability(
    email: EmailStr,
    phone: str,
    db: Session = Depends(get_db),
):

    try:
        normalized_phone = normalize_phone(phone)
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    email_exists, phone_exists = duplicate_status(
        db,
        normalize_email(str(email)),
        normalized_phone,
    )

    return {
        "success": True,
        "email_available": not email_exists,
        "phone_available": not phone_exists,
        "email_exists": email_exists,
        "phone_exists": phone_exists,
        "message": duplicate_message(
            email_exists,
            phone_exists,
        ),
    }


# ---------------------------------------------------------------------------
# Send OTP
# ---------------------------------------------------------------------------

@router.post("/send-otp")
async def send_otp(data: SendOTPRequest, db: Session = Depends(get_db)):
    method = data.delivery_method
    now = datetime.utcnow()
    if method == "email":
        if not data.email:
            raise HTTPException(status_code=400, detail="Email address is required.")
        destination = normalize_email(str(data.email))
        exists = db.query(User.id).filter(func.lower(User.email) == destination).first() is not None
    else:
        if not data.phone:
            raise HTTPException(status_code=400, detail="Mobile number is required.")
        try:
            destination = normalize_phone(data.phone)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        exists = db.query(User.id).filter(User.phone == destination).first() is not None
    if method == "email":
        raise_if_duplicate(exists, False)
    else:
        raise_if_duplicate(False, exists)
    key = otp_key(method, destination)
    existing = otp_store.get(key)
    if existing:
        last_sent = existing.get("last_sent")
        if isinstance(last_sent, datetime):
            elapsed = (now - last_sent).total_seconds()
            if elapsed < OTP_RESEND_COOLDOWN_SECONDS:
                raise HTTPException(status_code=429, detail=f"Please wait {max(1, int(OTP_RESEND_COOLDOWN_SECONDS-elapsed))} seconds before requesting another OTP.")
        if int(existing.get("resends", 0)) >= OTP_MAX_RESENDS:
            raise HTTPException(status_code=429, detail="OTP resend limit reached. Please try again later.")
    otp = f"{secrets.randbelow(1_000_000):06d}"
    if method == "sms":
        raise HTTPException(status_code=410, detail="Mobile OTP is sent through the MSG91 SecureOTP widget on the registration page.")
    delivered = send_otp_email(destination, otp)
    message = "Email OTP sent successfully."
    if not delivered:
        raise HTTPException(status_code=503, detail="OTP delivery failed. Please try again.")
    otp_store[key] = {"otp": otp, "method": method, "email": destination if method=="email" else "", "phone": destination if method=="sms" else "", "created_at": now, "last_sent": now, "expires_at": now+timedelta(seconds=OTP_TTL_SECONDS), "attempts": 0, "resends": int(existing.get("resends",0))+1 if existing else 0, "verified": False}
    logger.info("OTP sent via %s", method)
    return {"success": True, "message": message, "delivery_method": method, "expires_in": OTP_TTL_SECONDS, "resend_after": OTP_RESEND_COOLDOWN_SECONDS}


# ---------------------------------------------------------------------------
# Verify OTP
# ---------------------------------------------------------------------------

@router.post("/verify-otp")
async def verify_otp(data: VerifyOTPRequest):
    method = data.delivery_method
    if method == "email":
        if not data.email:
            raise HTTPException(status_code=400, detail="Email address is required.")
        destination = normalize_email(str(data.email))
    else:
        if not data.phone:
            raise HTTPException(status_code=400, detail="Mobile number is required.")
        try:
            destination = normalize_phone(data.phone)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    key = otp_key(method, destination)
    record = otp_store.get(key)
    if not record:
        raise HTTPException(status_code=400, detail="OTP not found. Please request a new OTP.")
    expires_at = record.get("expires_at")
    if not isinstance(expires_at, datetime) or datetime.utcnow() > expires_at:
        otp_store.pop(key, None)
        raise HTTPException(status_code=400, detail="OTP expired. Please request a new OTP.")
    attempts = int(record.get("attempts", 0))
    if attempts >= OTP_MAX_ATTEMPTS:
        otp_store.pop(key, None)
        raise HTTPException(status_code=429, detail="Too many incorrect OTP attempts. Please request a new OTP.")
    if secrets.compare_digest(data.otp, str(record.get("otp", ""))):
        record["verified"] = True
        record["verified_at"] = datetime.utcnow()
        return {"success": True, "verified": True, "delivery_method": method, "message": "OTP verified successfully."}
    record["attempts"] = attempts + 1
    raise HTTPException(status_code=400, detail=f"Invalid OTP. {max(0, OTP_MAX_ATTEMPTS-record['attempts'])} attempt(s) remaining.")


# ---------------------------------------------------------------------------
# Final registration
# ---------------------------------------------------------------------------

@router.post("/register")
async def register_account(
    data: RegisterRequest,
    request: Request,
    db: Session = Depends(get_db),
):

    email = normalize_email(
        str(data.email)
    )

    try:
        phone = normalize_phone(
            data.phone
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    if (
        data.confirm_password
        and data.password
        != data.confirm_password
    ):

        raise HTTPException(
            status_code=400,
            detail="Passwords do not match.",
        )

    # Never create a duplicate account.
    email_exists, phone_exists = (
        duplicate_status(
            db,
            email,
            phone,
        )
    )

    raise_if_duplicate(
        email_exists,
        phone_exists,
    )

    # Independently validate both MSG91 widget tokens on the server.
    # Frontend verification flags are never trusted.
    if not data.email_access_token:
        raise HTTPException(status_code=403, detail="Please verify your email OTP through MSG91.")
    if not data.phone_access_token:
        raise HTTPException(status_code=403, detail="Please verify your mobile OTP through MSG91.")

    verified_email_identifier = verify_msg91_access_token(data.email_access_token)
    verified_phone_identifier = verify_msg91_access_token(data.phone_access_token)

    if normalize_email(verified_email_identifier) != email:
        raise HTTPException(status_code=403, detail="The verified MSG91 email does not match the registration email.")
    try:
        verified_phone = normalize_phone(verified_phone_identifier)
    except ValueError as exc:
        raise HTTPException(status_code=403, detail="MSG91 verified a different or invalid mobile number.") from exc
    if verified_phone != phone:
        raise HTTPException(status_code=403, detail="The verified MSG91 mobile number does not match the registration mobile.")


    try:

        user = User(
            name=data.name.strip(),
            company_name=(
                data.company_name.strip()
            ),
            email=email,
            phone=phone,
            password_hash=hash_password(
                data.password
            ),
            role="Workspace Member",
            is_active=True,
            otp_verified=True,
        )

        db.add(user)

        db.commit()

        db.refresh(user)

    except Exception as exc:

        db.rollback()

        logger.exception(
            "Registration database operation failed"
        )

        raise HTTPException(
            status_code=500,
            detail=(
                "Unable to create the account. "
                "Please try again."
            ),
        ) from exc

    # Both OTPs are single-use.
    otp_store.pop(email_key, None)
    otp_store.pop(phone_key, None)

    # Existing session system.
    request.session["user"] = {
        "id": user.id,
        "name": user.name,
        "email": user.email,
        "company_name": user.company_name,
        "role": user.role,
    }

    return {
        "success": True,
        "message": (
            "Enterprise account created successfully."
        ),
        "user_id": user.id,
        "redirect": "/dashboard",
    }
