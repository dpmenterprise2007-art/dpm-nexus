# ==========================================================
# DPM NEXUS V9
# BOQ ENGINE ROUTER
# ==========================================================


from fastapi import (
    APIRouter,
    Depends
)

from sqlalchemy.orm import Session

from database.connection import get_db

from models.boq import BOQItem



router = APIRouter(

    prefix="/api/boq",

    tags=["BOQ"]

)



# ==========================================================
# GET ALL BOQ ITEMS
# ==========================================================


@router.get("/items")

async def get_boq_items(

    db: Session = Depends(get_db)

):

    items = db.query(

        BOQItem

    ).all()


    return {

        "success": True,

        "count": len(items),

        "data": items

    }



# ==========================================================
# CREATE BOQ ITEM
# ==========================================================


@router.post("/item")

async def create_boq_item(

    project_id: int,

    item_name: str,

    quantity: float,

    unit: str,

    rate: float,

    db: Session = Depends(get_db)

):


    amount = quantity * rate


    item = BOQItem(

        project_id=project_id,

        item_name=item_name,

        quantity=quantity,

        unit=unit,

        rate=rate,

        amount=amount

    )


    db.add(item)

    db.commit()

    db.refresh(item)


    return {

        "success": True,

        "message": "BOQ Item Created",

        "item_id": item.id,

        "amount": amount

    }



# ==========================================================
# BOQ SUMMARY
# ==========================================================
#
# Hint:
# Total project BOQ calculation.
#

@router.get("/summary")

async def boq_summary(

    db: Session = Depends(get_db)

):


    items = db.query(

        BOQItem

    ).all()



    subtotal = sum(

        item.amount

        for item in items

    )



    gst = subtotal * 0.18



    total = subtotal + gst



    return {

        "success": True,

        "subtotal": subtotal,

        "gst_18_percent": gst,

        "grand_total": total

    }