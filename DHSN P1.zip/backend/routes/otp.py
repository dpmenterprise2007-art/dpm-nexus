"""
DPM Nexus OTP verification routes.

Email delivery: SMTP (configure SMTP_* environment variables).
Mobile delivery: Twilio SMS (configure TWILIO_* environment variables).
OTP values are stored as HMAC hashes in PostgreSQL, expire automatically,
and are protected by resend cooldown and failed-attempt limits.
"""
import os
import re
import hmac
import hashlib
import secrets
import smtplib
import asyncio
import logging
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from urllib.parse import urlencode
from urllib.request import Request as URLRequest, urlopen
from urllib.error import HTTPError, URLError

from fastapi import APIRouter
from pydantic import BaseModel, Field
from sqlalchemy import text
from dotenv import load_dotenv
from pathlib import Path

load_dotenv(Path(__file__).resolve().parents[1] / ".env")

from database.connection import engine

logger = logging.getLogger("DPM Nexus OTP")
router = APIRouter(prefix="/api/auth", tags=["OTP Verification"])

OTP_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS dpm_otp_verifications (
    id BIGSERIAL PRIMARY KEY,
    channel VARCHAR(10) NOT NULL,
    destination VARCHAR(254) NOT NULL,
    otp_hash VARCHAR(64) NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0,
    verified_at TIMESTAMPTZ NULL,
    UNIQUE (channel, destination)
)
"""

OTP_TTL_SECONDS = int(os.getenv("OTP_TTL_SECONDS", "300"))
OTP_RESEND_COOLDOWN = int(os.getenv("OTP_RESEND_COOLDOWN", "60"))
OTP_MAX_ATTEMPTS = int(os.getenv("OTP_MAX_ATTEMPTS", "5"))
OTP_SECRET = os.getenv("OTP_SECRET") or os.getenv("SESSION_SECRET")
OTP_DIGITS = 6


class EmailOTPRequest(BaseModel):
    email: str


class EmailOTPVerify(BaseModel):
    email: str
    otp: str = Field(min_length=6, max_length=6, pattern=r"^\d{6}$")


class MobileOTPRequest(BaseModel):
    phone: str = Field(min_length=8, max_length=20)


class MobileOTPVerify(BaseModel):
    phone: str = Field(min_length=8, max_length=20)
    otp: str = Field(min_length=6, max_length=6, pattern=r"^\d{6}$")


def _now():
    return datetime.now(timezone.utc)


def _normalize_email(value: str) -> str:
    normalized = value.strip().lower()
    if len(normalized) > 254 or not re.fullmatch(r"[^@\\s]+@[^@\\s]+\\.[^@\\s]+", normalized):
        raise ValueError("Enter a valid email address.")
    return normalized


def _normalize_phone(value: str) -> str:
    value = value.strip()
    digits = re.sub(r"\D", "", value)
    if value.startswith("+"):
        normalized = "+" + digits
    elif len(digits) == 10:
        normalized = "+91" + digits
    elif len(digits) == 12 and digits.startswith("91"):
        normalized = "+" + digits
    else:
        raise ValueError("Enter a valid mobile number with country code, e.g. +919876543210.")
    if not re.fullmatch(r"\+[1-9]\d{7,14}", normalized):
        raise ValueError("Enter a valid international mobile number.")
    return normalized


def _otp_hash(channel: str, destination: str, otp: str) -> str:
    if not OTP_SECRET or len(OTP_SECRET) < 24:
        raise RuntimeError("Set a strong OTP_SECRET (minimum 24 characters) in backend/.env.")
    raw = f"{channel}:{destination}:{otp}".encode("utf-8")
    return hmac.new(OTP_SECRET.encode("utf-8"), raw, hashlib.sha256).hexdigest()


def _ensure_storage():
    with engine.begin() as conn:
        conn.execute(text(OTP_TABLE_SQL))


def _send_email(destination: str, otp: str):
    host = os.getenv("SMTP_HOST")
    port = int(os.getenv("SMTP_PORT", "587"))
    username = os.getenv("SMTP_USERNAME")
    password = os.getenv("SMTP_PASSWORD")
    sender = os.getenv("SMTP_FROM") or username
    use_ssl = os.getenv("SMTP_USE_SSL", "false").lower() == "true"
    if not all([host, username, password, sender]):
        raise RuntimeError("Email OTP is not configured. Set SMTP_HOST, SMTP_PORT, SMTP_USERNAME, SMTP_PASSWORD and SMTP_FROM in backend/.env.")
    msg = EmailMessage()
    msg["Subject"] = "Your DPM Nexus verification code"
    msg["From"] = sender
    msg["To"] = destination
    msg.set_content(
        f"Your DPM Nexus verification code is {otp}.\n\n"
        f"It expires in {OTP_TTL_SECONDS // 60} minutes. Do not share this code with anyone.\n"
        "If you did not request this code, you can ignore this email."
    )
    if use_ssl:
        with smtplib.SMTP_SSL(host, port, timeout=20) as smtp:
            smtp.login(username, password)
            smtp.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=20) as smtp:
            smtp.starttls()
            smtp.login(username, password)
            smtp.send_message(msg)


def _send_sms(destination: str, otp: str):
    account_sid = os.getenv("TWILIO_ACCOUNT_SID")
    auth_token = os.getenv("TWILIO_AUTH_TOKEN")
    from_number = os.getenv("TWILIO_FROM_NUMBER")
    if not all([account_sid, auth_token, from_number]):
        raise RuntimeError("Mobile OTP is not configured. Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN and TWILIO_FROM_NUMBER in backend/.env.")
    url = f"https://api.twilio.com/2010-04-01/Accounts/{account_sid}/Messages.json"
    body = urlencode({
        "To": destination,
        "From": from_number,
        "Body": f"Your DPM Nexus verification code is {otp}. It expires in {OTP_TTL_SECONDS // 60} minutes. Do not share it."
    }).encode("utf-8")
    import base64
    token = base64.b64encode(f"{account_sid}:{auth_token}".encode()).decode()
    req = URLRequest(url, data=body, headers={
        "Authorization": f"Basic {token}",
        "Content-Type": "application/x-www-form-urlencoded"
    }, method="POST")
    try:
        with urlopen(req, timeout=25) as response:
            response.read()
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="ignore")[:500]
        logger.error("Twilio SMS rejected: %s", detail)
        raise RuntimeError("SMS provider rejected the request. Check Twilio credentials, sender and destination.") from exc
    except URLError as exc:
        logger.exception("Twilio SMS delivery connection failed")
        raise RuntimeError("Could not connect to the SMS provider. Try again later.") from exc


def _request_otp(channel: str, destination: str):
    _ensure_storage()
    now = _now()
    with engine.begin() as conn:
        existing = conn.execute(text("""
            SELECT created_at FROM dpm_otp_verifications
            WHERE channel=:channel AND destination=:destination
        """), {"channel": channel, "destination": destination}).mappings().first()
        if existing and existing["created_at"] > now - timedelta(seconds=OTP_RESEND_COOLDOWN):
            wait = OTP_RESEND_COOLDOWN - int((now - existing["created_at"]).total_seconds())
            raise ValueError(f"Please wait {max(wait, 1)} seconds before requesting another OTP.")
    otp = f"{secrets.randbelow(10 ** OTP_DIGITS):0{OTP_DIGITS}d}"
    # Send first; only persist a usable OTP after the provider accepts the message.
    if channel == "email":
        _send_email(destination, otp)
    else:
        _send_sms(destination, otp)
    digest = _otp_hash(channel, destination, otp)
    with engine.begin() as conn:
        conn.execute(text("""
            INSERT INTO dpm_otp_verifications
                (channel,destination,otp_hash,expires_at,created_at,attempts,verified_at)
            VALUES
                (:channel,:destination,:otp_hash,:expires_at,:created_at,0,NULL)
            ON CONFLICT (channel,destination) DO UPDATE SET
                otp_hash=EXCLUDED.otp_hash,
                expires_at=EXCLUDED.expires_at,
                created_at=EXCLUDED.created_at,
                attempts=0,
                verified_at=NULL
        """), {
            "channel": channel, "destination": destination, "otp_hash": digest,
            "expires_at": now + timedelta(seconds=OTP_TTL_SECONDS), "created_at": now
        })


def _verify_otp(channel: str, destination: str, otp: str):
    _ensure_storage()
    now = _now()
    error = None
    with engine.begin() as conn:
        row = conn.execute(text("""
            SELECT otp_hash,expires_at,attempts,verified_at
            FROM dpm_otp_verifications
            WHERE channel=:channel AND destination=:destination
            FOR UPDATE
        """), {"channel": channel, "destination": destination}).mappings().first()
        if not row:
            error = "OTP not found. Request a new OTP."
        elif row["verified_at"] is not None:
            return
        elif row["expires_at"] <= now:
            conn.execute(text("DELETE FROM dpm_otp_verifications WHERE channel=:channel AND destination=:destination"),
                         {"channel": channel, "destination": destination})
            error = "OTP expired. Request a new OTP."
        elif row["attempts"] >= OTP_MAX_ATTEMPTS:
            error = "Maximum verification attempts reached. Request a new OTP."
        else:
            expected = _otp_hash(channel, destination, otp)
            if not hmac.compare_digest(row["otp_hash"], expected):
                conn.execute(text("""
                    UPDATE dpm_otp_verifications SET attempts=attempts+1
                    WHERE channel=:channel AND destination=:destination
                """), {"channel": channel, "destination": destination})
                error = "Incorrect OTP. Please check and try again."
            else:
                conn.execute(text("""
                    UPDATE dpm_otp_verifications SET verified_at=:verified_at
                    WHERE channel=:channel AND destination=:destination
                """), {"verified_at": now, "channel": channel, "destination": destination})
    if error:
        raise ValueError(error)


@router.post("/email/send-otp")
async def send_email_otp(data: EmailOTPRequest):
    destination = _normalize_email(str(data.email))
    try:
        await asyncio.to_thread(_request_otp, "email", destination)
        return {"success": True, "message": "Email OTP sent.", "expires_in": OTP_TTL_SECONDS}
    except ValueError as exc:
        return {"success": False, "message": str(exc)}
    except Exception as exc:
        logger.exception("Email OTP request failed")
        return {"success": False, "message": str(exc)}


@router.post("/email/verify-otp")
async def verify_email_otp(data: EmailOTPVerify):
    destination = _normalize_email(str(data.email))
    try:
        await asyncio.to_thread(_verify_otp, "email", destination, data.otp)
        return {"success": True, "message": "Email verified successfully.", "verified": True}
    except ValueError as exc:
        return {"success": False, "message": str(exc)}
    except Exception:
        logger.exception("Email OTP verification failed")
        return {"success": False, "message": "Verification service error. Please try again."}


@router.post("/mobile/send-otp")
async def send_mobile_otp(data: MobileOTPRequest):
    try:
        destination = _normalize_phone(data.phone)
        await asyncio.to_thread(_request_otp, "mobile", destination)
        return {"success": True, "message": "Mobile OTP sent.", "expires_in": OTP_TTL_SECONDS}
    except ValueError as exc:
        return {"success": False, "message": str(exc)}
    except Exception as exc:
        logger.exception("Mobile OTP request failed")
        return {"success": False, "message": str(exc)}


@router.post("/mobile/verify-otp")
async def verify_mobile_otp(data: MobileOTPVerify):
    try:
        destination = _normalize_phone(data.phone)
        await asyncio.to_thread(_verify_otp, "mobile", destination, data.otp)
        return {"success": True, "message": "Mobile number verified successfully.", "verified": True}
    except ValueError as exc:
        return {"success": False, "message": str(exc)}
    except Exception:
        logger.exception("Mobile OTP verification failed")
        return {"success": False, "message": "Verification service error. Please try again."}
