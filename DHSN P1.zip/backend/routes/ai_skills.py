"""DPM Nexus V9 - AI Skills Routes (ComfyUI image edition)."""
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel
from ai_engine.skill_engine import generate_file, available_skills
from ai_engine.image_skill import generate_image_file, image_status

router = APIRouter(prefix="/api/ai/skills", tags=["DPM AI Skills"])

class SkillRequest(BaseModel):
    title: str = "DPM Nexus AI Output"
    content: str = ""

def _filename_header(filename: str) -> str:
    return f'attachment; filename="{filename}"'

def _require_login(request: Request):
    user = request.session.get("user")
    if not user:
        raise HTTPException(status_code=401, detail="Authentication Required")
    return user

@router.get("/status")
async def phase1_skill_status():
    skills = available_skills()
    ist = image_status()
    return {
        "success": True,
        "engine": "DPM Nexus AI Engine",
        "phase": 1,
        "skills": {
            "pdf": "online" if "pdf" in skills else "offline",
            "word": "online" if "word" in skills else "offline",
            "excel": "online" if "excel" in skills else "offline",
            "image": "online" if ist.get("configured") else "configuration_required",
        },
        "image_provider": ist,
    }

@router.get("/list")
async def phase1_skill_list():
    skills = available_skills()
    skills["image"] = {"name":"ComfyUI Local Image Generation", "extension":".png", "mime":"image/png"}
    return {"success": True, "skills": skills}

async def _generate_document(skill: str, data: SkillRequest, request: Request):
    _require_login(request)
    if not data.content.strip():
        raise HTTPException(status_code=400, detail="Content is required.")
    try:
        filename, mime, raw = generate_file(skill=skill, title=data.title, content=data.content)
        return Response(content=raw, media_type=mime, headers={"Content-Disposition":_filename_header(filename),"X-DPM-AI-Skill":skill})
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"{skill.upper()} generation failed: {exc}")

@router.post("/pdf")
async def generate_pdf(data: SkillRequest, request: Request):
    return await _generate_document("pdf", data, request)

@router.post("/word")
async def generate_word(data: SkillRequest, request: Request):
    return await _generate_document("word", data, request)

@router.post("/excel")
async def generate_excel(data: SkillRequest, request: Request):
    return await _generate_document("excel", data, request)

@router.post("/image")
async def generate_image(data: SkillRequest, request: Request):
    _require_login(request)
    prompt = str(data.content or "").strip()
    if not prompt:
        raise HTTPException(status_code=400, detail="Image prompt is required.")
    try:
        filename, mime, raw = generate_image_file(prompt=prompt, title=data.title)
        return Response(content=raw, media_type=mime, headers={
            "Content-Disposition":_filename_header(filename),
            "Content-Length":str(len(raw)),
            "X-DPM-AI-Skill":"image",
            "X-DPM-AI-Provider":"ComfyUI Local",
        })
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"IMAGE generation failed: {exc}")
