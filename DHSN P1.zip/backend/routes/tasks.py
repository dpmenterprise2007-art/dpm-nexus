# ==========================================================
# DPM NEXUS V9
# TASK WORKFLOW ROUTER
# ==========================================================


from fastapi import (

    APIRouter,

    Depends

)


from sqlalchemy.orm import Session


from database.connection import get_db


from models.task import Task



router = APIRouter(

    prefix="/api/tasks",

    tags=["Workflow Engine"]

)



# ==========================================================
# LIST TASKS
# ==========================================================


@router.get("/list")

async def list_tasks(

    db: Session = Depends(get_db)

):


    tasks = db.query(

        Task

    ).all()



    return {


        "success": True,


        "count": len(tasks),


        "data": tasks

    }



# ==========================================================
# CREATE TASK
# ==========================================================


@router.post("/create")

async def create_task(

    title: str,

    description: str,

    project_id: int = None,

    assigned_to: str = None,

    priority: str = "Medium",

    db: Session = Depends(get_db)

):


    task = Task(

        title=title,

        description=description,

        project_id=project_id,

        assigned_to=assigned_to,

        priority=priority

    )


    db.add(task)

    db.commit()

    db.refresh(task)



    return {


        "success": True,


        "message": "Task Created",


        "task_id": task.id

    }



# ==========================================================
# UPDATE STATUS
# ==========================================================


@router.put("/{task_id}/status")

async def update_task_status(

    task_id: int,

    status: str,

    db: Session = Depends(get_db)

):


    task = db.query(

        Task

    ).filter(

        Task.id == task_id

    ).first()



    if not task:


        return {


            "success": False,


            "message": "Task Not Found"

        }



    task.status = status


    db.commit()



    return {


        "success": True,


        "message": "Task Updated"


    }



# ==========================================================
# WORKFLOW DASHBOARD
# ==========================================================


@router.get("/dashboard")

async def task_dashboard(

    db: Session = Depends(get_db)

):


    total = db.query(

        Task

    ).count()



    completed = db.query(

        Task

    ).filter(

        Task.status == "Completed"

    ).count()



    pending = db.query(

        Task

    ).filter(

        Task.status == "Pending"

    ).count()



    return {


        "success": True,


        "total_tasks": total,


        "completed": completed,


        "pending": pending

    }