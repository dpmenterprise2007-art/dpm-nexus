# ==========================================================
# DPM NEXUS V9
# FINANCE OS ROUTER
# ==========================================================


from fastapi import (
    APIRouter,
    Depends
)

from sqlalchemy.orm import Session

from database.connection import get_db

from models.invoice import Invoice



router = APIRouter(

    prefix="/api/finance",

    tags=["Finance OS"]

)



# ==========================================================
# GET ALL INVOICES
# ==========================================================


@router.get("/invoices")

async def get_invoices(

    db: Session = Depends(get_db)

):


    invoices = db.query(

        Invoice

    ).all()



    return {

        "success": True,

        "count": len(invoices),

        "data": invoices

    }



# ==========================================================
# CREATE INVOICE
# ==========================================================


@router.post("/invoice/create")

async def create_invoice(

    invoice_number: str,

    client_name: str,

    amount: float,

    db: Session = Depends(get_db)

):


    gst = amount * 0.18


    total = amount + gst



    invoice = Invoice(

        invoice_number=invoice_number,

        client_name=client_name,

        amount=amount,

        gst_amount=gst,

        status="Pending"

    )


    db.add(invoice)

    db.commit()

    db.refresh(invoice)



    return {

        "success": True,

        "message": "Invoice Created",

        "invoice_id": invoice.id,

        "subtotal": amount,

        "gst": gst,

        "total": total

    }



# ==========================================================
# UPDATE PAYMENT STATUS
# ==========================================================


@router.put("/invoice/{invoice_id}/status")

async def update_invoice_status(

    invoice_id: int,

    status: str,

    db: Session = Depends(get_db)

):


    invoice = db.query(

        Invoice

    ).filter(

        Invoice.id == invoice_id

    ).first()



    if not invoice:


        return {

            "success": False,

            "message": "Invoice Not Found"

        }



    invoice.status = status


    db.commit()



    return {

        "success": True,

        "message": "Invoice Status Updated",

        "status": status

    }



# ==========================================================
# FINANCE DASHBOARD
# ==========================================================


@router.get("/dashboard")

async def finance_dashboard(

    db: Session = Depends(get_db)

):


    invoices = db.query(

        Invoice

    ).all()



    total_invoice = sum(

        i.amount

        for i in invoices

    )


    pending = len([

        i for i in invoices

        if i.status == "Pending"

    ])


    completed = len([

        i for i in invoices

        if i.status == "Paid"

    ])



    return {

        "success": True,

        "total_invoice_value": total_invoice,

        "pending_invoice": pending,

        "paid_invoice": completed

    }



# ==========================================================
# RECEIVABLE REPORT
# ==========================================================


@router.get("/receivable")

async def receivable(

    db: Session = Depends(get_db)

):


    pending = db.query(

        Invoice

    ).filter(

        Invoice.status == "Pending"

    ).all()



    amount = sum(

        i.amount

        for i in pending

    )



    return {

        "success": True,

        "pending_amount": amount,

        "count": len(pending)

    }