"""
DPM Nexus V9 - Live Dashboard API
Reads existing project, CRM, BOQ and invoice records.
No schema migration or database writes are performed.
"""
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import func
from sqlalchemy.orm import Session

from database.connection import get_db
from models.project import Project
from models.crm import CRMLead
from models.boq import BOQItem
from models.invoice import Invoice

router = APIRouter(prefix="/api/dashboard", tags=["Dashboard"])


@router.get("/live-status")
def live_dashboard_status(request: Request, db: Session = Depends(get_db)):
    # Match the existing Starlette session used by main.py and auth.py.
    user = request.session.get("user")
    if not user:
        raise HTTPException(status_code=401, detail="Authentication required")

    role = str(user.get("role") or "").strip().lower()
    allowed_admin_roles = {"admin", "administrator", "super admin", "superadmin", "director"}
    if role not in allowed_admin_roles:
        raise HTTPException(status_code=403, detail="Admin access required")

    project_total = db.query(func.count(Project.id)).scalar() or 0
    project_status_rows = (
        db.query(Project.status, func.count(Project.id))
        .group_by(Project.status)
        .all()
    )
    project_status = {
        (status or "Unspecified"): count
        for status, count in project_status_rows
    }

    crm_leads = db.query(func.count(CRMLead.id)).scalar() or 0
    boq_line_items = db.query(func.count(BOQItem.id)).scalar() or 0
    boq_subtotal = db.query(func.coalesce(func.sum(BOQItem.amount), 0)).scalar() or 0

    invoice_subtotal = db.query(
        func.coalesce(func.sum(Invoice.amount), 0)
    ).scalar() or 0
    paid_revenue = db.query(
        func.coalesce(func.sum(Invoice.amount), 0)
    ).filter(func.lower(Invoice.status) == "paid").scalar() or 0
    pending_amount = db.query(
        func.coalesce(func.sum(Invoice.amount), 0)
    ).filter(func.lower(Invoice.status) == "pending").scalar() or 0
    pending_count = db.query(func.count(Invoice.id)).filter(
        func.lower(Invoice.status) == "pending"
    ).scalar() or 0
    paid_count = db.query(func.count(Invoice.id)).filter(
        func.lower(Invoice.status) == "paid"
    ).scalar() or 0

    return {
        "success": True,
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "user": {
            "name": user.get("name") or "DPM User",
            "company_name": user.get("company_name") or "",
            "role": user.get("role") or "",
        },
        "projects": {
            "total": project_total,
            "by_status": project_status,
        },
        "crm": {
            "lead_records": crm_leads,
            "note": "Count of CRM lead records; not a verified-client count.",
        },
        "boq": {
            "line_items": boq_line_items,
            "subtotal": round(float(boq_subtotal), 2),
            "gst_18_percent": round(float(boq_subtotal) * 0.18, 2),
            "grand_total": round(float(boq_subtotal) * 1.18, 2),
            "note": "BOQ count represents line items because the supplied schema has BOQItem rows, not a BOQ header table.",
        },
        "finance": {
            "invoice_subtotal": round(float(invoice_subtotal), 2),
            "paid_revenue": round(float(paid_revenue), 2),
            "pending_amount": round(float(pending_amount), 2),
            "pending_invoice_count": pending_count,
            "paid_invoice_count": paid_count,
            "note": "Paid revenue includes only invoices whose status is Paid; values exclude GST.",
        },
    }
