from datetime import datetime, timezone
import secrets

from fastapi import APIRouter, HTTPException

from schemas.contact import ContactInquiry
from utils.email import send_auto_reply, send_inquiry_email

router = APIRouter(prefix="/contact", tags=["Contact"])


def _make_inquiry_id() -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    return f"DPM-{stamp}-{secrets.token_hex(2).upper()}"


@router.post("/inquiry")
async def contact_inquiry(inquiry: ContactInquiry):
    request_id = _make_inquiry_id()

    inquiry_sent = send_inquiry_email(
        client_name=inquiry.full_name,
        company_name=inquiry.company_name,
        email=str(inquiry.email),
        phone=inquiry.phone,
        subject=inquiry.subject,
        message=inquiry.message,
        inquiry_type=inquiry.inquiry_type,
        location=inquiry.location,
        timeline=inquiry.timeline,
        request_id=request_id,
    )

    if not inquiry_sent:
        raise HTTPException(
            status_code=503,
            detail="Inquiry email could not be delivered. Please try again or use the direct email option.",
        )

    client_reply_sent = send_auto_reply(
        client_name=inquiry.full_name,
        client_email=str(inquiry.email),
        request_id=request_id,
    )

    return {
        "success": True,
        "message": "Inquiry submitted successfully.",
        "request_id": request_id,
        "admin_email_sent": True,
        "client_reply_sent": client_reply_sent,
    }
