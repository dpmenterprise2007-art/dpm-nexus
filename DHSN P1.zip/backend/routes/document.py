# ==========================================================
# DPM NEXUS V9
# DOCUMENT VAULT ROUTER
# ==========================================================


import os
import shutil


from fastapi import (

    APIRouter,

    UploadFile,

    File,

    Depends

)


from sqlalchemy.orm import Session


from database.connection import get_db


from models.document import Document



router = APIRouter(

    prefix="/api/documents",

    tags=["Document Vault"]

)



UPLOAD_FOLDER = "uploads/documents"



os.makedirs(

    UPLOAD_FOLDER,

    exist_ok=True

)



# ==========================================================
# UPLOAD DOCUMENT
# ==========================================================


@router.post("/upload")

async def upload_document(

    file: UploadFile = File(...),

    category: str = "General",

    db: Session = Depends(get_db)

):


    file_path = os.path.join(

        UPLOAD_FOLDER,

        file.filename

    )


    with open(

        file_path,

        "wb"

    ) as buffer:


        shutil.copyfileobj(

            file.file,

            buffer

        )



    document = Document(

        file_name=file.filename,

        file_path=file_path,

        file_type=file.content_type,

        category=category

    )


    db.add(document)

    db.commit()

    db.refresh(document)



    return {


        "success": True,


        "message": "Document Uploaded",


        "document_id": document.id

    }



# ==========================================================
# LIST DOCUMENTS
# ==========================================================


@router.get("/list")

async def list_documents(

    db: Session = Depends(get_db)

):


    documents = db.query(

        Document

    ).all()



    return {


        "success": True,


        "count": len(documents),


        "data": documents

    }



# ==========================================================
# PROJECT DOCUMENTS
# ==========================================================


@router.get("/project/{project_id}")

async def project_documents(

    project_id: int,

    db: Session = Depends(get_db)

):


    documents = db.query(

        Document

    ).filter(

        Document.project_id == project_id

    ).all()



    return {


        "success": True,


        "data": documents

    }