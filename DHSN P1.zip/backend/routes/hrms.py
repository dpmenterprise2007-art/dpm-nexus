# ==========================================================
# DPM NEXUS V9
# HRMS ROUTER
# ==========================================================


from fastapi import (

    APIRouter,

    Depends

)


from sqlalchemy.orm import Session


from database.connection import get_db


from models.employee import Employee



router = APIRouter(

    prefix="/api/hrms",

    tags=["HRMS"]

)



# ==========================================================
# GET EMPLOYEES
# ==========================================================


@router.get("/employees")

async def get_employees(

    db: Session = Depends(get_db)

):


    employees = db.query(

        Employee

    ).all()



    return {


        "success": True,


        "count": len(employees),


        "data": employees

    }



# ==========================================================
# CREATE EMPLOYEE
# ==========================================================


@router.post("/employee/create")

async def create_employee(

    name: str,

    department: str,

    designation: str,

    phone: str,

    email: str,

    db: Session = Depends(get_db)

):


    employee = Employee(

        name=name,

        department=department,

        designation=designation,

        phone=phone,

        email=email

    )


    db.add(employee)

    db.commit()

    db.refresh(employee)



    return {


        "success": True,


        "message": "Employee Created",


        "employee_id": employee.id

    }



# ==========================================================
# UPDATE EMPLOYEE STATUS
# ==========================================================


@router.put("/employee/{employee_id}/status")

async def update_employee_status(

    employee_id: int,

    status: str,

    db: Session = Depends(get_db)

):


    employee = db.query(

        Employee

    ).filter(

        Employee.id == employee_id

    ).first()



    if not employee:


        return {


            "success": False,


            "message": "Employee Not Found"

        }



    employee.status = status


    db.commit()



    return {


        "success": True,


        "message": "Status Updated"


    }



# ==========================================================
# HR DASHBOARD
# ==========================================================


@router.get("/dashboard")

async def hr_dashboard(

    db: Session = Depends(get_db)

):


    total = db.query(

        Employee

    ).count()



    active = db.query(

        Employee

    ).filter(

        Employee.status == "Active"

    ).count()



    return {


        "success": True,


        "total_employee": total,


        "active_employee": active

    }