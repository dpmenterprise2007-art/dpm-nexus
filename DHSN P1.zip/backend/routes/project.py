# ==========================================================
# DPM NEXUS V9
# PROJECT MANAGEMENT ROUTER
# ==========================================================


from fastapi import (
    APIRouter,
    Depends
)

from sqlalchemy.orm import Session

from database.connection import get_db

from models.project import Project


router = APIRouter(

    prefix="/api/projects",

    tags=["Project OS"]

)



# ==========================================================
# GET ALL PROJECTS
# ==========================================================


@router.get("/list")

async def get_projects(

    db: Session = Depends(get_db)

):


    projects = db.query(

        Project

    ).all()



    return {

        "success": True,

        "count": len(projects),

        "data": projects

    }



# ==========================================================
# CREATE PROJECT
# ==========================================================


@router.post("/create")

async def create_project(

    project_name: str,

    client_name: str,

    location: str,

    project_value: float = 0,

    db: Session = Depends(get_db)

):


    project = Project(

        project_name=project_name,

        client_name=client_name,

        location=location,

        project_value=project_value

    )


    db.add(project)

    db.commit()

    db.refresh(project)



    return {

        "success": True,

        "message": "Project Created",

        "project_id": project.id

    }



# ==========================================================
# UPDATE PROJECT STATUS
# ==========================================================


@router.put("/{project_id}/status")

async def update_project_status(

    project_id: int,

    status: str,

    db: Session = Depends(get_db)

):


    project = db.query(

        Project

    ).filter(

        Project.id == project_id

    ).first()



    if not project:


        return {

            "success": False,

            "message": "Project Not Found"

        }



    project.status = status


    db.commit()



    return {

        "success": True,

        "message": "Status Updated",

        "status": status

    }



# ==========================================================
# PROJECT DETAILS
# ==========================================================


@router.get("/{project_id}")

async def project_details(

    project_id: int,

    db: Session = Depends(get_db)

):


    project = db.query(

        Project

    ).filter(

        Project.id == project_id

    ).first()



    if not project:


        return {

            "success": False,

            "message": "Project Not Found"

        }



    return {

        "success": True,

        "data": project

    }



# ==========================================================
# PROJECT DASHBOARD SUMMARY
# ==========================================================


@router.get("/dashboard/summary")

async def project_summary(

    db: Session = Depends(get_db)

):


    total = db.query(

        Project

    ).count()



    running = db.query(

        Project

    ).filter(

        Project.status == "Running"

    ).count()



    completed = db.query(

        Project

    ).filter(

        Project.status == "Completed"

    ).count()



    return {

        "success": True,

        "total_projects": total,

        "running": running,

        "completed": completed

    }