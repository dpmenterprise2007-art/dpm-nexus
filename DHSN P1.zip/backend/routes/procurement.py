# ==========================================================
# DPM NEXUS V9
# PROCUREMENT ROUTER
# ==========================================================


from fastapi import (

    APIRouter,

    Depends

)


from sqlalchemy.orm import Session


from database.connection import get_db


from models.purchase_order import PurchaseOrder



router = APIRouter(

    prefix="/api/procurement",

    tags=["Procurement OS"]

)



# ==========================================================
# LIST PURCHASE ORDERS
# ==========================================================


@router.get("/orders")

async def list_orders(

    db: Session = Depends(get_db)

):


    orders = db.query(

        PurchaseOrder

    ).all()



    return {


        "success": True,


        "count": len(orders),


        "data": orders

    }



# ==========================================================
# CREATE PURCHASE ORDER
# ==========================================================


@router.post("/create")

async def create_purchase_order(

    po_number: str,

    vendor_name: str,

    material_name: str,

    quantity: float,

    amount: float,

    db: Session = Depends(get_db)

):


    order = PurchaseOrder(

        po_number=po_number,

        vendor_name=vendor_name,

        material_name=material_name,

        quantity=quantity,

        amount=amount

    )


    db.add(order)

    db.commit()

    db.refresh(order)



    return {


        "success": True,


        "message": "Purchase Order Created",


        "po_id": order.id

    }



# ==========================================================
# UPDATE APPROVAL STATUS
# ==========================================================


@router.put("/{po_id}/status")

async def update_po_status(

    po_id: int,

    status: str,

    db: Session = Depends(get_db)

):


    order = db.query(

        PurchaseOrder

    ).filter(

        PurchaseOrder.id == po_id

    ).first()



    if not order:


        return {


            "success": False,


            "message": "PO Not Found"

        }



    order.status = status


    db.commit()



    return {


        "success": True,


        "message": "Purchase Order Updated",

        "status": status

    }



# ==========================================================
# PROCUREMENT DASHBOARD
# ==========================================================


@router.get("/dashboard")

async def procurement_dashboard(

    db: Session = Depends(get_db)

):


    total = db.query(

        PurchaseOrder

    ).count()



    pending = db.query(

        PurchaseOrder

    ).filter(

        PurchaseOrder.status == "Pending"

    ).count()



    approved = db.query(

        PurchaseOrder

    ).filter(

        PurchaseOrder.status == "Approved"

    ).count()



    return {


        "success": True,


        "total_orders": total,


        "pending": pending,


        "approved": approved

    }