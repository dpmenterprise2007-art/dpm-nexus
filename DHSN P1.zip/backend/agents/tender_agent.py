# ==========================================================
# TENDER AI AGENT
# ==========================================================


from core.ai_engine import ai_response



def analyze_tender(

    tender_data

):


    prompt = f"""

Analyze Tender:

{tender_data}


Provide:

- Eligibility Check

- Risk Analysis

- Bid Strategy

- Document Checklist

"""


    return ai_response(

        prompt

    )