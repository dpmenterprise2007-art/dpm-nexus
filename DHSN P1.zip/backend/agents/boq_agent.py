# ==========================================================
# BOQ AI AGENT
# ==========================================================


from core.ai_engine import ai_response



def analyze_boq(

    boq_data

):


    prompt = f"""

Analyze BOQ:

{boq_data}


Generate:

1. Cost Analysis

2. Material Suggestion

3. Risk Points

4. Optimization

"""


    return ai_response(

        prompt

    )