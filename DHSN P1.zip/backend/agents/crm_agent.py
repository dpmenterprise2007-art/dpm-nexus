# ==========================================================
# CRM AI AGENT
# ==========================================================


from core.ai_engine import ai_response



def qualify_lead(

    lead_data

):


    prompt = f"""

Analyze Customer Lead:

{lead_data}


Generate:

- Lead Score

- Priority

- Next Action

"""


    return ai_response(

        prompt

    )