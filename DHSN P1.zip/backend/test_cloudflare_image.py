import os
import sys
import base64
from pathlib import Path

import requests
from dotenv import load_dotenv

BASE = Path(__file__).resolve().parent
load_dotenv(BASE / ".env")

account_id = os.getenv("CLOUDFLARE_ACCOUNT_ID", "").strip()
api_token = os.getenv("CLOUDFLARE_API_TOKEN", "").strip()
model = os.getenv(
    "CLOUDFLARE_IMAGE_MODEL",
    "@cf/black-forest-labs/flux-1-schnell"
).strip()

if not account_id:
    sys.exit("ERROR: CLOUDFLARE_ACCOUNT_ID .env mein nahi mila.")

if not api_token:
    sys.exit("ERROR: CLOUDFLARE_API_TOKEN .env mein nahi mila.")

url = (
    f"https://api.cloudflare.com/client/v4/accounts/"
    f"{account_id}/ai/run/{model}"
)

payload = {
    "prompt": (
        "Premium photorealistic corporate office interior for "
        "DPM Enterprise Private Limited, elegant light wood veneer, "
        "Italian marble flooring, premium furniture, refined lighting, "
        "wide-angle architectural photography, realistic materials, "
        "no text, no logo, no watermark."
    )
}

headers = {
    "Authorization": f"Bearer {api_token}",
    "Content-Type": "application/json"
}

print("Cloudflare FLUX image test shuru...")
print("Model:", model)

try:
    response = requests.post(
        url,
        headers=headers,
        json=payload,
        timeout=180
    )

    print("HTTP:", response.status_code)

    if not response.ok:
        print("CLOUDFLARE ERROR:")
        print(response.text[:3000])
        sys.exit(1)

    content_type = response.headers.get("Content-Type", "")

    if "image/" in content_type:
        image_bytes = response.content
    else:
        data = response.json()

        if not data.get("success", False):
            print("API ERROR:", data.get("errors"))
            sys.exit(1)

        result = data.get("result") or {}
        encoded = result.get("image")

        if not encoded:
            print("Image response nahi mili.")
            print(str(data)[:3000])
            sys.exit(2)

        image_bytes = base64.b64decode(encoded)

    output = BASE / "cloudflare_test_image.jpg"
    output.write_bytes(image_bytes)

    print()
    print("===================================")
    print("SUCCESS! Cloudflare image generated.")
    print("FILE:", output)
    print("===================================")

except requests.RequestException as exc:
    print("NETWORK ERROR:", exc)
    sys.exit(1)

except Exception as exc:
    print("ERROR:", type(exc).__name__, str(exc))
    sys.exit(1)