# ==========================================================
# DPM NEXUS V9 OPTIMIZED
# Enterprise Backend
# main.py
# Version : 3.1 Enterprise Final Clean
# ==========================================================

# ==========================================================
# IMPORTS
# ==========================================================

import os
import logging

from pathlib import Path
from contextlib import asynccontextmanager

from dotenv import load_dotenv

from fastapi import (
    FastAPI,
    Request
)

from fastapi.responses import (
    HTMLResponse,
    JSONResponse,
    RedirectResponse
)

from fastapi.staticfiles import StaticFiles

from fastapi.middleware.cors import CORSMiddleware

from starlette.middleware.sessions import SessionMiddleware

from starlette.exceptions import HTTPException as StarletteHTTPException

from fastapi.exceptions import RequestValidationError

from authlib.integrations.starlette_client import OAuth

from pydantic import BaseModel


# ==========================================================
# DATABASE
# ==========================================================

from database.base import Base

from database.connection import (
    engine,
    get_db
)


# ==========================================================
# SECURITY MIDDLEWARE
# ==========================================================

from middleware.security_headers import security_headers


# ==========================================================
# ROUTERS
# ==========================================================

from routes.ai import router as ai_router
from routes.crm import router as crm_router
from routes.boq import router as boq_router
from routes.tender import router as tender_router
from routes.project import router as projects_router
from routes.vendor import router as vendor_router
from routes.finance import router as finance_router
from routes.hrms import router as hrms_router
from routes.document import router as document_router
from routes.notification import router as notification_router
from routes.audit import router as audit_router
from routes.permissions import router as permission_router
from routes.admin import router as admin_router
from routes.director import router as director_router
from routes.search import router as search_router
from routes.ai_agents import router as ai_agent_router
from routes.tasks import router as task_router
from routes.calendar import router as calendar_router
from routes.inventory import router as inventory_router
from routes.procurement import router as procurement_router
from routes.analytics import router as analytics_router
from routes.dpm_ai import router as dpm_ai_router
from routes.contact import router as contact_router
from routes.auth import router as auth_router
from routes.public_ai import router as public_ai_router
from routes.ai_skills import router as ai_skills_router
from routes.dashboard import router as dashboard_router

# ==========================================================
# PROJECT PATHS
# ==========================================================

BASE_DIR = Path(__file__).resolve().parent

FRONTEND_DIR = BASE_DIR.parent / "frontend"

ASSETS_DIR = FRONTEND_DIR / "assets"

STATIC_DIR = FRONTEND_DIR / "static"

IMAGES_DIR = FRONTEND_DIR / "images"

CSS_DIR = FRONTEND_DIR / "css"

JS_DIR = FRONTEND_DIR / "js"

FONTS_DIR = FRONTEND_DIR / "fonts"

UPLOADS_DIR = FRONTEND_DIR / "uploads"


# ==========================================================
# ENVIRONMENT VARIABLES
# ==========================================================

load_dotenv(BASE_DIR / ".env")


APP_NAME = "DPM Nexus V9"

VERSION = "3.1 Enterprise Final"


SESSION_SECRET = os.getenv(
    "SESSION_SECRET",
    "dpm-enterprise-secret"
)


GOOGLE_CLIENT_ID = os.getenv(
    "GOOGLE_CLIENT_ID"
)


GOOGLE_CLIENT_SECRET = os.getenv(
    "GOOGLE_CLIENT_SECRET"
)


# ==========================================================
# AI / GROQ CONFIGURATION
# ==========================================================

# Groq API key. Keep the real key only in backend .env.
GROQ_API_KEY = os.getenv(
    "GROQ_API_KEY"
)

GROQ_BASE_URL = os.getenv(
    "GROQ_BASE_URL",
    "https://api.groq.com/openai/v1"
)

GROQ_MODEL = os.getenv(
    "GROQ_MODEL",
    "openai/gpt-oss-120b"
)

# Backward-compatible internal name used by existing AI status/chat code.
AI_MODEL = GROQ_MODEL


# ==========================================================
# GOOGLE OAUTH CONFIGURATION
# ==========================================================

GOOGLE_CLIENT_ID = os.getenv(
    "GOOGLE_CLIENT_ID"
)

GOOGLE_CLIENT_SECRET = os.getenv(
    "GOOGLE_CLIENT_SECRET"
)

GOOGLE_OAUTH_ENABLED = bool(
    GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET
)


# ==========================================================
# COMFYUI LOCAL IMAGE ENGINE
# ==========================================================

COMFYUI_ENABLED = os.getenv(
    "COMFYUI_ENABLED",
    "true"
).lower() == "true"

COMFYUI_BASE_URL = os.getenv(
    "COMFYUI_BASE_URL",
    "http://127.0.0.1:8188"
).rstrip("/")

COMFYUI_API_KEY = os.getenv(
    "COMFYUI_API_KEY"
)

COMFYUI_IMAGE_MODEL = os.getenv(
    "COMFYUI_IMAGE_MODEL",
    "flux1-schnell"
)

COMFYUI_WORKFLOW = os.getenv(
    "COMFYUI_WORKFLOW",
    ""
)


# ==========================================================
# LOGGING
# ==========================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

logger = logging.getLogger(APP_NAME)


# ==========================================================
# STARTUP / SHUTDOWN LIFESPAN
# ==========================================================


@asynccontextmanager
async def lifespan(app: FastAPI):

    logger.info("=" * 60)

    logger.info(
        "DPM NEXUS STARTING"
    )

    logger.info("=" * 60)


    logger.info(
        f"Frontend : {FRONTEND_DIR}"
    )


    logger.info(

        f"Google OAuth : {'YES' if GOOGLE_OAUTH_ENABLED else 'NO'}"

    )


    logger.info(

        f"Groq AI : {'YES' if GROQ_API_KEY else 'NO'}"

    )


    logger.info(

        f"Groq Model : {GROQ_MODEL}"

    )


    logger.info(

        f"ComfyUI : {'YES' if COMFYUI_ENABLED else 'NO'}"

    )


    logger.info(

        f"ComfyUI URL : {COMFYUI_BASE_URL}"

    )


    logger.info(

        f"ComfyUI Image Model : {COMFYUI_IMAGE_MODEL}"

    )


    try:

        Base.metadata.create_all(

            bind=engine

        )

        logger.info(

            "Database Tables Verified"

        )


    except Exception as e:


        logger.error(

            f"Database Error : {e}"

        )


    yield


    logger.info("=" * 60)

    logger.info(

        "DPM NEXUS STOPPED"

    )

    logger.info("=" * 60)



# ==========================================================
# FASTAPI APPLICATION
# ==========================================================


app = FastAPI(

    title=APP_NAME,

    version=VERSION,

    lifespan=lifespan

)

from fastapi.staticfiles import StaticFiles





# ==========================================================
# SESSION MIDDLEWARE
# ==========================================================


app.add_middleware(

    SessionMiddleware,

    secret_key=SESSION_SECRET,

    same_site="lax",

    https_only=False

)



# ==========================================================
# CORS
# ==========================================================


app.add_middleware(

    CORSMiddleware,

    allow_origins=["*"],

    allow_credentials=True,

    allow_methods=["*"],

    allow_headers=["*"]

)



# ==========================================================
# SECURITY HEADERS
# ==========================================================

app.middleware("http")(security_headers)



# ==========================================================
# STATIC FILE MOUNT
# ==========================================================


def mount_folder(

    url,

    folder

):


    if folder.exists():

        app.mount(

            url,

            StaticFiles(

                directory=str(folder)

            ),

            name=url.replace(

                "/",

                ""

            )

        )



mount_folder(

    "/assets",

    ASSETS_DIR

)


mount_folder(

    "/images",

    IMAGES_DIR

)


mount_folder(

    "/static",

    STATIC_DIR

)


mount_folder(

    "/css",

    CSS_DIR

)


mount_folder(

    "/js",

    JS_DIR

)


mount_folder(

    "/fonts",

    FONTS_DIR

)


mount_folder(

    "/uploads",

    UPLOADS_DIR

)


# ==========================================================
# GOOGLE OAUTH CONFIGURATION
# ==========================================================


oauth = OAuth()


if GOOGLE_OAUTH_ENABLED:


    oauth.register(

        name="google",

        client_id=GOOGLE_CLIENT_ID,

        client_secret=GOOGLE_CLIENT_SECRET,

        server_metadata_url=

        "https://accounts.google.com/.well-known/openid-configuration",


        client_kwargs={

            "scope":

            "openid email profile"

        }

    )



# ==========================================================
# ROUTER REGISTRATION
# ==========================================================


app.include_router(ai_router)

app.include_router(crm_router)

app.include_router(boq_router)

app.include_router(tender_router)

app.include_router(projects_router)

app.include_router(vendor_router)

app.include_router(finance_router)

app.include_router(hrms_router)

app.include_router(document_router)

app.include_router(notification_router)

app.include_router(audit_router)

app.include_router(permission_router)

app.include_router(admin_router)

app.include_router(director_router)

app.include_router(search_router)

app.include_router(ai_agent_router)

app.include_router(task_router)

app.include_router(calendar_router)

app.include_router(inventory_router)

app.include_router(procurement_router)

app.include_router(analytics_router)

app.include_router(dpm_ai_router)

app.include_router(auth_router)

app.include_router(contact_router)

app.include_router(public_ai_router)
app.include_router(ai_skills_router)
app.include_router(dashboard_router)

logger.info(

    "Enterprise Routes Loaded Successfully"

)



# ==========================================================
# CORE HTML HELPERS
# ==========================================================


def read_html(filename: str):

    """
    HTML file safely read karega.
    """


    file = FRONTEND_DIR / filename


    if not file.exists():


        logger.error(

            f"{filename} not found"

        )


        return f"""

        <!DOCTYPE html>

        <html>

        <body style="font-family:Arial;padding:40px">

        <h2>404</h2>

        <p>{filename} not found.</p>

        </body>

        </html>

        """



    try:


        return file.read_text(

            encoding="utf-8"

        )



    except Exception as e:


        logger.exception(e)


        return f"""

        <h2>{e}</h2>

        """



# ==========================================================
# PAGE RENDER HELPER
# ==========================================================

def render_page(filename: str):
    """
    Render an HTML page from the frontend directory.
    Keeps all existing page URLs linked to their actual HTML files.
    """
    return HTMLResponse(content=read_html(filename))


# ==========================================================
# SESSION HELPERS
# ==========================================================


def get_user(

    request: Request

):


    return request.session.get(

        "user"

    )



def is_logged_in(

    request: Request

):


    return get_user(

        request

    ) is not None



def require_login(

    request: Request

):


    user = get_user(

        request

    )


    if user:


        return user


    return None



# ==========================================================
# RESPONSE HELPERS
# ==========================================================


def success(

    data=None,

    message="Success"

):


    return {


        "success": True,


        "message": message,


        "data": data

    }




def failed(

    message,

    status=400

):


    return JSONResponse(

        status_code=status,

        content={


            "success": False,


            "message": message


        }

    )

# ==========================================================
# PUBLIC WEBSITE HOME
# ==========================================================

@app.get(
    "/",
    response_class=HTMLResponse
)
async def root():

    return render_page(

        "index.html"

    )



# ==========================================================
# LOGIN PAGE
# ==========================================================


@app.get(
    "/login",
    response_class=HTMLResponse
)
async def login(

    request: Request

):


    if is_logged_in(request):

        return RedirectResponse(

            "/dashboard"

        )


    return render_page(

        "login.html"

    )

# ==========================================================
# REGISTER PAGE
# ==========================================================

@app.get(
    "/register",
    response_class=HTMLResponse
)
async def register_page(
    request: Request
):

    if is_logged_in(request):

        return RedirectResponse(
            "/dashboard"
        )


    return render_page(
        "register.html"
    )


# ==========================================================
# LOGOUT
# ==========================================================


@app.get("/logout")

async def logout(

    request: Request

):


    request.session.clear()


    logger.info(

        "User Logged Out"

    )


    return RedirectResponse(

        "/login"

    )



# ==========================================================
# GOOGLE LOGIN
# ==========================================================


@app.get("/auth/google/login")
async def google_login(

    request: Request

):

    if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET:

        return failed(

            "Google OAuth Not Configured",

            500

        )


    redirect_uri = request.url_for(

        "google_callback"

    )


    return await oauth.google.authorize_redirect(

        request,

        redirect_uri

    )



# ==========================================================
# GOOGLE CALLBACK
# ==========================================================


@app.get("/auth/google/callback")

async def google_callback(

    request: Request

):


    try:


        token = await oauth.google.authorize_access_token(

            request

        )


        user = token.get(

            "userinfo"

        )


        if not user:


            user = await oauth.google.parse_id_token(

                request,

                token

            )



        request.session["user"] = {


            "name":

            user.get("name"),


            "email":

            user.get("email"),


            "picture":

            user.get("picture"),


            "role":

            "Workspace Member"

        }



        logger.info(

            f"Google Login : {user.get('email')}"

        )


        return RedirectResponse(

            "/dashboard"

        )



    except Exception as e:


        logger.exception(e)


        return failed(

            str(e),

            500

        )



# ==========================================================
# AUTH CHECK
# ==========================================================


@app.get("/api/auth/check")

async def auth_check(

    request: Request

):


    if is_logged_in(request):


        return {


            "authenticated": True,


            "user": get_user(request)

        }



    return {


        "authenticated": False

    }



# ==========================================================
# PROFILE API
# ==========================================================


@app.get("/api/profile")

async def profile(

    request: Request

):


    user = get_user(request)


    if not user:


        return failed(

            "Unauthorized",

            401

        )



    return success(

        user,

        "Profile Loaded"

    )



# ==========================================================
# PAGE ROUTE HELPER
# ==========================================================


def open_protected_page(

    request: Request,

    filename: str

):


    if not is_logged_in(request):


        return RedirectResponse(

            "/login"

        )



    return render_page(

        filename

    )



# ==========================================================
# ENTERPRISE PAGES
# ==========================================================


@app.get("/dashboard", response_class=HTMLResponse)

async def dashboard(request: Request):

    return open_protected_page(

        request,

        "dashboard.html"

    )



@app.get("/ai", response_class=HTMLResponse)

async def ai_workspace(request: Request):

    return open_protected_page(

        request,

        "ai.html"

    )



@app.get("/crm", response_class=HTMLResponse)

async def crm(request: Request):

    return open_protected_page(

        request,

        "crm.html"

    )



@app.get("/boq", response_class=HTMLResponse)

async def boq(request: Request):

    return open_protected_page(

        request,

        "boq.html"

    )



@app.get("/analytics", response_class=HTMLResponse)

async def analytics(request: Request):

    return open_protected_page(

        request,

        "analytics.html"

    )



@app.get("/finance", response_class=HTMLResponse)

async def finance(request: Request):

    return open_protected_page(

        request,

        "finance.html"

    )



@app.get("/vendors", response_class=HTMLResponse)

async def vendors(request: Request):

    return open_protected_page(

        request,

        "vendors.html"

    )



@app.get("/profile", response_class=HTMLResponse)

async def profile_page(request: Request):

    return open_protected_page(

        request,

        "profile.html"

    )



@app.get("/settings", response_class=HTMLResponse)

async def settings(request: Request):

    return open_protected_page(

        request,

        "settings.html"

    )



@app.get("/reports", response_class=HTMLResponse)

async def reports(request: Request):

    return open_protected_page(

        request,

        "reports.html"

    )



# ==========================================================
# PUBLIC PAGES
# ==========================================================


@app.get("/about", response_class=HTMLResponse)

async def about():

    return render_page(

        "about.html"

    )



@app.get("/contact", response_class=HTMLResponse)

async def contact():

    return render_page(

        "contact.html"

    )



@app.get("/services", response_class=HTMLResponse)

async def services():

    return render_page(

        "services.html"

    )


@app.get("/projects", response_class=HTMLResponse)

async def public_projects():

    return render_page(

        "projects.html"

    )


@app.get("/clients", response_class=HTMLResponse)

async def clients():

    return render_page(

        "clients.html"

    )

# ==========================================================
# PROJECT BOARD
# ==========================================================

@app.get("/projects-board", response_class=HTMLResponse)
async def projects_board(request: Request):
    return open_protected_page(request, "projects-board.html")


# ==========================================================
# CURRENT USER
# ==========================================================

@app.get("/me")
async def me(request: Request):
    user = get_user(request)
    if not user:
        return failed("Login Required", 401)
    return success(user, "Authenticated")


@app.get("/api/user")
async def current_user(request: Request):
    user = get_user(request)
    if not user:
        return failed("Unauthorized", 401)
    return success(user, "Current User Loaded")


# ==========================================================
# ERROR HANDLERS
# ==========================================================


@app.exception_handler(

    StarletteHTTPException

)

async def http_exception_handler(

    request: Request,

    exc: StarletteHTTPException

):


    return JSONResponse(

        status_code=exc.status_code,

        content={


            "success": False,


            "error": exc.detail,


            "status_code": exc.status_code

        }

    )



@app.exception_handler(

    RequestValidationError

)

async def validation_exception_handler(

    request: Request,

    exc: RequestValidationError

):


    return JSONResponse(

        status_code=422,

        content={


            "success": False,


            "error": "Validation Error",


            "details": exc.errors()

        }

    )



@app.exception_handler(Exception)

async def global_exception_handler(

    request: Request,

    exc: Exception

):


    logger.exception(exc)


    return JSONResponse(

        status_code=500,

        content={


            "success": False,


            "error": "Internal Server Error"

        }

    )
# ==========================================================
# HEALTH CHECK
# ==========================================================


@app.get("/health")
async def health():


    return {


        "success": True,


        "app": APP_NAME,


        "version": VERSION,


        "status": "running",


        "google_oauth": GOOGLE_OAUTH_ENABLED,

        "groq_ai": bool(GROQ_API_KEY),

        "groq_model": GROQ_MODEL,

        "comfyui": COMFYUI_ENABLED,

        "comfyui_url": COMFYUI_BASE_URL,

        "comfyui_image_model": COMFYUI_IMAGE_MODEL

    }



# ==========================================================
# BASIC STATUS
# ==========================================================


@app.get("/ping")
async def ping():


    return {


        "success": True,


        "message":

        "DPM Nexus Online"

    }



@app.get("/api/status")
async def system_status():


    return {


        "application":

        APP_NAME,


        "version":

        VERSION,


        "status":

        "online",


        "modules": {


            "ai": True,


            "crm": True,


            "boq": True,


            "analytics": True,


            "finance": True


        }

    }



@app.get("/api/version")
async def version():


    return {


        "name":

        APP_NAME,


        "version":

        VERSION,


        "edition":

        "Enterprise",


        "codename":

        "DPM Nexus V9 Optimized"

    }



@app.get("/alive")
async def alive():


    return {


        "alive":

        True,


        "service":

        APP_NAME

    }



@app.get("/ready")
async def ready():


    return {


        "ready":

        True,


        "database":

        "connected",


        "ai_engine":

        "configured"

        if GROQ_API_KEY

        else

        "not configured",

        "groq": bool(GROQ_API_KEY),

        "comfyui": COMFYUI_ENABLED

    }



# ==========================================================
# AI ENGINE BRIDGE — GROQ
# ==========================================================

# DPM Nexus uses Groq for text AI.
# OpenAI direct chat configuration has been removed.
# Groq exposes an OpenAI-compatible API, so the existing
# chat.completions interface can remain unchanged.

try:

    from openai import OpenAI

    if GROQ_API_KEY:

        ai_client = OpenAI(
            api_key=GROQ_API_KEY,
            base_url=GROQ_BASE_URL
        )

        logger.info(
            "Groq AI Client Initialized"
        )

    else:

        ai_client = None

        logger.warning(
            "Groq API Key Missing"
        )


except Exception as e:

    ai_client = None

    logger.error(
        f"Groq Client Init Failed : {e}"
    )


# ==========================================================
# AI SYSTEM PROMPT
# ==========================================================

AI_SYSTEM_PROMPT = """

You are DPM Nexus AI.

You are the enterprise AI assistant
for DPM ENTERPRISE PRIVATE LIMITED.

You help with:

- Interior Projects
- BOQ Preparation
- Tender Analysis
- CRM
- Business Strategy
- Project Management
- Corporate Documentation
- Enterprise Reports
- PDF / Word / Excel document preparation
- Image-generation prompts
- DPM Nexus workflow automation

Rules:

1. Give professional enterprise-level responses.
2. Do not invent company facts, rates, legal facts, or tender requirements.
3. When the user explicitly asks for PDF, Word, Excel, image, or video,
   provide the requested content and let the corresponding skill endpoint
   handle the file generation.
4. Normal questions must remain normal chat.
5. Never expose API keys or internal secrets.

"""


# ==========================================================
# AI REQUEST MODEL
# ==========================================================


class AIMessage(BaseModel):

    messages: list



# ==========================================================
# AI CHAT API
# ==========================================================


@app.post("/api/ai/chat")

async def ai_chat(

    data: AIMessage,

    request: Request

):


    if not is_logged_in(request):


        return failed(

            "Authentication Required",

            401

        )



    if not ai_client:


        return failed(

            "AI Engine Not Configured",

            500

        )



    try:


        messages = [


            {


                "role":

                "system",


                "content":

                AI_SYSTEM_PROMPT

            }


        ]



        messages.extend(

            data.messages

        )



        response = ai_client.chat.completions.create(


            model=GROQ_MODEL,


            messages=messages,


            temperature=0.7

        )



        answer = response.choices[0].message.content



        return {


            "success":

            True,


            "model":

            GROQ_MODEL,


            "response":

            answer

        }



    except Exception as e:


        logger.exception(e)


        return failed(

            str(e),

            500

        )



# ==========================================================
# AI STATUS
# ==========================================================


@app.get("/api/ai/status")

async def ai_status():


    return {


        "engine":

        "DPM Nexus AI",


        "status":

        "online"

        if ai_client

        else

        "offline",


        "model":

        AI_MODEL,

        "phase1_skills": {
            "pdf": "online",
            "word": "online",
            "excel": "online"
        }

    }



# ==========================================================
# DATABASE STATUS
# ==========================================================


@app.get("/api/database/status")

async def database_status():

    try:
        connection = engine.connect()
        connection.close()
        return {
            "success": True,
            "database": "online",
            "type": "PostgreSQL"
        }
    except Exception as e:
        return {
            "success": False,
            "database": "offline",
            "type": "PostgreSQL",
            "message": str(e)
        }



@app.get("/api/database/check")

async def database_check():


    try:


        connection = engine.connect()


        connection.close()



        return {


            "success":

            True,


            "message":

            "Database Connected"

        }



    except Exception as e:


        return {


            "success":

            False,


            "message":

            str(e)

        }



# ==========================================================
