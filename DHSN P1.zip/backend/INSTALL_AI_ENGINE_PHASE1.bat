@echo off
setlocal
title DPM Nexus AI Engine - Phase 1 Installer

echo ================================================
echo DPM NEXUS AI ENGINE - PHASE 1
echo PDF + WORD + EXCEL SKILLS
echo ================================================
echo.

cd /d "%~dp0"

echo [1/4] Installing required Python packages...
python -m pip install -r requirements_phase1.txt
if errorlevel 1 goto FAIL

echo.
echo [2/4] Checking target AI Engine...
if not exist "ai_engine" mkdir "ai_engine"
if not exist "ai_engine\skills" mkdir "ai_engine\skills"

echo.
echo [3/4] Backing up existing response.py...
if exist "ai_engine\response.py" (
    if not exist "ai_engine\response.py.phase1_backup" (
        copy /Y "ai_engine\response.py" "ai_engine\response.py.phase1_backup" >nul
    )
)

echo.
echo [4/4] Copying Phase-1 engine files...
copy /Y "package\ai_engine\skill_engine.py" "ai_engine\skill_engine.py" >nul
copy /Y "package\ai_engine\response.py" "ai_engine\response.py" >nul
copy /Y "package\ai_engine\__init__.py" "ai_engine\__init__.py" >nul
copy /Y "package\ai_engine\skills\__init__.py" "ai_engine\skills\__init__.py" >nul
copy /Y "package\ai_engine\skills\pdf_skill.py" "ai_engine\skills\pdf_skill.py" >nul
copy /Y "package\ai_engine\skills\word_skill.py" "ai_engine\skills\word_skill.py" >nul
copy /Y "package\ai_engine\skills\excel_skill.py" "ai_engine\skills\excel_skill.py" >nul

echo.
echo ================================================
echo PHASE 1 AI ENGINE INSTALLED
echo ================================================
echo Existing knowledge.py was NOT replaced.
echo Existing response.py backup:
echo ai_engine\response.py.phase1_backup
echo.
echo IMPORTANT:
echo Restart your FastAPI server after installation.
echo ================================================
pause
exit /b 0

:FAIL
echo.
echo INSTALLATION FAILED.
pause
exit /b 1
