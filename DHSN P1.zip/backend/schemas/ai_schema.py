from pydantic import BaseModel
from typing import Optional


class ChatRequest(BaseModel):
    message: str
    tool: Optional[str] = "general"
    model: Optional[str] = None


class SimpleRequest(BaseModel):
    prompt: str
    model: Optional[str] = None