# ==========================================================
# DPM NEXUS V9
# AUTH SCHEMAS - COMPATIBILITY VERSION
# ==========================================================

from typing import Optional

from pydantic import (
    AliasChoices,
    BaseModel,
    ConfigDict,
    EmailStr,
    Field,
)


class SendOTPRequest(BaseModel):

    model_config = ConfigDict(
        populate_by_name=True,
        str_strip_whitespace=True,
    )

    email: EmailStr = Field(
        validation_alias=AliasChoices(
            "email",
            "business_email",
            "businessEmail",
        ),
    )

    delivery_method: str = Field(default="email")


class VerifyOTPRequest(BaseModel):

    model_config = ConfigDict(
        populate_by_name=True,
        str_strip_whitespace=True,
    )

    email: EmailStr

    otp: str = Field(
        min_length=6,
        max_length=6,
        validation_alias=AliasChoices(
            "otp",
            "otp_code",
            "otpCode",
            "verification_otp",
            "verificationOtp",
        ),
    )

    delivery_method: str = Field(
        default="email",
        validation_alias=AliasChoices(
            "delivery_method",
            "deliveryMethod",
            "otp_method",
            "otpMethod",
        ),
    )


class RegisterRequest(BaseModel):

    model_config = ConfigDict(
        populate_by_name=True,
        str_strip_whitespace=True,
    )

    name: str = Field(
        min_length=2,
        max_length=150,
        validation_alias=AliasChoices(
            "name",
            "full_name",
            "fullName",
        ),
    )

    company_name: str = Field(
        min_length=2,
        max_length=200,
        validation_alias=AliasChoices(
            "company_name",
            "companyName",
            "company",
        ),
    )

    email: EmailStr = Field(
        validation_alias=AliasChoices(
            "email",
            "business_email",
            "businessEmail",
        ),
    )

    phone: str = Field(
        min_length=10,
        max_length=15,
        validation_alias=AliasChoices(
            "phone",
            "mobile",
            "mobile_number",
            "mobileNumber",
        ),
    )

    password: str = Field(
        min_length=8,
        max_length=128,
        validation_alias=AliasChoices(
            "password",
            "user_password",
        ),
    )

    otp: Optional[str] = Field(
        default=None,
        validation_alias=AliasChoices(
            "otp",
            "otp_code",
            "otpCode",
            "verification_otp",
            "verificationOtp",
        ),
    )

    delivery_method: str = Field(
        default="email",
        validation_alias=AliasChoices(
            "delivery_method",
            "deliveryMethod",
            "otp_method",
            "otpMethod",
        ),
    )

    confirm_password: Optional[str] = Field(
        default=None,
        validation_alias=AliasChoices(
            "confirm_password",
            "confirmPassword",
            "password_confirmation",
        ),
    )


class LoginRequest(BaseModel):

    model_config = ConfigDict(
        populate_by_name=True,
        str_strip_whitespace=True,
    )

    email: EmailStr
    password: str
