from pydantic import BaseModel, EmailStr, Field


class ContactInquiry(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=100)
    company_name: str = Field(..., min_length=2, max_length=150)
    email: EmailStr
    phone: str = Field(..., min_length=10, max_length=15)
    inquiry_type: str = Field(default="General Business Inquiry", max_length=120)
    location: str = Field(default="", max_length=200)
    subject: str = Field(default="Website Inquiry", max_length=200)
    message: str = Field(..., min_length=10, max_length=5000)
    timeline: str = Field(default="", max_length=200)
