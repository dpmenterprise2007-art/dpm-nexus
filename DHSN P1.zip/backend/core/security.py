# ==========================================================
# DPM NEXUS V9
# SECURITY CORE
# ==========================================================


import os

from datetime import datetime, timedelta


from jose import (

    JWTError,

    jwt

)


from passlib.context import CryptContext



SECRET_KEY = os.getenv(

    "JWT_SECRET",

    "dpm-nexus-secret-key"

)


ALGORITHM = "HS256"


TOKEN_EXPIRE_MINUTES = 60



pwd_context = CryptContext(

    schemes=["bcrypt"],

    deprecated="auto"

)



# ==========================================================
# PASSWORD HASH
# ==========================================================


def hash_password(password):

    return pwd_context.hash(

        password

    )



def verify_password(

    plain,

    hashed

):

    return pwd_context.verify(

        plain,

        hashed

    )



# ==========================================================
# CREATE JWT TOKEN
# ==========================================================


def create_token(data):


    payload = data.copy()


    expire = datetime.utcnow() + timedelta(

        minutes=TOKEN_EXPIRE_MINUTES

    )


    payload.update({

        "exp": expire

    })


    return jwt.encode(

        payload,

        SECRET_KEY,

        algorithm=ALGORITHM

    )



# ==========================================================
# VERIFY JWT
# ==========================================================


def verify_token(token):


    try:


        payload = jwt.decode(

            token,

            SECRET_KEY,

            algorithms=[ALGORITHM]

        )


        return payload


    except JWTError:


        return None