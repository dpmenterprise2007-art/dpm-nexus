from pydantic import BaseSettings

class Settings(BaseSettings):
    APP_NAME: str = "DHSN"
    VERSION: str = "100.0"
    SECRET_KEY: str = "CHANGE_THIS_LATER"

settings = Settings()