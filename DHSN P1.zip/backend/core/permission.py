# ==========================================================
# DPM NEXUS V9
# PERMISSION ROUTER
# ==========================================================


from fastapi import APIRouter


from core.permissions import DEFAULT_ROLES



router = APIRouter(

    prefix="/api/permissions",

    tags=["RBAC"]

)



# ==========================================================
# GET ROLES
# ==========================================================


@router.get("/roles")

async def get_roles():


    return {


        "success": True,

        "roles": DEFAULT_ROLES

    }



# ==========================================================
# CHECK ACCESS
# ==========================================================


@router.get("/check")

async def check_access(

    role: str,

    module: str

):


    allowed = module in DEFAULT_ROLES.get(

        role,

        []

    )


    if "ALL" in DEFAULT_ROLES.get(role, []):

        allowed = True



    return {


        "success": True,

        "role": role,

        "module": module,

        "allowed": allowed

    }