# ==========================================================
# DPM NEXUS V9
# GLOBAL SEARCH ENGINE CORE
# ==========================================================


def normalize_text(text):

    if not text:

        return ""

    return text.lower().strip()



def search_match(

    source,

    keyword

):


    keyword = normalize_text(keyword)


    results = []


    for item in source:


        item_text = normalize_text(

            str(item)

        )


        if keyword in item_text:


            results.append(item)


    return results