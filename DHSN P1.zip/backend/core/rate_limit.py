# ==========================================================
# SIMPLE RATE LIMITER
# ==========================================================


from time import time



requests = {}



def check_limit(

    ip,

    limit=100

):


    now = time()


    if ip not in requests:

        requests[ip] = []



    requests[ip] = [

        t for t in requests[ip]

        if now - t < 60

    ]



    if len(requests[ip]) >= limit:

        return False



    requests[ip].append(

        now

    )


    return True