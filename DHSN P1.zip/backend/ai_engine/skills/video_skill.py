"""DPM Nexus AI Video Skill.

Creates a professional MP4 from supplied image assets using ffmpeg. This is a
rendering/composition skill; it does not pretend to be an AI text-to-video
provider. A future provider can be plugged in through the same interface.
"""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile


def generate_from_images(images, output_path, *, duration=4, fps=30, title=None):
    paths = [Path(x) for x in images if Path(x).exists()]
    if not paths:
        raise ValueError("At least one existing image is required for video generation.")
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ffmpeg is not installed or is not available in PATH.")

    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        concat = Path(td) / "concat.txt"
        lines = []
        for p in paths:
            lines.append("file '" + str(p.resolve()).replace("'", "'\\''") + "'")
            lines.append(f"duration {float(duration):.3f}")
        lines.append("file '" + str(paths[-1].resolve()).replace("'", "'\\''") + "'")
        concat.write_text("\n".join(lines), encoding="utf-8")

        vf = "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,format=yuv420p"
        cmd = [ffmpeg, "-y", "-f", "concat", "-safe", "0", "-i", str(concat), "-vf", vf, "-r", str(fps), "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-movflags", "+faststart", str(output)]
        subprocess.run(cmd, check=True, capture_output=True, text=True)
    return str(output), "video/mp4"
