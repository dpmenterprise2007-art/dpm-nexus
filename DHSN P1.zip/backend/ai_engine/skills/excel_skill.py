from ai_engine.skill_engine import generate_file


def generate(title, content):
    return generate_file("excel", title, content)
