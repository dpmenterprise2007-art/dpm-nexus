"""Shared document-artifact cleaner for DPM Nexus AI.

Use this before passing an AI answer to PDF/Word/Excel generation so the file
contains the requested deliverable rather than conversational wrapper text.
"""
from ai_engine.skill_engine import clean_artifact_content

__all__ = ["clean_artifact_content"]
