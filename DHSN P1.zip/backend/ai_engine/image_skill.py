
"""DPM Nexus V9 image skill: Cloudflare FLUX primary, ComfyUI preserved."""
from __future__ import annotations

import base64
import json
import os
import re
import time
import uuid
from pathlib import Path
from typing import Optional

import requests
from dotenv import load_dotenv

# Load the backend .env file explicitly.
BACKEND_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BACKEND_DIR / ".env", override=False)

CF_MODEL = "@cf/black-forest-labs/flux-1-schnell"
CF_API = "https://api.cloudflare.com/client/v4"


def _env(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


def _safe_filename(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", str(value or "").strip())
    return re.sub(r"_+", "_", value).strip("._")[:90] or "DPM_Nexus_AI_Image"


def _build_prompt(title: str, prompt: str) -> str:
    return f"""Create a premium professional visual for DPM ENTERPRISE PRIVATE LIMITED.
Title: {str(title or 'DPM Nexus AI Image').strip()}
User brief: {str(prompt or '').strip()}
Art direction: premium photorealism, realistic lighting and materials,
refined commercial composition, believable proportions, light premium
corporate aesthetic where suitable. Do not invent or approximate a company
logo. Do not add random text, watermarks, phone numbers or contact details.
Render only text explicitly requested."""


# ---------------- Cloudflare Workers AI / FLUX ----------------

def _cloudflare_ready() -> bool:
    return bool(
        _env("CLOUDFLARE_ACCOUNT_ID")
        and _env("CLOUDFLARE_API_TOKEN")
        and _env("CLOUDFLARE_IMAGE_MODEL", CF_MODEL)
    )


def _cloudflare_generate(
    prompt: str, title: str, timeout: int = 180
) -> bytes:
    account = _env("CLOUDFLARE_ACCOUNT_ID")
    token = _env("CLOUDFLARE_API_TOKEN")
    model = _env("CLOUDFLARE_IMAGE_MODEL", CF_MODEL)

    if not account or not token:
        raise RuntimeError(
            "Cloudflare credentials missing. Check CLOUDFLARE_ACCOUNT_ID "
            "and CLOUDFLARE_API_TOKEN in backend/.env."
        )

    url = f"{CF_API}/accounts/{account}/ai/run/{model}"
    payload = {"prompt": _build_prompt(title, prompt)}

    try:
        response = requests.post(
            url,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
                "Accept": "image/*, application/json",
            },
            json=payload,
            timeout=timeout,
        )
    except requests.RequestException as exc:
        raise RuntimeError(
            f"Cloudflare image request failed: {exc}"
        ) from exc

    if not response.ok:
        try:
            detail = response.json()
        except Exception:
            detail = response.text[:1500]
        raise RuntimeError(
            f"Cloudflare Workers AI HTTP {response.status_code}: {detail}"
        )

    content_type = (
        response.headers.get("Content-Type") or ""
    ).lower()

    # FLUX normally returns the generated image as binary data.
    if content_type.startswith("image/") and response.content:
        return response.content

    # Also support JSON responses containing base64 image data.
    try:
        data = response.json()
    except Exception as exc:
        raise RuntimeError(
            "Cloudflare returned an unexpected image response."
        ) from exc

    containers = [data]
    if isinstance(data, dict) and isinstance(data.get("result"), dict):
        containers.append(data["result"])

    for container in containers:
        if not isinstance(container, dict):
            continue
        for key in ("image", "b64_json", "image_base64"):
            value = container.get(key)
            if isinstance(value, str) and value:
                try:
                    return base64.b64decode(value, validate=True)
                except Exception as exc:
                    raise RuntimeError(
                        "Cloudflare returned invalid base64 image data."
                    ) from exc

    raise RuntimeError(
        "Cloudflare response did not contain image bytes."
    )


# ---------------- Existing ComfyUI provider ----------------

def _comfy_status() -> dict:
    enabled = _env("COMFYUI_ENABLED", "true").lower() == "true"
    workflow = _env("COMFYUI_WORKFLOW")

    return {
        "provider": "ComfyUI Local",
        "model": _env("COMFYUI_IMAGE_MODEL", "local-workflow"),
        "configured": bool(
            enabled
            and _env("COMFYUI_BASE_URL", "http://127.0.0.1:8188")
            and workflow
        ),
        "enabled": enabled,
        "base_url": _env(
            "COMFYUI_BASE_URL", "http://127.0.0.1:8188"
        ),
        "workflow": workflow,
    }


def _comfy_headers() -> dict:
    key = _env("COMFYUI_API_KEY")
    headers = {"Accept": "application/json"}

    if key:
        headers["Authorization"] = f"Bearer {key}"
        headers["X-API-Key"] = key

    return headers


def _load_workflow() -> dict:
    raw_path = _env("COMFYUI_WORKFLOW")

    if not raw_path:
        raise RuntimeError(
            "Set COMFYUI_WORKFLOW to an exported ComfyUI API workflow JSON."
        )

    path = Path(raw_path)
    if not path.is_absolute():
        path = BACKEND_DIR / path

    if not path.exists():
        raise RuntimeError(f"ComfyUI workflow not found: {path}")

    try:
        workflow = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise RuntimeError(
            f"Invalid ComfyUI workflow JSON: {path}"
        ) from exc

    if not isinstance(workflow, dict):
        raise RuntimeError(
            "ComfyUI API workflow must be an object keyed by node IDs."
        )

    return workflow


def _set_comfy_prompt(workflow: dict, prompt: str) -> None:
    configured_id = _env("COMFYUI_POSITIVE_NODE_ID")

    if configured_id and configured_id in workflow:
        node = workflow[configured_id]
        inputs = node.setdefault("inputs", {})

        if "text" in inputs:
            inputs["text"] = prompt
            return
        if "prompt" in inputs:
            inputs["prompt"] = prompt
            return

        raise RuntimeError(
            "Configured ComfyUI positive node has no text/prompt input."
        )

    candidates = []

    for node_id, node in workflow.items():
        if not isinstance(node, dict):
            continue

        inputs = node.get("inputs") or {}
        title = str(
            (node.get("_meta") or {}).get("title", "")
        ).lower()
        class_type = str(node.get("class_type", "")).lower()

        if not ("text" in inputs or "prompt" in inputs):
            continue
        if "negative" in title or "negative" in class_type:
            continue

        priority = 0 if (
            "positive" in title or "prompt" in title
        ) else 1

        candidates.append((priority, node_id, node))

    candidates.sort(key=lambda item: item[0])

    if not candidates:
        raise RuntimeError(
            "No positive text/prompt input found in ComfyUI workflow."
        )

    node = candidates[0][2]
    inputs = node.setdefault("inputs", {})

    if "text" in inputs:
        inputs["text"] = prompt
    elif "prompt" in inputs:
        inputs["prompt"] = prompt
    else:
        raise RuntimeError(
            "ComfyUI prompt node has no text/prompt input."
        )


def _comfy_generate(
    prompt: str, title: str, timeout: int = 300
) -> bytes:
    status = _comfy_status()

    if not status["enabled"]:
        raise RuntimeError(
            "ComfyUI is disabled. Set COMFYUI_ENABLED=true."
        )

    if not status["configured"]:
        raise RuntimeError(
            "ComfyUI workflow is not configured. Set COMFYUI_WORKFLOW "
            "in backend/.env."
        )

    base = status["base_url"].rstrip("/")
    headers = _comfy_headers()

    try:
        ping = requests.get(
            f"{base}/system_stats", headers=headers, timeout=15
        )
        if not ping.ok:
            raise RuntimeError(
                f"ComfyUI health check HTTP {ping.status_code}: "
                f"{ping.text[:500]}"
            )

        workflow = _load_workflow()
        _set_comfy_prompt(
            workflow, _build_prompt(title, prompt)
        )

        queued = requests.post(
            f"{base}/prompt",
            headers={
                **headers,
                "Content-Type": "application/json",
            },
            json={
                "prompt": workflow,
                "client_id": str(uuid.uuid4()),
            },
            timeout=60,
        )

        if not queued.ok:
            raise RuntimeError(
                f"ComfyUI /prompt HTTP {queued.status_code}: "
                f"{queued.text[:1200]}"
            )

        prompt_id = queued.json().get("prompt_id")
        if not prompt_id:
            raise RuntimeError(
                f"ComfyUI did not return prompt_id: {queued.text[:800]}"
            )

        deadline = time.time() + timeout

        while time.time() < deadline:
            history_response = requests.get(
                f"{base}/history/{prompt_id}",
                headers=headers,
                timeout=30,
            )

            if history_response.ok:
                record = history_response.json().get(prompt_id)

                if record:
                    status_data = record.get("status") or {}

                    if status_data.get("status_str") == "error":
                        raise RuntimeError(
                            "ComfyUI workflow failed: "
                            f"{status_data.get('messages')}"
                        )

                    outputs = record.get("outputs") or {}

                    for output in outputs.values():
                        for image_info in output.get("images", []) or []:
                            filename = image_info.get("filename")
                            if not filename:
                                continue

                            image_response = requests.get(
                                f"{base}/view",
                                params={
                                    "filename": filename,
                                    "subfolder": image_info.get(
                                        "subfolder", ""
                                    ),
                                    "type": image_info.get(
                                        "type", "output"
                                    ),
                                },
                                headers=headers,
                                timeout=120,
                            )

                            if (
                                image_response.ok
                                and image_response.content
                            ):
                                return image_response.content

            time.sleep(1.5)

        raise RuntimeError(
            f"ComfyUI image generation timed out after {timeout}s."
        )

    except requests.RequestException as exc:
        raise RuntimeError(
            f"Cannot connect to ComfyUI at {base}: {exc}"
        ) from exc


# ---------------- Public API: names retained ----------------

def image_status() -> dict:
    """Return provider status without exposing secrets."""
    provider = _env("IMAGE_PROVIDER", "cloudflare").lower()

    if provider == "comfyui":
        return _comfy_status()

    if provider != "cloudflare":
        return {
            "provider": provider,
            "configured": False,
            "enabled": False,
            "error": "Unsupported IMAGE_PROVIDER.",
        }

    comfy = _comfy_status()

    return {
        "provider": "Cloudflare Workers AI",
        "model": _env("CLOUDFLARE_IMAGE_MODEL", CF_MODEL),
        "configured": _cloudflare_ready(),
        "enabled": True,
        "base_url": CF_API,
        "fallback_provider": (
            "ComfyUI Local" if comfy["configured"] else None
        ),
    }


def generate_image(
    prompt: str,
    title: str = "DPM Nexus AI Image",
    *,
    timeout: int = 300,
    size: Optional[str] = None,
    quality: Optional[str] = None,
) -> bytes:
    """Return generated image bytes; keep existing function signature."""
    if not str(prompt or "").strip():
        raise ValueError("Image prompt is required.")

    provider = _env("IMAGE_PROVIDER", "cloudflare").lower()

    if provider == "cloudflare":
        cf_timeout = int(
            _env(
                "CLOUDFLARE_IMAGE_TIMEOUT",
                str(min(timeout, 180)),
            )
        )
        return _cloudflare_generate(
            prompt, title, cf_timeout
        )

    if provider == "comfyui":
        return _comfy_generate(prompt, title, timeout)

    raise RuntimeError(
        f"Unsupported IMAGE_PROVIDER={provider!r}. "
        "Use 'cloudflare' or 'comfyui'."
    )


def generate_image_file(
    prompt: str,
    title: str = "DPM Nexus AI Image",
    **kwargs,
):
    """Return (filename, MIME type, image bytes) for existing routes."""
    raw = generate_image(prompt, title, **kwargs)
    filename = _safe_filename(title)

    if raw.startswith(b"\x89PNG\r\n\x1a\n"):
        return f"{filename}.png", "image/png", raw

    if raw.startswith(b"RIFF") and raw[8:12] == b"WEBP":
        return f"{filename}.webp", "image/webp", raw

    if raw.startswith(b"\xff\xd8\xff"):
        return f"{filename}.jpg", "image/jpeg", raw

    # ComfyUI workflows may produce PNG; Cloudflare FLUX commonly produces JPEG.
    provider = _env("IMAGE_PROVIDER", "cloudflare").lower()
    if provider == "comfyui":
        return f"{filename}.png", "image/png", raw

    # Keep bytes available for diagnosis instead of silently altering them.
    return f"{filename}.jpg", "image/jpeg", raw
