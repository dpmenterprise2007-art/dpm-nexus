"""
DPM Nexus AI Engine — V2 Premium Document Skills
Preserves generate_file(skill, title, content) API.
PDF: premium DPM Enterprise + DPM Nexus AI corporate layout.
Word: professional header/footer, styles, hierarchy and tables.
Excel: structured workbook, title band, metadata, wrapped cells, filters,
       freeze panes, print setup and auto-sized columns.
"""
from io import BytesIO
from datetime import datetime
from html import escape
from pathlib import Path
import re

SKILLS = {
    "pdf": {"name": "PDF Skill", "extension": ".pdf", "mime": "application/pdf"},
    "word": {"name": "Word Skill", "extension": ".docx", "mime": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"},
    "excel": {"name": "Excel Skill", "extension": ".xlsx", "mime": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"},
}


def available_skills():
    return SKILLS.copy()


def generate_file(skill: str, title: str, content: str):
    skill = (skill or "").strip().lower()
    if skill not in SKILLS:
        raise ValueError("Unsupported skill. Use pdf, word or excel.")
    if not str(content or "").strip():
        raise ValueError("Content is required.")
    if skill == "pdf":
        data = _pdf(title, content)
    elif skill == "word":
        data = _word(title, content)
    else:
        data = _excel(title, content)
    safe = _safe_filename(title) or "DPM_Nexus_AI_Output"
    return safe + SKILLS[skill]["extension"], SKILLS[skill]["mime"], data


def _safe_filename(value):
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", str(value or "").strip())
    value = re.sub(r"_+", "_", value).strip("._")
    return value[:90] or "DPM_Nexus_AI_Output"


def _find_logo():
    here = Path(__file__).resolve().parent
    candidates = [
        here.parent / "frontend" / "images" / "logos" / "dpmlogo1.jpg",
        here.parent.parent / "frontend" / "images" / "logos" / "dpmlogo1.jpg",
        here.parent / "images" / "logos" / "dpmlogo1.jpg",
        Path.cwd() / "frontend" / "images" / "logos" / "dpmlogo1.jpg",
        Path.cwd() / "images" / "logos" / "dpmlogo1.jpg",
    ]
    return next((str(p) for p in candidates if p.exists()), None)


def _font_names():
    """Return a Unicode font that contains Devanagari + Latin glyphs.

    The old implementation preferred Segoe UI. Segoe UI is not a reliable
    Devanagari font, so ReportLab replaced Hindi characters with boxes.
    DPM Nexus now ships Noto Sans Devanagari with the backend and prefers it.
    Windows Nirmala UI/Mangal are supported as fallbacks.
    """
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont

    here = Path(__file__).resolve().parent / "fonts" / "NotoSansDevanagari-Regular.ttf"
    bundled = here / "fonts"
    candidates = [
        (bundled / "NotoSansDevanagari-Regular.ttf", bundled / "NotoSansDevanagari-Bold.ttf"),
        (Path("C:/Windows/Fonts/Nirmala.ttf"), Path("C:/Windows/Fonts/NirmalaB.ttf")),
        (Path("C:/Windows/Fonts/mangal.ttf"), Path("C:/Windows/Fonts/mangalb.ttf")),
        (Path("/usr/share/fonts/truetype/noto/NotoSansDevanagari-Regular.ttf"), Path("/usr/share/fonts/truetype/noto/NotoSansDevanagari-Bold.ttf")),
        (Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"), Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")),
    ]

    for reg, bold in candidates:
        if reg.exists() and bold.exists():
            try:
                # Use unique names so repeated hot-reload imports do not collide.
                if "DPMUnicode" not in pdfmetrics.getRegisteredFontNames():
                    pdfmetrics.registerFont(TTFont("DPMUnicode", str(reg)))
                if "DPMUnicodeBold" not in pdfmetrics.getRegisteredFontNames():
                    pdfmetrics.registerFont(TTFont("DPMUnicodeBold", str(bold)))
                return "DPMUnicode", "DPMUnicodeBold"
            except Exception:
                continue
    return "Helvetica", "Helvetica-Bold"


def _parse_content(content):
    """Parse common AI markdown into typed blocks without requiring markdown libs."""
    blocks = []
    lines = str(content or "").replace("\r", "").split("\n")
    i = 0
    while i < len(lines):
        raw = lines[i].strip()
        if not raw:
            i += 1; continue
        if raw.startswith("### "):
            blocks.append(("h2", raw[4:].strip())); i += 1; continue
        if raw.startswith("## "):
            blocks.append(("h1", raw[3:].strip())); i += 1; continue
        if raw.startswith("# "):
            blocks.append(("title", raw[2:].strip())); i += 1; continue
        if raw.startswith("-") or raw.startswith("•") or re.match(r"^\d+[.)]\s+", raw):
            items = []
            while i < len(lines):
                s = lines[i].strip()
                if not (s.startswith("-") or s.startswith("•") or re.match(r"^\d+[.)]\s+", s)):
                    break
                items.append(re.sub(r"^(?:[-•]|\d+[.)])\s*", "", s)); i += 1
            blocks.append(("list", items)); continue
        if "|" in raw and i + 1 < len(lines) and "|" in lines[i+1]:
            table = []
            while i < len(lines) and "|" in lines[i].strip():
                s = lines[i].strip().strip("|")
                if not s: break
                cells = [c.strip() for c in s.split("|")]
                if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                    table.append(cells)
                i += 1
            if table: blocks.append(("table", table)); continue
        blocks.append(("p", raw)); i += 1
    return blocks


def _pdf(title, content):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_LEFT
    from reportlab.lib.units import mm
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether

    out = BytesIO(); W, H = A4
    FONT, BOLD = _font_names()
    NAVY = colors.HexColor("#0A1730"); BLUE = colors.HexColor("#1756B8"); RED = colors.HexColor("#B5122B")
    MUTED = colors.HexColor("#68758A"); LINE = colors.HexColor("#DCE3EC"); PALE = colors.HexColor("#F5F8FC")
    PALE_BLUE = colors.HexColor("#EEF5FF"); INK = colors.HexColor("#172033"); WHITE = colors.white
    logo = _find_logo()

    def chrome(canvas, doc):
        canvas.saveState()
        canvas.setFillColor(BLUE); canvas.rect(0, H-3.2*mm, W, 1.6*mm, fill=1, stroke=0)
        canvas.setFillColor(RED); canvas.rect(0, H-4.8*mm, W, 1.6*mm, fill=1, stroke=0)
        if logo:
            try: canvas.drawImage(logo, 17*mm, H-25.5*mm, width=25*mm, height=18*mm, preserveAspectRatio=True, mask="auto")
            except Exception: pass
        canvas.setFillColor(NAVY); canvas.setFont(BOLD, 10.5); canvas.drawString(47*mm, H-12.5*mm, "DPM ENTERPRISE PRIVATE LIMITED")
        canvas.setFillColor(MUTED); canvas.setFont(FONT, 7.2); canvas.drawString(47*mm, H-17*mm, "Enterprise Interior • Turnkey • Commercial Solutions")
        canvas.setFillColor(PALE_BLUE); canvas.roundRect(W-72*mm, H-22.5*mm, 55*mm, 12.5*mm, 2.5*mm, fill=1, stroke=0)
        canvas.setFillColor(BLUE); canvas.setFont(BOLD, 8); canvas.drawString(W-67.5*mm, H-15*mm, "DPM NEXUS AI")
        canvas.setFillColor(MUTED); canvas.setFont(FONT, 6.3); canvas.drawString(W-67.5*mm, H-19.1*mm, "Enterprise Intelligence")
        canvas.setStrokeColor(LINE); canvas.setLineWidth(.55); canvas.line(17*mm, H-29*mm, W-17*mm, H-29*mm); canvas.line(17*mm, 18*mm, W-17*mm, 18*mm)
        canvas.setFillColor(MUTED); canvas.setFont(FONT, 6.8); canvas.drawString(17*mm, 11.7*mm, "DPM ENTERPRISE PRIVATE LIMITED")
        canvas.setFillColor(NAVY); canvas.setFont(BOLD, 6.8); canvas.drawString(67*mm, 11.7*mm, "DPM NEXUS AI")
        canvas.setFillColor(MUTED); canvas.setFont(FONT, 6.6); canvas.drawString(17*mm, 7.3*mm, "Corporate Document • Controlled Digital Copy")
        canvas.drawRightString(W-17*mm, 11.7*mm, f"Page {doc.page:02d}")
        canvas.drawRightString(W-17*mm, 7.3*mm, "CONFIDENTIAL • FOR AUTHORISED USE")
        canvas.restoreState()

    doc = SimpleDocTemplate(out, pagesize=A4, leftMargin=17*mm, rightMargin=17*mm, topMargin=36*mm, bottomMargin=25*mm,
                            title=str(title), author="DPM Enterprise Private Limited • DPM Nexus AI")
    title_style = ParagraphStyle("DPMTitle", fontName=BOLD, fontSize=23, leading=28, textColor=NAVY, spaceAfter=6)
    sub = ParagraphStyle("DPMSub", fontName=FONT, fontSize=8.8, leading=13, textColor=MUTED, spaceAfter=12)
    h1 = ParagraphStyle("DPMH1", fontName=BOLD, fontSize=14, leading=18, textColor=NAVY, spaceBefore=10, spaceAfter=6, keepWithNext=True)
    h2 = ParagraphStyle("DPMH2", fontName=BOLD, fontSize=10.5, leading=14, textColor=BLUE, spaceBefore=7, spaceAfter=4, keepWithNext=True)
    body = ParagraphStyle("DPMBody", fontName=FONT, fontSize=9.1, leading=14, textColor=INK, spaceAfter=6)
    bullet = ParagraphStyle("DPMBullet", parent=body, leftIndent=6*mm, firstLineIndent=-4*mm)
    small = ParagraphStyle("DPMSmall", fontName=FONT, fontSize=7, leading=9.5, textColor=MUTED)

    story = [Paragraph(escape(str(title or "DPM Nexus AI Document")), title_style), Paragraph("Generated by DPM Nexus AI • DPM Enterprise Private Limited", sub)]
    for kind, val in _parse_content(content):
        if kind in ("title", "h1"):
            story.append(Paragraph(escape(val), h1))
        elif kind == "h2":
            story.append(Paragraph(escape(val), h2))
        elif kind == "p":
            story.append(Paragraph(escape(val).replace("  ", "&nbsp;&nbsp;"), body))
        elif kind == "list":
            for item in val: story.append(Paragraph("• " + escape(item), bullet))
        elif kind == "table":
            data = [[Paragraph(escape(str(c)), small) for c in row] for row in val]
            if data:
                cols = max(len(r) for r in data); data = [r + [Paragraph("", small)]*(cols-len(r)) for r in data]
                widths = [176*mm/cols]*cols
                t = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
                t.setStyle(TableStyle([
                    ("BACKGROUND", (0,0), (-1,0), NAVY), ("TEXTCOLOR", (0,0), (-1,0), WHITE),
                    ("GRID", (0,0), (-1,-1), .35, LINE), ("VALIGN", (0,0), (-1,-1), "TOP"),
                    ("LEFTPADDING", (0,0), (-1,-1), 3*mm), ("RIGHTPADDING", (0,0), (-1,-1), 3*mm),
                    ("TOPPADDING", (0,0), (-1,-1), 2.5*mm), ("BOTTOMPADDING", (0,0), (-1,-1), 2.5*mm),
                    ("ROWBACKGROUNDS", (0,1), (-1,-1), [WHITE, PALE]),
                ])); story += [Spacer(1, 2*mm), t, Spacer(1, 4*mm)]
    story += [Spacer(1, 3*mm), Table([[Paragraph("<b>DPM NEXUS AI</b><br/>Enterprise Intelligence • Document Generation • Business Workflow", body)]], colWidths=[176*mm], style=TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), PALE_BLUE), ("BOX", (0,0), (-1,-1), .5, colors.HexColor("#C9DBF7")),
        ("LINEBEFORE", (0,0), (0,0), 1.8*mm, BLUE), ("LEFTPADDING", (0,0), (-1,-1), 5*mm),
        ("RIGHTPADDING", (0,0), (-1,-1), 5*mm), ("TOPPADDING", (0,0), (-1,-1), 3.5*mm), ("BOTTOMPADDING", (0,0), (-1,-1), 3.5*mm)
    ])), Spacer(1, 4*mm), Paragraph("Generated: " + datetime.now().strftime("%d-%m-%Y %H:%M"), small)]
    doc.build(story, onFirstPage=chrome, onLaterPages=chrome)
    return out.getvalue()


def _word(title, content):
    from docx import Document
    from docx.shared import Pt, Inches, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.section import WD_SECTION
    from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    doc = Document(); sec = doc.sections[0]
    sec.top_margin = Inches(.75); sec.bottom_margin = Inches(.7); sec.left_margin = Inches(.75); sec.right_margin = Inches(.75)
    sec.header_distance = Inches(.25); sec.footer_distance = Inches(.3)
    styles = doc.styles
    styles["Normal"].font.name = "Nirmala UI"; styles["Normal"].font.size = Pt(10)
    for name, size, color in [("Title", 23, "0A1730"), ("Heading 1", 15, "0A1730"), ("Heading 2", 11, "1756B8")]:
        st = styles[name]; st.font.name = "Nirmala UI"; st.font.size = Pt(size); st.font.bold = True; st.font.color.rgb = RGBColor.from_string(color)
    for st in [styles["Normal"], styles["Title"], styles["Heading 1"], styles["Heading 2"]]:
        st._element.rPr.rFonts.set(qn("w:ascii"), "Nirmala UI")
        st._element.rPr.rFonts.set(qn("w:hAnsi"), "Nirmala UI")
        st._element.rPr.rFonts.set(qn("w:cs"), "Nirmala UI")

    header = sec.header.paragraphs[0]; header.alignment = WD_ALIGN_PARAGRAPH.LEFT
    r = header.add_run("DPM ENTERPRISE PRIVATE LIMITED"); r.bold=True; r.font.size=Pt(10); r.font.color.rgb=RGBColor(10,23,48)
    header.add_run("   |   DPM NEXUS AI • Enterprise Intelligence").font.size=Pt(8)
    p = sec.footer.paragraphs[0]; p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.add_run("Corporate Document • Controlled Digital Copy   |   ").font.size=Pt(8)
    field = OxmlElement("w:fldSimple"); field.set(qn("w:instr"), "PAGE"); p._p.append(field)

    doc.add_heading(str(title), level=0)
    meta = doc.add_paragraph("DPM Enterprise Private Limited  •  Generated by DPM Nexus AI  •  " + datetime.now().strftime("%d-%m-%Y %H:%M"))
    meta.runs[0].font.size=Pt(8); meta.runs[0].font.color.rgb=RGBColor(104,117,138)

    for kind, val in _parse_content(content):
        if kind in ("title", "h1"): doc.add_heading(val, level=1)
        elif kind == "h2": doc.add_heading(val, level=2)
        elif kind == "p": doc.add_paragraph(val)
        elif kind == "list":
            for item in val: doc.add_paragraph(item, style="List Bullet")
        elif kind == "table":
            rows = len(val); cols = max(len(r) for r in val)
            table = doc.add_table(rows=rows, cols=cols); table.alignment=WD_TABLE_ALIGNMENT.CENTER; table.style="Table Grid"
            for ri,row in enumerate(val):
                for ci in range(cols):
                    cell=table.cell(ri,ci); cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.TOP
                    cell.text = row[ci] if ci < len(row) else ""
                    if ri==0:
                        for rr in cell.paragraphs[0].runs: rr.bold=True
                        tcPr=cell._tc.get_or_add_tcPr(); shd=OxmlElement("w:shd"); shd.set(qn("w:fill"),"0A1730"); tcPr.append(shd)
                        for rr in cell.paragraphs[0].runs: rr.font.color.rgb=RGBColor(255,255,255)
    out=BytesIO(); doc.save(out); return out.getvalue()


def _excel(title, content):
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.page import PageMargins

    wb=Workbook(); ws=wb.active; ws.title="DPM AI Output"
    navy="0A1730"; blue="1756B8"; red="B5122B"; pale="EEF5FF"; line="DCE3EC"
    ws.merge_cells("A1:H1"); ws["A1"]=str(title or "DPM Nexus AI Output"); ws["A1"].font=Font(name="Aptos Display",size=18,bold=True,color="FFFFFF"); ws["A1"].fill=PatternFill("solid",fgColor=navy); ws["A1"].alignment=Alignment(vertical="center")
    ws.row_dimensions[1].height=30
    ws.merge_cells("A2:H2"); ws["A2"]="DPM ENTERPRISE PRIVATE LIMITED  •  DPM NEXUS AI  •  Generated " + datetime.now().strftime("%d-%m-%Y %H:%M"); ws["A2"].font=Font(size=9,color="68758A"); ws["A2"].alignment=Alignment(vertical="center")
    blocks=_parse_content(content); row=4; thin=Side(style="thin",color=line)
    for kind,val in blocks:
        if kind in ("title","h1","h2"):
            ws.merge_cells(start_row=row,start_column=1,end_row=row,end_column=8); c=ws.cell(row,1,val); c.font=Font(size=13 if kind!="h2" else 11,bold=True,color=blue if kind=="h2" else navy); c.fill=PatternFill("solid",fgColor=pale); c.alignment=Alignment(vertical="center",wrap_text=True); row+=1
        elif kind=="p":
            ws.merge_cells(start_row=row,start_column=1,end_row=row,end_column=8); c=ws.cell(row,1,val); c.alignment=Alignment(wrap_text=True,vertical="top"); row+=1
        elif kind=="list":
            for item in val:
                ws.merge_cells(start_row=row,start_column=1,end_row=row,end_column=8); c=ws.cell(row,1,"• "+item); c.alignment=Alignment(wrap_text=True,vertical="top"); row+=1
        elif kind=="table":
            data=val; cols=max(len(x) for x in data)
            for ri,arr in enumerate(data):
                for ci in range(cols):
                    c=ws.cell(row+ri,ci+1,arr[ci] if ci<len(arr) else ""); c.alignment=Alignment(wrap_text=True,vertical="top"); c.border=Border(left=thin,right=thin,top=thin,bottom=thin)
                    if ri==0: c.font=Font(bold=True,color="FFFFFF"); c.fill=PatternFill("solid",fgColor=navy)
            ws.auto_filter.ref=f"A{row}:{get_column_letter(cols)}{row+len(data)-1}"; row+=len(data)+2
    for col in range(1,9): ws.column_dimensions[get_column_letter(col)].width=18
    ws.column_dimensions["A"].width=24
    ws.freeze_panes="A4"; ws.sheet_view.showGridLines=False
    ws.print_title_rows="1:3"; ws.page_setup.orientation="landscape"; ws.page_setup.fitToWidth=1; ws.page_setup.fitToHeight=0; ws.sheet_properties.pageSetUpPr.fitToPage=True
    ws.page_margins=PageMargins(left=.25,right=.25,top=.5,bottom=.5,header=.2,footer=.2)
    ws.oddFooter.center.text="DPM ENTERPRISE PRIVATE LIMITED  •  DPM NEXUS AI  •  Page &P of &N"
    out=BytesIO(); wb.save(out); return out.getvalue()
