from __future__ import annotations

import base64
import os
import re
from pathlib import Path

import requests
from dotenv import load_dotenv

BASE = Path(__file__).resolve().parent.parent
load_dotenv(BASE / ".env")


def _env(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


def _safe_filename(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", str(value or "").strip())
    return re.sub(r"_+", "_", value).strip("._")[:90] or "DPM_Nexus_AI_Image"


def cloudflare_image_status() -> dict:
    account_id = _env("CLOUDFLARE_ACCOUNT_ID")
    token = _env("CLOUDFLARE_API_TOKEN")
    model = _env(
        "CLOUDFLARE_IMAGE_MODEL",
        "@cf/black-forest-labs/flux-1-schnell",
    )

    return {
        "provider": "Cloudflare Workers AI",
        "model": model,
        "configured": bool(account_id and token),
        "account_configured": bool(account_id),
        "token_configured": bool(token),
    }


def generate_cloudflare_image(
    prompt: str,
    title: str = "DPM Nexus AI Image",
) -> bytes:

    account_id = _env("CLOUDFLARE_ACCOUNT_ID")
    token = _env("CLOUDFLARE_API_TOKEN")
    model = _env(
        "CLOUDFLARE_IMAGE_MODEL",
        "@cf/black-forest-labs/flux-1-schnell",
    )

    if not account_id:
        raise RuntimeError(
            "CLOUDFLARE_ACCOUNT_ID is missing in backend/.env"
        )

    if not token:
        raise RuntimeError(
            "CLOUDFLARE_API_TOKEN is missing in backend/.env"
        )

    prompt = str(prompt or "").strip()

    if not prompt:
        raise RuntimeError("Image prompt is required.")

    enhanced_prompt = f"""
Create a premium professional visual for DPM ENTERPRISE PRIVATE LIMITED.

Project title:
{title}

User brief:
{prompt}

Quality direction:
- Photorealistic premium corporate quality.
- Sophisticated architectural composition where applicable.
- Realistic materials and realistic lighting.
- Clean refined commercially usable presentation.
- Light premium theme.
- Avoid cheap, dark or cluttered styling.
- No fake company logo.
- No random text.
- No watermark.
""".strip()

    url = (
        f"https://api.cloudflare.com/client/v4/accounts/"
        f"{account_id}/ai/run/{model}"
    )

    response = requests.post(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
        json={"prompt": enhanced_prompt},
        timeout=180,
    )

    if not response.ok:
        try:
            detail = response.json()
        except Exception:
            detail = response.text[:2000]

        raise RuntimeError(
            f"Cloudflare Workers AI HTTP {response.status_code}: {detail}"
        )

    content_type = response.headers.get("Content-Type", "")

    if "image/" in content_type:
        return response.content

    try:
        data = response.json()
    except Exception as exc:
        raise RuntimeError(
            "Cloudflare returned an invalid response."
        ) from exc

    if not data.get("success", False):
        raise RuntimeError(
            f"Cloudflare image generation failed: {data.get('errors')}"
        )

    result = data.get("result") or {}
    encoded = result.get("image")

    if not encoded:
        raise RuntimeError(
            "Cloudflare returned no image data."
        )

    try:
        return base64.b64decode(encoded)
    except Exception as exc:
        raise RuntimeError(
            "Cloudflare returned invalid image data."
        ) from exc


def generate_cloudflare_image_file(
    prompt: str,
    title: str = "DPM Nexus AI Image",
):
    raw = generate_cloudflare_image(
        prompt=prompt,
        title=title,
    )

    filename = f"{_safe_filename(title)}.jpg"

    return filename, "image/jpeg", raw
