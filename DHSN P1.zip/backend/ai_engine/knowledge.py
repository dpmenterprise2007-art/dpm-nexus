# DPM AI KNOWLEDGE BASE V9


DPM_KNOWLEDGE = {


"company":

"""
DPM ENTERPRISE PRIVATE LIMITED

DPM Enterprise provides turnkey interior solutions,
furniture manufacturing and infrastructure services.

Services:
- Corporate Interior
- Commercial Interior
- Residential Interior
- Luxury Villa Interior
- Hotel Interior
- Restaurant Interior
- Showroom Interior
- Furniture Manufacturing
""",



"corporate":

"""
DPM Enterprise specializes in large scale corporate
office interiors with premium finishes,
custom furniture, glass partitions,
woodwork and complete execution.
""",



"residential":

"""
DPM provides luxury residential interior solutions:

- Modular Kitchen
- Wardrobe
- TV Unit
- False Ceiling
- Furniture
- Complete Home Interior
""",



"boq":

"""
DPM provides professional BOQ preparation,
estimation and turnkey project planning.
""",



"contact":

"""
For project discussion contact:

DPM Enterprise

WhatsApp:
9930998063
"""
}