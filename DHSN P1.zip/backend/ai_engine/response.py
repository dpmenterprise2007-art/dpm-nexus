from ai_engine.knowledge import DPM_KNOWLEDGE


def generate_response(message):
    msg = message.lower()

    if "corporate" in msg or "office" in msg:
        return DPM_KNOWLEDGE["corporate"]

    elif "home" in msg or "residential" in msg:
        return DPM_KNOWLEDGE["residential"]

    elif "boq" in msg or "estimate" in msg:
        return DPM_KNOWLEDGE["boq"]

    elif "contact" in msg or "number" in msg:
        return DPM_KNOWLEDGE["contact"]

    else:
        return """
Thank you for contacting DPM Enterprise.

Please share:

1. Project Type
2. Location
3. Area Size
4. Budget Range
5. Timeline

Our project consultant will assist you.
"""


# ==========================================================
# DPM NEXUS AI — PHASE 1 SKILLS
# Additive only: existing generate_response() remains intact.
# ==========================================================

def generate_skill_file(skill, title, content):
    """
    Generate a real downloadable document from the AI Engine.

    skill: pdf | word | excel
    Returns: (filename, mime_type, bytes)
    """
    from ai_engine.skill_engine import generate_file
    return generate_file(skill, title, content)
