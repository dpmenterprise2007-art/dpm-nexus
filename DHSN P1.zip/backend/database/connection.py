# ==========================================================
# DPM NEXUS V9
# DATABASE CONNECTION
# ==========================================================

import os

from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

load_dotenv()

# Keep the existing DHSN local database when no explicit
# DATABASE_URL is configured. Existing data is preserved.
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "sqlite:///./dhsn.db"
)

if DATABASE_URL.startswith("sqlite"):
    engine = create_engine(
        DATABASE_URL,
        connect_args={"check_same_thread": False},
        pool_pre_ping=True,
        echo=False,
    )
else:
    engine = create_engine(
        DATABASE_URL,
        pool_pre_ping=True,
        echo=False,
    )

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
