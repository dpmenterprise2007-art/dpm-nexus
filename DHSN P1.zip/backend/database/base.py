# ==========================================================
# DPM NEXUS V9
# DATABASE BASE
# ==========================================================


from sqlalchemy.orm import declarative_base

Base = declarative_base()