from core.database import SessionLocal
from models.user import User
from core.security import hash_password

db = SessionLocal()

admin = User(
    full_name="DHSN Super Admin",
    email="admin@dpmenterprise.in",
    password_hash=hash_password("Admin@123"),
    role="SUPER_ADMIN"
)

db.add(admin)
db.commit()

print("SUPER ADMIN CREATED")