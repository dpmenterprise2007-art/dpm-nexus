
import os
import sys
from pathlib import Path
from dotenv import load_dotenv
from google import genai

load_dotenv(Path(__file__).resolve().parent / ".env")

api_key = os.getenv("GEMINI_API_KEY", "").strip()
model = os.getenv("GEMINI_IMAGE_MODEL", "gemini-2.5-flash-image").strip()

if not api_key:
    sys.exit("ERROR: GEMINI_API_KEY .env file mein nahi mili.")

try:
    client = genai.Client(api_key=api_key)

    print("Gemini image test shuru...")
    print("Model:", model)

    response = client.models.generate_content(
        model=model,
        contents=(
            "Generate a photorealistic premium corporate office interior "
            "with Italian marble flooring, light wood veneer, elegant "
            "lighting and realistic furniture. No text, no logo."
        ),
    )

    saved = False
    for candidate in response.candidates or []:
        content = candidate.content
        if not content:
            continue
        for part in content.parts or []:
            if part.inline_data and part.inline_data.data:
                mime = part.inline_data.mime_type or "image/png"
                ext = ".jpg" if "jpeg" in mime else ".png"
                output = Path(__file__).resolve().parent / ("gemini_test_image" + ext)
                output.write_bytes(part.inline_data.data)
                print("SUCCESS! Image saved:", output)
                saved = True
                break
        if saved:
            break

    if not saved:
        print("Response mein image nahi mili.")
        print("Response text:", getattr(response, "text", None))
        sys.exit(2)

except Exception as exc:
    print("GEMINI ERROR:", type(exc).__name__, str(exc))
    sys.exit(1)
