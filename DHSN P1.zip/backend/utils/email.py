"""
DPM Nexus V9 - Central Email Utility
-------------------------------------
Keeps inquiry and OTP email delivery in one reusable module.
Existing email_inquiry.py is intentionally left untouched for compatibility.
"""

from __future__ import annotations

import html
import logging
import os
import smtplib
from email.message import EmailMessage
from pathlib import Path
from typing import Iterable

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parents[1]
load_dotenv(BASE_DIR / ".env")

logger = logging.getLogger("DPM-Nexus-Email")

SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USERNAME = os.getenv("SMTP_USERNAME", "")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
FROM_EMAIL = os.getenv("FROM_EMAIL", SMTP_USERNAME)
FROM_NAME = os.getenv("FROM_NAME", "DPM Enterprise Private Limited")

ADMIN_EMAILS = [
    item.strip()
    for item in os.getenv("ADMIN_EMAILS", SMTP_USERNAME).split(",")
    if item.strip()
]

SMTP_TIMEOUT = int(os.getenv("SMTP_TIMEOUT", "20"))


def _normalise_recipients(recipients: Iterable[str] | str) -> list[str]:
    if isinstance(recipients, str):
        recipients = recipients.split(",")
    return [str(item).strip() for item in recipients if str(item).strip()]


def send_email(
    subject: str,
    html_body: str,
    recipients: Iterable[str] | str,
    *,
    text_body: str | None = None,
    reply_to: str | None = None,
) -> bool:
    """Send an HTML email through the configured SMTP server."""
    to_list = _normalise_recipients(recipients)

    if not to_list:
        logger.error("Email skipped: no recipients configured")
        return False

    if not SMTP_USERNAME or not SMTP_PASSWORD:
        logger.error("Email skipped: SMTP credentials are not configured")
        return False

    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = f"{FROM_NAME} <{FROM_EMAIL}>"
    message["To"] = ", ".join(to_list)
    if reply_to:
        message["Reply-To"] = reply_to

    message.set_content(text_body or "Please view this email in an HTML-capable email client.")
    message.add_alternative(html_body, subtype="html")

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=SMTP_TIMEOUT) as server:
            server.ehlo()
            server.starttls()
            server.ehlo()
            server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.send_message(message)
        logger.info("Email sent successfully to %s", ", ".join(to_list))
        return True
    except Exception:
        logger.exception("Email delivery failed")
        return False


def _safe(value: object) -> str:
    return html.escape(str(value or "")).replace("\n", "<br>")


def _email_shell(title: str, content: str) -> str:
    return f"""<!doctype html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;background:#f4f7fb;font-family:Arial,Helvetica,sans-serif;color:#172033;">
  <div style="max-width:720px;margin:30px auto;padding:0 16px;">
    <div style="background:#0b1120;color:#fff;padding:24px 28px;border-radius:18px 18px 0 0;">
      <div style="font-size:12px;letter-spacing:1.5px;opacity:.75;">DPM NEXUS</div>
      <div style="font-size:25px;font-weight:700;margin-top:6px;">{_safe(title)}</div>
    </div>
    <div style="background:#fff;padding:30px;border:1px solid #e6ebf2;border-top:0;border-radius:0 0 18px 18px;">
      {content}
      <div style="margin-top:28px;padding-top:18px;border-top:1px solid #e8edf3;font-size:12px;color:#718096;">
        DPM Enterprise Private Limited · DPM Nexus Enterprise Platform
      </div>
    </div>
  </div>
</body>
</html>"""


def send_inquiry_email(
    client_name: str,
    company_name: str,
    email: str,
    phone: str,
    subject: str,
    message: str,
    *,
    inquiry_type: str = "General Business Inquiry",
    location: str = "",
    timeline: str = "",
    request_id: str = "",
) -> bool:
    """Send a complete inquiry notification to configured DPM recipients."""
    rows = [
        ("Inquiry ID", request_id),
        ("Full Name", client_name),
        ("Company / Organization", company_name),
        ("Email", email),
        ("Phone", phone),
        ("Inquiry Type", inquiry_type),
        ("Project Location", location),
        ("Expected Timeline / Priority", timeline),
        ("Subject", subject),
    ]

    table = "".join(
        f'<tr><td style="padding:10px 12px;border-bottom:1px solid #edf1f5;font-weight:700;width:38%;">{_safe(k)}</td>'
        f'<td style="padding:10px 12px;border-bottom:1px solid #edf1f5;">{_safe(v) or "—"}</td></tr>'
        for k, v in rows
    )

    content = f"""
    <p style="font-size:16px;line-height:1.7;">A new website inquiry has been received.</p>
    <table style="width:100%;border-collapse:collapse;font-size:14px;">{table}</table>
    <div style="margin-top:22px;padding:18px;background:#f7f9fc;border-radius:12px;">
      <div style="font-weight:700;margin-bottom:8px;">Project Scope / Requirement</div>
      <div style="line-height:1.7;">{_safe(message) or "—"}</div>
    </div>
    """

    subject_line = f"New Inquiry | {request_id or company_name or client_name}"
    text = (
        f"New DPM Nexus inquiry\n\n"
        f"Inquiry ID: {request_id}\nName: {client_name}\nCompany: {company_name}\n"
        f"Email: {email}\nPhone: {phone}\nType: {inquiry_type}\n"
        f"Location: {location}\nTimeline: {timeline}\nSubject: {subject}\n\n"
        f"Requirement:\n{message}"
    )
    return send_email(
        subject_line,
        _email_shell("New Enterprise Inquiry", content),
        ADMIN_EMAILS,
        text_body=text,
        reply_to=email,
    )


def send_auto_reply(client_name: str, client_email: str, request_id: str = "") -> bool:
    content = f"""
    <p style="font-size:16px;line-height:1.7;">Dear {_safe(client_name)},</p>
    <p style="font-size:16px;line-height:1.7;">Thank you for contacting DPM Enterprise Private Limited. We have received your inquiry and our team will review the requirement.</p>
    <div style="padding:16px;background:#f7f9fc;border-radius:12px;margin:20px 0;">
      <strong>Inquiry ID:</strong> {_safe(request_id) or "Generated"}<br>
      <span style="color:#64748b;">Please keep this reference for future communication.</span>
    </div>
    <p style="font-size:15px;line-height:1.7;">Our team will contact you using the details submitted in the inquiry.</p>
    <p style="margin-top:24px;">Regards,<br><strong>DPM Enterprise Private Limited</strong><br>DPM Nexus</p>
    """
    text = (
        f"Dear {client_name},\n\nThank you for contacting DPM Enterprise Private Limited. "
        f"We have received your inquiry.\n\nInquiry ID: {request_id}\n\nRegards,\nDPM Enterprise Private Limited"
    )
    return send_email(
        "DPM Nexus | Inquiry Received",
        _email_shell("Inquiry Received", content),
        [client_email],
        text_body=text,
    )


def send_otp_email(client_email: str, otp: str) -> bool:
    content = f"""
    <p style="font-size:16px;line-height:1.7;">Your DPM Nexus verification code is:</p>
    <div style="font-size:34px;letter-spacing:10px;font-weight:800;text-align:center;padding:20px;background:#f7f9fc;border-radius:14px;color:#2563eb;">{_safe(otp)}</div>
    <p style="font-size:14px;color:#64748b;line-height:1.7;">This OTP is valid for 5 minutes. Do not share it with anyone.</p>
    """
    return send_email(
        "DPM Nexus | Email Verification OTP",
        _email_shell("Email Verification", content),
        [client_email],
        text_body=f"Your DPM Nexus OTP is {otp}. It is valid for 5 minutes.",
    )
