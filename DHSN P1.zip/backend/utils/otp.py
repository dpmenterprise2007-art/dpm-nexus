import random
from datetime import datetime, timedelta


# ===============================
# GENERATE 6 DIGIT OTP
# ===============================

def generate_otp():

    return str(
        random.randint(
            100000,
            999999
        )
    )


# ===============================
# OTP EXPIRY TIME
# ===============================

def otp_expiry_time():

    return datetime.utcnow() + timedelta(
        minutes=5
    )


# ===============================
# VERIFY OTP EXPIRY
# ===============================

def is_otp_expired(expiry_time):

    if not expiry_time:
        return True


    return datetime.utcnow() > expiry_time