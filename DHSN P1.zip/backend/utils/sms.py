"""Optional SMS delivery for DPM Nexus OTP.

Supports Twilio and Fast2SMS using environment variables. No fake SMS success
is ever returned when credentials are missing.
"""

from __future__ import annotations

import base64
import os
import urllib.parse
import urllib.request


def send_mobile_otp(phone: str, otp: str) -> tuple[bool, str]:
    """Return (success, message). Uses Fast2SMS first, then Twilio."""
    fast2sms_key = os.getenv("FAST2SMS_API_KEY", "").strip()
    if fast2sms_key:
        return _send_fast2sms(phone, otp, fast2sms_key)

    sid = os.getenv("TWILIO_ACCOUNT_SID", "").strip()
    token = os.getenv("TWILIO_AUTH_TOKEN", "").strip()
    from_number = os.getenv("TWILIO_FROM_NUMBER", "").strip()
    if sid and token and from_number:
        return _send_twilio(phone, otp, sid, token, from_number)

    return (
        False,
        "Mobile OTP service is not configured. Add FAST2SMS_API_KEY or Twilio credentials to backend/.env.",
    )


def _send_fast2sms(phone: str, otp: str, api_key: str) -> tuple[bool, str]:
    url = "https://www.fast2sms.com/dev/bulkV2"
    payload = urllib.parse.urlencode({
        "route": "q",
        "message": f"Your DPM Nexus verification OTP is {otp}. It is valid for 5 minutes.",
        "language": "english",
        "flash": "0",
        "numbers": phone,
    }).encode()
    request = urllib.request.Request(
        url,
        data=payload,
        headers={"authorization": api_key, "Content-Type": "application/x-www-form-urlencoded"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            body = response.read().decode("utf-8", errors="replace")
            if 200 <= response.status < 300:
                return True, "Mobile OTP sent successfully."
            return False, f"SMS provider rejected the request: HTTP {response.status}. {body[:200]}"
    except Exception as exc:
        return False, f"Mobile OTP delivery failed: {exc}"


def _send_twilio(phone: str, otp: str, sid: str, token: str, from_number: str) -> tuple[bool, str]:
    url = f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json"
    payload = urllib.parse.urlencode({
        "From": from_number,
        "To": phone if phone.startswith("+") else f"+91{phone}",
        "Body": f"Your DPM Nexus verification OTP is {otp}. It is valid for 5 minutes.",
    }).encode()
    basic = base64.b64encode(f"{sid}:{token}".encode()).decode()
    request = urllib.request.Request(
        url,
        data=payload,
        headers={
            "Authorization": f"Basic {basic}",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            body = response.read().decode("utf-8", errors="replace")
            if 200 <= response.status < 300:
                return True, "Mobile OTP sent successfully."
            return False, f"SMS provider rejected the request: HTTP {response.status}. {body[:200]}"
    except Exception as exc:
        return False, f"Mobile OTP delivery failed: {exc}"
