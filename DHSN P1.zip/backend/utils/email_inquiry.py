import os
import smtplib

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from dotenv import load_dotenv

load_dotenv()


SMTP_HOST = os.getenv("SMTP_HOST")

SMTP_PORT = int(os.getenv("SMTP_PORT"))

SMTP_USERNAME = os.getenv("SMTP_USERNAME")

SMTP_PASSWORD = os.getenv("SMTP_PASSWORD")


ADMIN_EMAILS = [

email.strip()

for email in

os.getenv(

"ADMIN_EMAILS",

""

).split(",")

if email.strip()

]


FROM_NAME = "DPM Nexus AI"


def send_email(

subject: str,

html_body: str,

recipients: list

):

    try:

        server = smtplib.SMTP(

            SMTP_HOST,

            SMTP_PORT

        )

        server.starttls()

        server.login(

            SMTP_USERNAME,

            SMTP_PASSWORD

        )

        for recipient in recipients:

            message = MIMEMultipart()

            message["From"] = f"{FROM_NAME} <{SMTP_USERNAME}>"

            message["To"] = recipient

            message["Subject"] = subject

            message.attach(

                MIMEText(

                    html_body,

                    "html"

                )

            )

            server.sendmail(

                SMTP_USERNAME,

                recipient,

                message.as_string()

            )

        server.quit()

        return True

    except Exception as e:

        print(

            "EMAIL ERROR:",

            str(e)

        )

        return False


def send_inquiry_email(

    client_name,

    company_name,

    email,

    phone,

    subject,

    message

):

    html = f"""

    <html>

    <body
    style="font-family:Arial;padding:30px;background:#f5f5f5;">

    <div
    style="background:white;padding:30px;border-radius:12px;">

    <h2>

    New Inquiry Received

    </h2>

    <hr>

    <table
    cellpadding="10">

    <tr>

    <td><b>Name</b></td>

    <td>{client_name}</td>

    </tr>

    <tr>

    <td><b>Company</b></td>

    <td>{company_name}</td>

    </tr>

    <tr>

    <td><b>Email</b></td>

    <td>{email}</td>

    </tr>

    <tr>

    <td><b>Phone</b></td>

    <td>{phone}</td>

    </tr>

    <tr>

    <td><b>Subject</b></td>

    <td>{subject}</td>

    </tr>

    <tr>

    <td><b>Message</b></td>

    <td>{message}</td>

    </tr>

    </table>

    </div>

    </body>

    </html>

    """

    return send_email(

        subject=f"New Inquiry | {company_name}",

        html_body=html,

        recipients=ADMIN_EMAILS

    )


def send_auto_reply(

    client_name,

    client_email

):

    html = f"""

    <html>

    <body
    style="font-family:Arial;padding:30px;">

    <h2>

    Thank You

    {client_name}

    </h2>

    <p>

    We have received your inquiry.

    </p>

    <p>

    Our team will contact you shortly.

    </p>

    <br>

    Regards,

    <br>

    DPM Enterprise Private Limited

    </body>

    </html>

    """

    return send_email(

        subject="Thank You For Contacting DPM Enterprise",

        html_body=html,

        recipients=[client_email]

    )