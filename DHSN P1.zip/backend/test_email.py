from services.email_service import EmailService

html = """
<h2>DPM Enterprise Private Limited</h2>

<p>SMTP Testing Successful ✅</p>

<p>This email is sent from DPM Nexus V9.</p>
"""

status, message = EmailService.send_email(
    to_email="dpmenterprise2007@gmail.com",
    subject="SMTP Test | DPM Enterprise",
    html_body=html
)

print(status)
print(message)