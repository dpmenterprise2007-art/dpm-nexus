from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

# ==========================
# ROUTERS
# ==========================

from routes.auth import router as auth_router

# Dashboard router optional
try:
    from routes.dashboard import router as dashboard_router
    HAS_DASHBOARD = True
except ImportError:
    HAS_DASHBOARD = False

# ==========================
# APP
# ==========================

app = FastAPI(
    title="DPM AI OS",
    version="5.0.0"
)

# ==========================
# SESSION
# ==========================

app.add_middleware(
    SessionMiddleware,
    secret_key="DPM_AI_OS_SUPER_SECRET_2026"
)

# ==========================
# CORS
# ==========================

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:8000",
        "http://localhost.8000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ==========================
# ROUTERS
# ==========================

app.include_router(auth_router)

if HAS_DASHBOARD:
    app.include_router(dashboard_router)

# ==========================
# PATHS
# ==========================

BASE_DIR = Path(__file__).resolve().parent
FRONTEND_DIR = BASE_DIR.parent / "frontend"

# ==========================
# STATIC
# ==========================

app.mount(
    "/static",
    StaticFiles(directory=FRONTEND_DIR),
    name="static"
)

# ==========================
# PAGES
# ==========================

@app.get("/", include_in_schema=False)
async def index():
    return FileResponse(FRONTEND_DIR / "index.html")


@app.get("/login", include_in_schema=False)
async def login():
    return FileResponse(FRONTEND_DIR / "login.html")


@app.get("/dashboard", include_in_schema=False)
async def dashboard():
    return FileResponse(FRONTEND_DIR / "dashboard.html")


@app.get("/about", include_in_schema=False)
async def about():
    return FileResponse(FRONTEND_DIR / "about.html")


@app.get("/contact", include_in_schema=False)
async def contact():
    return FileResponse(FRONTEND_DIR / "contact.html")



# ==========================
# API
# ==========================

@app.get("/health")
async def health():
    return {
        "status": "running",
        "platform": "DPM AI OS",
        "version": "5.0.0"
    }


@app.get("/api")
async def api():
    return {
        "message": "DPM AI OS API Running"
    }