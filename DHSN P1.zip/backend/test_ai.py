from ai_engine.response import generate_response


print(
generate_response(
"Need corporate office interior"
)
)