@echo off
setlocal
title DPM Nexus V9 - Phase 1 Routes Installer

cd /d "%~dp0"

echo ================================================
echo DPM NEXUS V9 - PHASE 1 ROUTES
echo PDF + WORD + EXCEL
echo ================================================
echo.

echo [1] Installing dependencies...
python -m pip install -r requirements_phase1.txt
if errorlevel 1 goto FAIL

echo.
echo [2] Creating AI Engine folders...
if not exist "ai_engine" mkdir "ai_engine"
if not exist "ai_engine\skills" mkdir "ai_engine\skills"
if not exist "routes" mkdir "routes"

echo.
echo [3] Backing up existing files...
if exist "main.py" (
    if not exist "main.py.phase1_routes_backup" (
        copy /Y "main.py" "main.py.phase1_routes_backup" >nul
    )
)
if exist "ai_engine\response.py" (
    if not exist "ai_engine\response.py.phase1_routes_backup" (
        copy /Y "ai_engine\response.py" "ai_engine\response.py.phase1_routes_backup" >nul
    )
)

echo.
echo [4] Copying Phase 1 files...
copy /Y "package\ai_engine\__init__.py" "ai_engine\__init__.py" >nul
copy /Y "package\ai_engine\knowledge.py" "ai_engine\knowledge.py" >nul
copy /Y "package\ai_engine\response.py" "ai_engine\response.py" >nul
copy /Y "package\ai_engine\skill_engine.py" "ai_engine\skill_engine.py" >nul
copy /Y "package\ai_engine\skills\__init__.py" "ai_engine\skills\__init__.py" >nul
copy /Y "package\ai_engine\skills\pdf_skill.py" "ai_engine\skills\pdf_skill.py" >nul
copy /Y "package\ai_engine\skills\word_skill.py" "ai_engine\skills\word_skill.py" >nul
copy /Y "package\ai_engine\skills\excel_skill.py" "ai_engine\skills\excel_skill.py" >nul
copy /Y "package\routes\ai_skills.py" "routes\ai_skills.py" >nul

echo.
echo [5] Integrating router into existing main.py...
python install_phase1_routes.py
if errorlevel 1 goto FAIL

echo.
echo ================================================
echo PHASE 1 ROUTES INSTALLED
echo ================================================
echo.
echo Restart:
echo python -m uvicorn main:app --reload
echo.
echo Test:
echo http://127.0.0.1:8000/api/ai/skills/status
echo http://127.0.0.1:8000/docs
echo.
pause
exit /b 0

:FAIL
echo.
echo INSTALLATION FAILED.
pause
exit /b 1
