@echo off
setlocal
cd /d "%~dp0.."
if not exist "backend\ai_engine\skill_engine.py" (
  echo ERROR: backend\ai_engine\skill_engine.py not found.
  pause
  exit /b 1
)
if not exist "backend\ai_engine\skill_engine.py.backup_before_pdf_style" copy /Y "backend\ai_engine\skill_engine.py" "backend\ai_engine\skill_engine.py.backup_before_pdf_style" >nul
copy /Y "%~dp0ai_engine\skill_engine.py" "backend\ai_engine\skill_engine.py" >nul
if errorlevel 1 (
  echo ERROR: Could not update skill_engine.py
  pause
  exit /b 1
)
echo.
echo DPM Nexus AI FINAL PDF STYLE installed.
echo Existing skill_engine.py backup created before replacement.
echo Restart FastAPI after this.
echo.
pause
