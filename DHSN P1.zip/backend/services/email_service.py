import smtplib

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from config.email import (
    SMTP_HOST,
    SMTP_PORT,
    SMTP_USERNAME,
    SMTP_PASSWORD,
    FROM_EMAIL,
    FROM_NAME,
)


class EmailService:

    @staticmethod
    def send_email(
        to_email: str,
        subject: str,
        html_body: str
    ) -> tuple[bool, str]:

        try:

            message = MIMEMultipart("alternative")

            message["Subject"] = subject
            message["From"] = f"{FROM_NAME} <{FROM_EMAIL}>"
            message["To"] = to_email

            message.attach(
                MIMEText(html_body, "html")
            )

            with smtplib.SMTP(
                SMTP_HOST,
                SMTP_PORT
            ) as server:

                server.ehlo()

                server.starttls()

                server.login(
                    SMTP_USERNAME,
                    SMTP_PASSWORD
                )

                server.sendmail(
                    FROM_EMAIL,
                    [to_email],
                    message.as_string()
                )

            return True, "Email Sent Successfully"

        except Exception as e:

            return False, str(e)