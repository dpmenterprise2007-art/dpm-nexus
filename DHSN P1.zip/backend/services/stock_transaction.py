# ==========================================================
# DPM NEXUS V9
# STOCK TRANSACTION MODEL
# ==========================================================


from sqlalchemy import (

    Column,

    Integer,

    String,

    Float,

    DateTime

)

from datetime import datetime

from database.base import Base



class StockTransaction(Base):

    __tablename__ = "stock_transactions"


    id = Column(

        Integer,

        primary_key=True

    )


    material_id = Column(

        Integer

    )


    transaction_type = Column(

        String(50)

    )


    quantity = Column(

        Float

    )


    project_id = Column(

        Integer,

        nullable=True

    )


    reference = Column(

        String(200)

    )


    created_at = Column(

        DateTime,

        default=datetime.utcnow

    )