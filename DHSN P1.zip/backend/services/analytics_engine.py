# ==========================================================
# DPM NEXUS V9
# ANALYTICS ENGINE
# ==========================================================


def calculate_growth(

    current,

    previous

):


    if previous == 0:

        return 0


    growth = (

        (current - previous)

        /

        previous

    ) * 100


    return round(

        growth,

        2

    )



def generate_summary(data):


    return {


        "total": len(data),


        "status": "Analytics Generated"


    }