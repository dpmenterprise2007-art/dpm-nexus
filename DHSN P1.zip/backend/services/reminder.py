# ==========================================================
# DPM NEXUS V9
# REMINDER SERVICE
# ==========================================================


from datetime import datetime



def check_reminder(event):


    today = datetime.now().date()


    if str(today) == event.event_date:


        return {


            "reminder": True,


            "message":

            f"Reminder: {event.title}"

        }



    return {


        "reminder": False

    }