"""
=========================================================
DPM NEXUS V9
EMAIL CONFIGURATION
=========================================================
Development  : Gmail SMTP
Production   : GoDaddy Business Email SMTP
=========================================================
"""

import os
from dotenv import load_dotenv

# Load .env file
load_dotenv()


# =========================================================
# SMTP SETTINGS
# =========================================================

SMTP_HOST = os.getenv(
    "SMTP_HOST",
    "smtp.gmail.com"
)

SMTP_PORT = int(
    os.getenv(
        "SMTP_PORT",
        "587"
    )
)

SMTP_USERNAME = os.getenv(
    "SMTP_USERNAME"
)

SMTP_PASSWORD = os.getenv(
    "SMTP_PASSWORD"
)

SMTP_USE_TLS = True


# =========================================================
# EMAIL DETAILS
# =========================================================

FROM_EMAIL = SMTP_USERNAME

FROM_NAME = "DPM Enterprise Private Limited"


# =========================================================
# ADMIN EMAILS
# =========================================================

ADMIN_EMAILS = [

    "dpmenterprise2007@gmail.com",

    # Production
    # "admin@dpmenterprise.in"

]