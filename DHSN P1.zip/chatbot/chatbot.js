/* DPM Nexus V10 — chatbot UI behavior
 * Sends no requests until a real, verified endpoint is configured.
 */
(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector('form[data-chat-form], #chat-history + form');
    const history = document.querySelector("#chat-history");
    if (!form || !history) return;

    form.addEventListener("submit", function (event) {
      const message = form.querySelector('textarea[name="message"]');
      if (!message || !message.value.trim()) {
        event.preventDefault();
        if (message) message.focus();
        return;
      }

      // The browser submits the form to its declared action. This handler only
      // performs local validation; endpoint and response rendering need integration.
    });

    history.setAttribute("aria-live", "polite");
  });
})();
